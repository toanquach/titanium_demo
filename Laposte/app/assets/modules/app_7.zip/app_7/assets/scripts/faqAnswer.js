var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

(function() {
  var FaqAnswer;
  FaqAnswer = (function(_super) {
    __extends(FaqAnswer, _super);

    function FaqAnswer() {
      this.failLoadFaq = __bind(this.failLoadFaq, this);
      this.successLoadFaq = __bind(this.successLoadFaq, this);
      var data;
      this.question = ko.observable();
      this.answer = ko.observable();
      data = $('#app').data('json');
      FaqAnswer.__super__.constructor.call(this, data);
    }

    FaqAnswer.prototype.isSuccessLoaded = function() {
      var jsonPath;
      jsonPath = Helpers.convertAbsoluteToRelativeJsonPath(this.getData().json.faq);
      return Helpers.loadJson(jsonPath).done(this.successLoadFaq).fail(this.failLoadFaq);
    };

    FaqAnswer.prototype.successLoadFaq = function(data) {
      var id;
      id = parseInt(Helpers.getUrlVar("question"), 10) - 1;
      this.question(data.faq[id].question);
      this.answer(data.faq[id].answer);
      this.fillLabels();
      Bridge.hideLoader();
      return Bridge.tracking(7, "page", {
        "myPageLabel": "faq_answer",
        "andPageChapter": "faq_answer"
      });
    };

    FaqAnswer.prototype.failLoadFaq = function(error) {
      return console.log(error);
    };

    return FaqAnswer;

  })(ManifestLoader);
  return $(function() {
    return ko.applyBindings(new FaqAnswer());
  });
})();
