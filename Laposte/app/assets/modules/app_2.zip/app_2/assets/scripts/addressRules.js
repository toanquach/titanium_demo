var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

(function() {
  var AddressRules;
  AddressRules = (function(_super) {
    __extends(AddressRules, _super);

    function AddressRules() {
      this.failLoadAddressRules = __bind(this.failLoadAddressRules, this);
      this.successLoadAddressRules = __bind(this.successLoadAddressRules, this);
      var data;
      this.rules = ko.observableArray();
      data = $('#app').data('json');
      AddressRules.__super__.constructor.call(this, data);
    }

    AddressRules.prototype.isSuccessLoaded = function() {
      var jsonPath;
      jsonPath = Helpers.convertAbsoluteToRelativeJsonPath(this.getData().json.addressRules);
      return Helpers.loadJson(jsonPath).done(this.successLoadAddressRules).fail(this.failLoadAddressRules);
    };

    AddressRules.prototype.successLoadAddressRules = function(data) {
      this.data = data.rules;
      this.setRules();
      Bridge.hideLoader();
      return Bridge.tracking(5, "page", {
        "myPageLabel": "regles_adresse",
        "andPageChapter": "regles_adresse"
      });
    };

    AddressRules.prototype.failLoadAddressRules = function(error) {
      return console.log(error);
    };

    AddressRules.prototype.setRules = function() {
      var i, _i, _ref, _results;
      _results = [];
      for (i = _i = 0, _ref = this.data.length; 0 <= _ref ? _i < _ref : _i > _ref; i = 0 <= _ref ? ++_i : --_i) {
        _results.push(this.rules.push(new this.DisplayRule(this.data[i], this)));
      }
      return _results;
    };

    AddressRules.prototype.DisplayRule = function(data, that) {
      this.num = data.num;
      return this.desc = data.rule;
    };

    return AddressRules;

  })(ManifestLoader);
  return $(function() {
    return ko.applyBindings(new AddressRules());
  });
})();
