var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

(function() {
  var choisirEnvoiSuivi;
  choisirEnvoiSuivi = (function(_super) {
    __extends(choisirEnvoiSuivi, _super);

    choisirEnvoiSuivi.prototype.instance = null;

    function choisirEnvoiSuivi() {
      this.clickAdviceHandler = __bind(this.clickAdviceHandler, this);
      this.successLoad = __bind(this.successLoad, this);
      var data;
      this.products = ko.observableArray();
      this.title = ko.observable();
      data = $('#app').data('json');
      choisirEnvoiSuivi.__super__.constructor.call(this, data);
    }

    choisirEnvoiSuivi.prototype.isSuccessLoaded = function() {
      return Helpers.loadJson(Helpers.convertAbsoluteToRelativeJsonPath(this.getData().json.choisirEnvoiSuivi)).done(this.successLoad).fail(this.failLoad);
    };

    choisirEnvoiSuivi.prototype.successLoad = function(data) {
      var andPageChapter;
      this.fillLabels();
      $('.need-help').on('click', this.clickAdviceHandler);
      this.title(data.title);
      this.data = data.products;
      this.displayProducts();
      Helpers.forceImgToRetina($('img'));
      Bridge.hideLoader();
      if (Helpers.getUrlVar("type") != null) {
        andPageChapter = data.tracking.andPageChapter.replace("_TYPE_", Helpers.getUrlVar("type"));
      } else {
        andPageChapter = data.tracking.andPageChapter;
      }
      return Bridge.tracking(data.tracking.setLevel2, "page", {
        "myPageLabel": data.tracking.myPageLabel,
        "andPageChapter": andPageChapter
      });
    };

    choisirEnvoiSuivi.prototype.displayProducts = function() {
      var i, _i, _ref, _results;
      _results = [];
      for (i = _i = 0, _ref = this.data.length; 0 <= _ref ? _i < _ref : _i > _ref; i = 0 <= _ref ? ++_i : --_i) {
        _results.push(this.products.push(new this.displayProduct(this.data[i], this)));
      }
      return _results;
    };

    choisirEnvoiSuivi.prototype.displayProduct = function(data, that) {
      this.title = data.title;
      this.type = data.type;
      this.link = data.link;
      this.desc = data.desc;
      this.format = data.format;
      this.price = data.price;
    };

    choisirEnvoiSuivi.prototype.clickAdviceHandler = function(e) {
      var completeUrl, target, url;
      e.preventDefault();
      target = e.currentTarget;
      url = $(target).attr('href');
      completeUrl = "" + (Helpers.getCurrentApp()) + "/views/" + url;
      return Bridge.displayPopin(completeUrl, null, "Service Conso");
    };

    return choisirEnvoiSuivi;

  })(ManifestLoader);
  return $(function() {
    return ko.applyBindings(new choisirEnvoiSuivi());
  });
})();
