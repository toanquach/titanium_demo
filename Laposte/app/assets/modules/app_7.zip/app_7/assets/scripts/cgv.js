var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

(function() {
  var Cgv;
  Cgv = (function(_super) {
    __extends(Cgv, _super);

    function Cgv() {
      this.failLoadCGV = __bind(this.failLoadCGV, this);
      this.successLoadCGV = __bind(this.successLoadCGV, this);
      var data;
      this.title = ko.observable();
      this.articles = ko.observableArray();
      data = $('#app').data('json');
      Cgv.__super__.constructor.call(this, data);
    }

    Cgv.prototype.isSuccessLoaded = function() {
      var jsonPath;
      jsonPath = Helpers.convertAbsoluteToRelativeJsonPath(this.getData().json.cgv);
      return Helpers.loadJson(jsonPath).done(this.successLoadCGV).fail(this.failLoadCGV);
    };

    Cgv.prototype.successLoadCGV = function(data) {
      this.fillLabels();
      this.title(data.title);
      this.setArticles(data);
      Bridge.hideLoader();
      return Bridge.tracking(7, "page", {
        "myPageLabel": "cgv",
        "andPageChapter": "envoyer_une_carte::cgv"
      });
    };

    Cgv.prototype.failLoadCGV = function(error) {
      return console.log(error);
    };

    Cgv.prototype.setArticles = function(data) {
      var item, _i, _len, _ref, _results;
      _ref = data.articles;
      _results = [];
      for (_i = 0, _len = _ref.length; _i < _len; _i++) {
        item = _ref[_i];
        _results.push(this.articles.push(new this.DisplayArticle(item, this)));
      }
      return _results;
    };

    Cgv.prototype.DisplayArticle = function(data, that) {
      this.title = data.title;
      this.description = data.description;
      return this;
    };

    return Cgv;

  })(ManifestLoader);
  return $(function() {
    return ko.applyBindings(new Cgv());
  });
})();
