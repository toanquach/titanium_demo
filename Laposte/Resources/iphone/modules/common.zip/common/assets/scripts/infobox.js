var __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

(function() {
  var Infobox;
  Infobox = (function(_super) {
    __extends(Infobox, _super);

    function Infobox(opts) {
      google.maps.OverlayView.call(this);
      this.latlng_ = opts.latlng;
      this.map_ = opts.map;
      this.template_ = opts.content;
      if (opts.height === void 0) {
        opts.height = 168;
      }
      this.height_ = opts.height;
      if (opts.width === void 0) {
        opts.width = 290;
      }
      this.width_ = opts.width;
      this.offsetVertical_ = -(this.height_ + 65);
      this.offsetHorizontal_ = -(this.width_ / 2);
      this.setMap(this.map_);
    }

    Infobox.prototype.remove = function() {
      if (this.div_) {
        this.div_.parentNode.removeChild(this.div_);
        return this.div_ = null;
      }
    };

    Infobox.prototype.draw = function() {
      var pixPosition;
      this.createElement();
      if (!this.div_) {
        return;
      }
      pixPosition = this.getProjection().fromLatLngToDivPixel(this.latlng_);
      if (!pixPosition) {
        return;
      }
      this.div_.style.width = this.width_ + "px";
      this.div_.style.left = (pixPosition.x + this.offsetHorizontal_) + "px";
      this.div_.style.height = this.height_ + "px";
      this.div_.style.top = (pixPosition.y + this.offsetVertical_) + "px";
      this.div_.style.display = "block";
    };

    Infobox.prototype.createElement = function() {
      var div, panes;
      panes = this.getPanes();
      div = this.div_;
      if (!div) {
        div = this.div_ = this.template_;
        panes.floatPane.appendChild(div);
        this.panMap();
      } else if (div.parentNode !== panes.floatPane) {
        div.parentNode.removeChild(div);
        panes.floatPane.appendChild(div);
      }
    };

    Infobox.prototype.panMap = function() {
      var bounds, boundsSpan, center, centerX, centerY, degPixelX, degPixelY, iwEastLng, iwHeight, iwNorthLat, iwOffsetX, iwOffsetY, iwSouthLat, iwWestLng, iwWidth, latSpan, longSpan, map, mapDiv, mapEastLng, mapHeight, mapNorthLat, mapSouthLat, mapWestLng, mapWidth, padX, padY, position, shiftLat, shiftLng;
      map = this.map_;
      bounds = map.getBounds();
      if (!bounds) {
        return;
      }
      position = this.latlng_;
      iwWidth = this.width_;
      iwHeight = this.height_;
      iwOffsetX = this.offsetHorizontal_;
      iwOffsetY = this.offsetVertical_;
      padX = 15;
      padY = 40;
      mapDiv = map.getDiv();
      mapWidth = mapDiv.offsetWidth;
      mapHeight = mapDiv.offsetHeight;
      boundsSpan = bounds.toSpan();
      longSpan = boundsSpan.lng();
      latSpan = boundsSpan.lat();
      degPixelX = longSpan / mapWidth;
      degPixelY = latSpan / mapHeight;
      mapWestLng = bounds.getSouthWest().lng();
      mapEastLng = bounds.getNorthEast().lng();
      mapNorthLat = bounds.getNorthEast().lat();
      mapSouthLat = bounds.getSouthWest().lat();
      iwWestLng = position.lng() + (iwOffsetX - padX) * degPixelX;
      iwEastLng = position.lng() + (iwOffsetX + iwWidth + padX) * degPixelX;
      iwNorthLat = position.lat() - (iwOffsetY - padY) * degPixelY;
      iwSouthLat = position.lat() - (iwOffsetY + iwHeight + padY) * degPixelY;
      shiftLng = (iwWestLng < mapWestLng ? mapWestLng - iwWestLng : 0) + (iwEastLng > mapEastLng ? mapEastLng - iwEastLng : 0);
      shiftLat = (iwNorthLat > mapNorthLat ? mapNorthLat - iwNorthLat : 0) + (iwSouthLat < mapSouthLat ? mapSouthLat - iwSouthLat : 0);
      center = map.getCenter();
      centerX = center.lng() - shiftLng;
      centerY = center.lat() - shiftLat;
      map.panTo(new google.maps.LatLng(centerY, centerX));
      google.maps.event.removeListener(this.boundsChangedListener_);
      this.boundsChangedListener_ = null;
    };

    return Infobox;

  })(google.maps.OverlayView);
  return window.Infobox = Infobox;
})();
