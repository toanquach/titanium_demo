(function() {
  var Webservices;
  Webservices = (function() {
    function Webservices() {}

    Webservices.cpt = 0;

    Webservices.webservices = null;

    Webservices.token = "";

    Webservices.callService = function(wsPath, paramsMandatory, paramsOptionnal, callbackSuccess, callbackError) {
      var commonDataPath;
      this.wsPath = wsPath;
      this.paramsMandatory = paramsMandatory;
      this.paramsOptionnal = paramsOptionnal;
      this.callbackSuccess = callbackSuccess;
      this.callbackError = callbackError;
      if (this.webservices == null) {
        commonDataPath = $('#app').data('common-json');
        return this.loadCommsonJson(commonDataPath);
      } else {
        this.buildWebserviceUrl();
        return this.callWebservice();
      }
    };

    Webservices.loadCommsonJson = function(commonDataPath) {
      $.ajaxSetup({
        cache: false
      });
      return $.getJSON(commonDataPath).done(this.successLoadCommonJson).fail(this.failLoadCommonJson);
    };

    Webservices.buildWebserviceUrl = function() {
      var item, paramsKeys, session, _i, _j, _len, _len1, _results;
      session = md5("" + this.webservices.key + this.token);
      this.urlService = "" + this.webservices.path + this.wsPath + "?id=" + this.webservices.id + "&session=" + session;
      paramsKeys = Object.keys(this.paramsMandatory);
      for (_i = 0, _len = paramsKeys.length; _i < _len; _i++) {
        item = paramsKeys[_i];
        this.urlService = this.urlService.replace('#{' + item + '}', this.paramsMandatory[item]);
      }
      paramsKeys = Object.keys(this.paramsOptionnal);
      _results = [];
      for (_j = 0, _len1 = paramsKeys.length; _j < _len1; _j++) {
        item = paramsKeys[_j];
        _results.push(this.urlService += "&" + item + "=" + this.paramsOptionnal[item]);
      }
      return _results;
    };

    Webservices.callWebservice = function() {
      return $.ajax({
        url: this.urlService,
        dataType: 'json',
        error: this.errorWebservice,
        success: this.successWebservice,
        fail: this.failWebservice
      });
    };

    Webservices.successLoadCommonJson = function(data) {
      Webservices.webservices = data.data.webservices;
      Webservices.token = Webservices.webservices.token;
      return Webservices.callService(Webservices.wsPath, Webservices.paramsMandatory, Webservices.paramsOptionnal, Webservices.callbackSuccess, Webservices.callbackError);
    };

    Webservices.failLoadCommonJson = function(error) {
      return Webservices.callbackError();
    };

    Webservices.retryCallWebservice = function(dataObj) {
      if (this.cpt < 5) {
        this.cpt++;
        this.buildWebserviceUrl();
        return this.callWebservice();
      } else {
        return this.callbackError(dataObj.error);
      }
    };

    Webservices.successWebservice = function(dataObj, status) {
      Webservices.token = dataObj.token;
      Bridge.writeToken(Webservices.token);
      if (dataObj.error != null) {
        return Webservices.retryCallWebservice(dataObj);
      } else {
        return Webservices.callbackSuccess(dataObj);
      }
    };

    Webservices.failWebservice = function(dataObj, status, typeError) {
      Webservices.error = dataObj.error;
      Webservices.token = dataObj.token;
      Bridge.writeToken(Webservices.token);
      return Webservices.retryCallWebservice(dataObj);
    };

    Webservices.errorWebservice = function(dataObj, status, typeError) {
      Webservices.error = dataObj.responseJSON.error;
      Webservices.token = dataObj.responseJSON.token;
      Bridge.writeToken(Webservices.token);
      return Webservices.retryCallWebservice(dataObj.responseJSON);
    };

    return Webservices;

  }).call(this);
  return window.Webservices = Webservices;
})();
