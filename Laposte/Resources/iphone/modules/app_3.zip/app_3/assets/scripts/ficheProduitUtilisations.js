var __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

(function() {
  var ficheProduitUtilisations;
  ficheProduitUtilisations = (function(_super) {
    __extends(ficheProduitUtilisations, _super);

    ficheProduitUtilisations.prototype.instance = null;

    function ficheProduitUtilisations() {
      var _this = this;
      $('#app').on('dataloaded.ficheProduitCore', function() {
        return _this.render();
      });
      ficheProduitUtilisations.__super__.constructor.call(this);
      this;
    }

    ficheProduitUtilisations.prototype.render = function() {
      this.sectionData = this.productData.extras.utilisations;
      this.track();
      this.html(this.parseContent(this.sectionData));
      this.title(this.sectionData.title);
      this.img(this.productData.image);
      return this;
    };

    ficheProduitUtilisations.prototype.track = function() {
      return Bridge.tracking(this.productData.tracking.setLevel2, "page", {
        "myPageLabel": "" + this.productData.tracking.myPageLabel,
        "andPageChapter": "" + this.productData.tracking.andPageChapter
      });
    };

    return ficheProduitUtilisations;

  })(ficheProduitCore);
  return $(function() {
    return ko.applyBindings(new ficheProduitUtilisations());
  });
})();
