var CropImageCanvas,
  __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

CropImageCanvas = (function(_super) {
  __extends(CropImageCanvas, _super);

  CropImageCanvas.prototype.stage = null;

  CropImageCanvas.prototype.sens = "horizontal";

  function CropImageCanvas(el, src, callback) {
    var data;
    this.el = el;
    this.handleTick = __bind(this.handleTick, this);
    this.onPressMove = __bind(this.onPressMove, this);
    this.onMouseDown = __bind(this.onMouseDown, this);
    this.onMouseOut = __bind(this.onMouseOut, this);
    this.onMouseOver = __bind(this.onMouseOver, this);
    this.loadImageDone = __bind(this.loadImageDone, this);
    this.imgSrc = src;
    this.callback = callback;
    data = $('#app').data('json');
    CropImageCanvas.__super__.constructor.call(this, data);
  }

  CropImageCanvas.prototype.isSuccessLoaded = function() {
    this.stage = new createjs.Stage(this.el[0]);
    this.stage.enableMouseOver(30);
    this.width = this.stage.canvas.width;
    this.height = this.stage.canvas.height;
    this.init();
    createjs.Ticker.addEventListener("tick", this.handleTick);
    return createjs.Touch.enable(this.stage);
  };

  CropImageCanvas.prototype.init = function() {
    this.container = new createjs.Container();
    this.stage.addChild(this.container);
    if (this.imgSrc.indexOf("data:image") !== -1) {
      return this.loadB64Image();
    } else {
      return this.loadImg();
    }
  };

  CropImageCanvas.prototype.loadImg = function() {
    this.queue = new createjs.LoadQueue(false, "", true);
    this.queue.on("complete", this.loadImageDone, this);
    return this.queue.loadManifest([this.imgSrc]);
  };

  CropImageCanvas.prototype.loadB64Image = function() {
    this.tempImage = new Image();
    this.tempImage.onload = this.loadImageDone;
    return this.tempImage.src = this.imgSrc;
  };

  CropImageCanvas.prototype.loadImageDone = function() {
    this.buildImg();
    this.buildRatioLayer(this.sens);
    this.callback();
    return Bridge.hideLoader();
  };

  CropImageCanvas.prototype.buildImg = function() {
    if (this.imgSrc.indexOf("data:image") !== -1) {
      this.img = new createjs.Bitmap(this.imgSrc);
    } else {
      this.img = new createjs.Bitmap(this.queue.getItem(this.imgSrc).tag);
    }
    this.imgW = this.img.image.width;
    this.imgH = this.img.image.height;
    this.ratioImg = this.imgW / this.imgH;
    this.ratioPostcard = this.getData().crop.final_width / this.getData().crop.final_height;
    if (this.imgW > this.imgH) {
      if (this.ratioImg < this.ratioPostcard) {
        this.sc = this.width / this.imgW;
      } else {
        this.sc = this.height / this.imgH;
      }
    } else {
      if ((this.imgH / this.imgW) <= this.ratioPostcard) {
        this.sc = this.height / this.imgH;
      } else {
        this.sc = this.height / this.imgH * ((this.imgH / this.imgW) / this.ratioPostcard);
      }
    }
    this.img.scaleX = this.sc;
    this.img.scaleY = this.sc;
    this.container.addChild(this.img);
    this.container.x = this.width - (this.imgW * this.sc) >> 1;
    return this.container.y = this.height - (this.imgH * this.sc) >> 1;
  };

  CropImageCanvas.prototype.buildRatioLayer = function(sens) {
    var diffRatio, g, h, w;
    this.sens = sens;
    this.removeRatioLayers();
    g = new createjs.Graphics();
    g.beginFill("#f00");
    if (this.sens === "horizontal") {
      w = this.container.getBounds().width;
      if (w > this.getData().crop.final_width) {
        w = this.getData().crop.final_width;
      }
      h = w / this.ratioPostcard;
    } else {
      diffRatio = this.height / this.getData().crop.final_height;
      h = this.container.getBounds().height * diffRatio;
      if (h > this.getData().crop.final_height * diffRatio) {
        h = this.getData().crop.final_height * diffRatio;
      }
      w = h / this.ratioPostcard;
    }
    g.drawRect(0, 0, w, h);
    g.endFill();
    this.layer = new createjs.Shape(g);
    this.layer.alpha = 0.01;
    this.layer.setBounds(0, 0, w, h);
    this.layer.x = this.container.getBounds().width - this.layer.getBounds().width >> 1;
    this.layer.y = (this.container.getBounds().height - this.layer.getBounds().height) >> 1;
    this.container.addChild(this.layer);
    this.layer.addEventListener("mouseover", this.onMouseOver);
    this.layer.addEventListener("mouseout", this.onMouseOut);
    this.layer.addEventListener("mousedown", this.onMouseDown);
    this.layer.addEventListener("pressmove", this.onPressMove);
    return this.buildBorderLayers();
  };

  CropImageCanvas.prototype.buildBorderLayers = function() {
    var g, h, w;
    g = new createjs.Graphics();
    g.beginFill("#fff");
    if (this.sens === "horizontal") {
      w = this.container.getBounds().width;
      h = this.layer.y;
    } else {
      w = this.layer.x;
      h = this.container.getBounds().height;
    }
    g.drawRect(0, 0, w, h);
    g.endFill();
    this.topLeftLayer = new createjs.Shape(g);
    this.topLeftLayer.alpha = 0.5;
    this.topLeftLayer.setBounds(0, 0, w, h);
    if (this.sens === "horizontal") {
      this.topLeftLayer.x = this.layer.x;
      this.topLeftLayer.y = 0;
    } else {
      this.topLeftLayer.x = 0;
      this.topLeftLayer.y = this.layer.y;
    }
    this.container.addChild(this.topLeftLayer);
    this.bottomRightLayer = new createjs.Shape(g);
    this.bottomRightLayer.alpha = 0.5;
    this.bottomRightLayer.setBounds(0, 0, w, h);
    if (this.sens === "horizontal") {
      this.bottomRightLayer.x = this.layer.x;
      this.bottomRightLayer.y = this.layer.y + this.layer.getBounds().height;
    } else {
      this.bottomRightLayer.x = this.layer.x + this.layer.getBounds().width;
      this.bottomRightLayer.y = this.layer.y;
    }
    return this.container.addChild(this.bottomRightLayer);
  };

  CropImageCanvas.prototype.removeRatioLayers = function() {
    if (this.layer != null) {
      this.container.removeChild(this.layer);
      this.layer = null;
    }
    if (this.topLeftLayer != null) {
      this.container.removeChild(this.topLeftLayer);
      this.topLeftLayer = null;
    }
    if (this.bottomRightLayer != null) {
      this.container.removeChild(this.bottomRightLayer);
      return this.bottomRightLayer = null;
    }
  };

  CropImageCanvas.prototype.checkQuality = function() {
    var sc;
    return sc = {
      scW: this.getData().crop.final_width / this.layer.getBounds().width,
      scH: this.getData().crop.final_height / this.layer.getBounds().height
    };
  };

  CropImageCanvas.prototype.generateCropImage = function(callback) {
    var crop, newContainer, sc;
    newContainer = new createjs.Container();
    crop = this.img.clone();
    if (this.sens === "horizontal") {
      crop.x = -this.layer.x;
      crop.y = -this.layer.y;
      newContainer.addChildAt(crop, 0);
      newContainer.setBounds(0, 0, crop.getBounds().width * this.sc, crop.getBounds().height * this.sc);
      sc = this.getData().crop.final_width / this.layer.getBounds().width;
      newContainer.cache(0, 0, this.layer.getBounds().width, this.layer.getBounds().height, sc);
    } else {
      crop.x = -this.layer.y;
      crop.y = this.layer.x + this.layer.getBounds().width;
      crop.rotation = -90;
      newContainer.addChildAt(crop, 0);
      newContainer.setBounds(0, 0, crop.getBounds().width * this.sc, crop.getBounds().height * this.sc);
      sc = this.getData().crop.final_width / this.layer.getBounds().width;
      newContainer.cache(0, 0, this.layer.getBounds().height, this.layer.getBounds().width, sc);
    }
    this.cropImageSrc = newContainer.getCacheDataURL();
    return callback();
  };

  CropImageCanvas.prototype.onMouseOver = function(e) {
    return e.currentTarget.cursor = "pointer";
  };

  CropImageCanvas.prototype.onMouseOut = function(e) {
    return e.currentTarget.cursor = "auto";
  };

  CropImageCanvas.prototype.onMouseDown = function(e) {
    if (this.sens === "horizontal") {
      this.currentY = e.localY;
      this.minY = -this.container.y;
      return this.maxY = this.container.getBounds().height + this.container.y;
    } else {
      this.currentX = e.localX;
      this.minX = 0;
      this.maxX = this.container.getBounds().width;
      if (this.container.x < 0) {
        this.minX = -this.container.x;
        return this.maxX = this.container.getBounds().width + this.container.x;
      }
    }
  };

  CropImageCanvas.prototype.onPressMove = function(e) {
    var layer, newX, newY;
    layer = e.currentTarget;
    if (this.sens === "horizontal") {
      newY = this.currentY - e.localY;
      layer.y -= newY;
      if (layer.y < this.minY) {
        layer.y = this.minY;
      }
      if (layer.y + layer.getBounds().height > this.maxY) {
        layer.y = this.maxY - layer.getBounds().height;
      }
    } else {
      newX = this.currentX - e.localX;
      layer.x -= newX;
      if (layer.x < this.minX) {
        layer.x = this.minX;
      }
      if (layer.x + layer.getBounds().width > this.maxX) {
        layer.x = this.maxX - layer.getBounds().width;
      }
    }
    if (this.sens === "horizontal") {
      this.topLeftLayer.scaleY = this.layer.y / this.topLeftLayer.getBounds().height;
      this.bottomRightLayer.scaleY = 2 - this.topLeftLayer.scaleY;
      return this.bottomRightLayer.y = this.layer.y + this.layer.getBounds().height;
    } else {
      this.topLeftLayer.scaleX = this.layer.x / this.topLeftLayer.getBounds().width;
      this.bottomRightLayer.scaleX = 2 - this.topLeftLayer.scaleX;
      return this.bottomRightLayer.x = this.layer.x + this.layer.getBounds().width;
    }
  };

  CropImageCanvas.prototype.handleTick = function() {
    return this.stage.update();
  };

  return CropImageCanvas;

})(ManifestLoader);
