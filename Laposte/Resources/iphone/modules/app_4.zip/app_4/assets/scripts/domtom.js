var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

(function() {
  var Domtom;
  Domtom = (function(_super) {
    __extends(Domtom, _super);

    Domtom.prototype.instance = null;

    function Domtom() {
      this.successLoadParams = __bind(this.successLoadParams, this);
      this.chooseDest = __bind(this.chooseDest, this);
      this.successLoad = __bind(this.successLoad, this);
      var data;
      this.links = ko.observableArray();
      data = $('#app').data('json');
      Domtom.__super__.constructor.call(this, data);
    }

    Domtom.prototype.isSuccessLoaded = function() {
      return Helpers.loadJson(Helpers.convertAbsoluteToRelativeJsonPath(this.getData().json.domtom)).done(this.successLoad).fail(this.failLoad);
    };

    Domtom.prototype.successLoad = function(data) {
      Domtom.getInstance(this);
      this.displayLinks(data.liste_pays[1].pays);
      this.fillLabels();
      Helpers.forceImgToRetina($('img'));
      Helpers.loadJson(Helpers.convertAbsoluteToRelativeJsonPath(this.getData().json.params)).done(this.successLoadParams).fail(this.failLoadParams);
      $('body').on('click', 'a', this.chooseDest);
      return Bridge.hideLoader();
    };

    Domtom.prototype.displayLinks = function(data) {
      var i, _i, _ref, _results;
      _results = [];
      for (i = _i = 0, _ref = data.length; 0 <= _ref ? _i < _ref : _i > _ref; i = 0 <= _ref ? ++_i : --_i) {
        _results.push(this.links.push(new this.displayLink(data[i])));
      }
      return _results;
    };

    Domtom.prototype.displayLink = function(data) {
      this.label = data.libelle;
      if (Helpers.getUrlVar("step") != null) {
        this.link = "app_4/views/steps.html?step=" + (Helpers.getUrlVar("step"));
      } else {
        this.link = "app_4/views/steps.html";
      }
      return this.value = JSON.stringify({
        "dom_com": data.id,
        "dom_tom": data.id
      });
    };

    Domtom.prototype.chooseDest = function(e) {
      var destination;
      e.preventDefault();
      this.redirection = $(e.currentTarget).attr('href');
      $.extend(this.params.params, $(e.currentTarget).data('value'));
      destination = $(e.currentTarget).find('.label').text();
      $.extend(this.params.summary, {
        "destination": this.getLabel("destinationPrefix") + destination
      });
      $.extend(this.params.favorite, {
        "destination": destination
      });
      if (Helpers.isWebApp()) {
        return Bridge.writeJSON(this.getData().json.params, this.params, "Domtom.gotoNext()", false, "");
      } else {
        return Domtom.gotoNext();
      }
    };

    Domtom.prototype.successLoadParams = function(data) {
      return this.params = data;
    };

    Domtom.getInstance = function(_this) {
      if (this.instance == null) {
        this.instance = _this;
      }
      return this.instance;
    };

    Domtom.gotoNext = function() {
      return Bridge.redirect(this.instance.redirection);
    };

    return Domtom;

  })(ManifestLoader);
  window.Domtom = Domtom;
  return $(function() {
    return ko.applyBindings(new Domtom());
  });
})();
