(function() {
  var Bridge;
  Bridge = (function() {
    function Bridge() {}

    Bridge.writeJSON = function(nameFileJSON, dataObj, callback, boolFav, typeFav) {
      var bridgeURL, bridgeURLEncode, strDataObj;
      if (boolFav == null) {
        boolFav = false;
      }
      if (typeFav == null) {
        typeFav = "";
      }
      if (Helpers.isWebApp()) {
        strDataObj = JSON.stringify(dataObj);
        bridgeURL = "{\"typeFav\": \"" + typeFav + "\", \"nameFileJSON\": \"" + nameFileJSON + "\", \"callback\": \"" + callback + "\", \"boolFav\": \"" + boolFav + "\", \"dataObj\": " + strDataObj + "}";
        bridgeURLEncode = "#writejson?" + (encodeURIComponent(bridgeURL));
        setTimeout((function() {
          window.location = bridgeURLEncode;
        }), 200);
      }
    };

    Bridge.setFavorite = function(id, dataObj, typeFavorite, callback, currentUrl) {
      var bridgeURL, bridgeURLEncode, strDataObj;
      if (currentUrl == null) {
        currentUrl = Helpers.getCurrentPage();
      }
      if (Helpers.isWebApp()) {
        strDataObj = JSON.stringify(dataObj);
        bridgeURL = "{\"id\": \"" + id + "\", \"dataObj\": " + strDataObj + ", \"typeFavorite\": \"" + typeFavorite + "\", \"callback\": \"" + callback + "\", \"urldetailpage\": \"" + currentUrl + "\"}";
        bridgeURLEncode = "#setfavorite?" + (encodeURIComponent(bridgeURL));
        window.location = bridgeURLEncode;
      }
    };

    Bridge.removeFavorite = function(id, typeFavorite, callback) {
      var bridgeURL, bridgeURLEncode;
      if (Helpers.isWebApp()) {
        bridgeURL = "{\"id\": \"" + id + "\", \"typeFavorite\": \"" + typeFavorite + "\", \"callback\": \"" + callback + "\"}";
        bridgeURLEncode = "#removefavorite?" + (encodeURIComponent(bridgeURL));
        window.location = bridgeURLEncode;
      }
    };

    Bridge.alertPopin = function(title, message, btnObj1, btnObj2) {
      var bridgeURL, bridgeURLEncode;
      if (btnObj2 == null) {
        btnObj2 = {
          "title": "",
          "callback": ""
        };
      }
      if (Helpers.isWebApp()) {
        bridgeURL = "{\"title\": \"" + title + "\", \"message\": \"" + message + "\", \"btnObj1\": " + (JSON.stringify(btnObj1)) + ", \"btnObj2\": " + (JSON.stringify(btnObj2)) + "}";
        bridgeURLEncode = "#alertpopin?" + (encodeURIComponent(bridgeURL));
        window.location = bridgeURLEncode;
      } else {
        console.log("{\"title\": \"" + title + "\", \"message\": \"" + message + "\", \"btnObj1\": " + (JSON.stringify(btnObj1)) + ", \"btnObj2\": " + (JSON.stringify(btnObj2)) + "}");
      }
    };

    Bridge.displayPopin = function(nameViewURL, callback, title) {
      var bridgeURL, bridgeURLEncode, params, url;
      if (callback == null) {
        callback = null;
      }
      if (title == null) {
        title = null;
      }
      if (Helpers.isWebApp()) {
        bridgeURL = "{\"nameViewURL\":\"" + nameViewURL + "\",\"callback\":\"" + callback + "\",\"title\":\"" + title + "\"}";
        bridgeURLEncode = "#displaypopin?" + (encodeURIComponent(bridgeURL));
        window.location = bridgeURLEncode;
      } else {
        params = nameViewURL.split("/");
        url = params[params.length - 1];
        window.location = url;
      }
    };

    Bridge.displayLoader = function() {
      var bridgeURL;
      if (Helpers.isWebApp()) {
        bridgeURL = "#displayloader?";
        window.location = bridgeURL;
      }
    };

    Bridge.hideLoader = function(changePage) {
      var bridgeURLEncode;
      if (changePage == null) {
        changePage = true;
      }
      if (Helpers.isWebApp()) {
        changePage = "{\"changePage\":\"" + changePage + "\"}";
        bridgeURLEncode = "#hideloader?" + (encodeURIComponent(changePage));
        window.location = bridgeURLEncode;
      }
    };

    Bridge.navigationTitle = function(title) {
      var bridgeURLEncode;
      if (Helpers.isWebApp()) {
        bridgeURLEncode = "#navigationtitle?" + (encodeURIComponent(title));
        setTimeout((function() {
          window.location = bridgeURLEncode;
        }), 50);
      }
    };

    Bridge.update = function() {
      if (Helpers.isWebApp()) {
        window.location.reload();
      }
    };

    Bridge.writeToken = function(token) {
      var bridgeURLEncode;
      if (Helpers.isWebApp()) {
        bridgeURLEncode = "#writetoken?" + (encodeURIComponent(token));
        setTimeout((function() {
          window.location = bridgeURLEncode;
        }), 100);
      }
    };

    Bridge.writeTempJSON = function(dataObj) {
      var bridgeURLEncode, strDataObj;
      if (Helpers.isWebApp()) {
        strDataObj = JSON.stringify(dataObj);
        bridgeURLEncode = "#writetempjson?" + (encodeURIComponent(strDataObj));
        window.location = bridgeURLEncode;
      }
    };

    Bridge.removeTempJSON = function() {
      var bridgeURL;
      if (Helpers.isWebApp()) {
        bridgeURL = "#removetempjson?";
        window.location = bridgeURL;
      }
    };

    Bridge.tracking = function(setLevel2, type, dataObj, clickType) {
      var bridgeURL, bridgeURLEncode, strDataObj;
      if (clickType == null) {
        clickType = '\"\"';
      }
      strDataObj = JSON.stringify(dataObj);
      bridgeURL = "{\"setLevel2\": \"" + setLevel2 + "\", \"type\": \"" + type + "\", \"dataObj\": " + strDataObj + ", \"clickType\": " + clickType + "}";
      if (Helpers.isWebApp()) {
        bridgeURLEncode = "#tracking?" + (encodeURIComponent(bridgeURL));
        setTimeout((function() {
          window.location = bridgeURLEncode;
        }), 400);
      } else {
        console.log("#tracking?" + bridgeURL);
      }
    };

    Bridge.redirect = function(lien) {
      var bridgeURL, bridgeURLEncode;
      if (Helpers.isWebApp()) {
        bridgeURL = "{\"link\": \"" + lien + "\"}";
        bridgeURLEncode = "#redirect?" + (encodeURIComponent(bridgeURL));
        window.location = bridgeURLEncode;
      } else {
        window.location = lien.split('/').pop();
      }
    };

    Bridge.switchModule = function(module, path) {
      var bridgeURL, bridgeURLEncode;
      if (Helpers.isWebApp()) {
        bridgeURL = "{\"module\": \"" + module + "\",\"path\": \"" + path + "\"}";
        bridgeURLEncode = "#switchmodule?" + (encodeURIComponent(bridgeURL));
        window.location = bridgeURLEncode;
      } else {
        window.location = "?" + path;
      }
    };

    Bridge.externalLink = function(link) {
      var bridgeURL, bridgeURLEncode;
      if (Helpers.isWebApp()) {
        bridgeURL = "{\"link\": \"" + link + "\"}";
        bridgeURLEncode = "#externallink?" + (encodeURIComponent(bridgeURL));
        return window.location = bridgeURLEncode;
      } else {
        return window.location = link;
      }
    };

    Bridge.addNotif = function(type, id) {
      var bridgeURL, bridgeURLEncode;
      if (Helpers.isWebApp()) {
        bridgeURL = "{\"type\": \"" + type + "\" , \"colisid\": \"" + id + "\"}";
        bridgeURLEncode = "#externallink?" + (encodeURIComponent(bridgeURL));
        return window.location = bridgeURLEncode;
      } else {
        bridgeURL = "{\"type\": \"" + type + "\" , \"colisid\": \"" + id + "\"}";
        return console.log(bridgeURL);
      }
    };

    Bridge.getUserLocation = function(callback) {
      var bridgeURL, bridgeURLEncode;
      bridgeURL = "{\"callback\": \"" + callback + "\"}";
      bridgeURLEncode = "#getuserlocation?" + (encodeURIComponent(bridgeURL));
      return window.location = bridgeURLEncode;
    };

    Bridge.socialNetworkCnx = function(networkUrl, appUrl) {
      var bridgeURL, bridgeURLEncode;
      if (Helpers.isWebApp()) {
        bridgeURL = "{\"networkurl\": \"" + networkUrl + "\", \"appurl\": \"" + appUrl + "\"}";
        bridgeURLEncode = "#socialnetworkcnx?" + (encodeURIComponent(bridgeURL));
        window.location = bridgeURLEncode;
      } else {
        window.location = networkUrl;
      }
    };

    Bridge.openCamera = function(appUrl) {
      var bridgeURL, bridgeURLEncode;
      if (Helpers.isWebApp()) {
        bridgeURL = "{\"appurl\": \"" + appUrl + "\"}";
        bridgeURLEncode = "#opencamera?" + (encodeURIComponent(bridgeURL));
        window.location = bridgeURLEncode;
      } else {
        console.log("Bridge.openCamera(" + appUrl + ")");
      }
    };

    Bridge.openPhotoLibrary = function(appUrl) {
      var bridgeURL, bridgeURLEncode;
      if (Helpers.isWebApp()) {
        bridgeURL = "{\"appurl\": \"" + appUrl + "\"}";
        bridgeURLEncode = "#openphotolibrary?" + (encodeURIComponent(bridgeURL));
        window.location = bridgeURLEncode;
      } else {
        console.log("Bridge.openPhotoLibrary(" + appUrl + ")");
      }
    };

    Bridge.navBack = function(type) {
      var bridgeURL, bridgeURLEncode;
      if (Helpers.isWebApp) {
        bridgeURL = "{\"type\": \"" + type + "\"}";
        bridgeURLEncode = "#navBack?" + (encodeURIComponent(bridgeURL));
        window.location = bridgeURLEncode;
      } else {
        window.history.back();
      }
    };

    return Bridge;

  })();
  return window.Bridge = Bridge;
})();
