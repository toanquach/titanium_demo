var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

(function() {
  var MapList;
  MapList = (function(_super) {
    __extends(MapList, _super);

    function MapList() {
      this.clickFavoriteIconHandler = __bind(this.clickFavoriteIconHandler, this);
      this.mouseOutFavoriteIconHandler = __bind(this.mouseOutFavoriteIconHandler, this);
      this.mouseOverFavoriteIconHandler = __bind(this.mouseOverFavoriteIconHandler, this);
      this.failLoadWriteJson = __bind(this.failLoadWriteJson, this);
      this.successLoadWriteJson = __bind(this.successLoadWriteJson, this);
      this.failLoadList = __bind(this.failLoadList, this);
      this.successLoadList = __bind(this.successLoadList, this);
      var data;
      this.offices = ko.observableArray();
      data = $('#app').data('json');
      MapList.__super__.constructor.call(this, data);
    }

    MapList.prototype.isSuccessLoaded = function() {
      var params;
      MapList.getInstance(this);
      this.getVars = Helpers.getUrlVars();
      if (this.getVars !== null) {
        if ((Helpers.getUrlVar('lat') != null) && (Helpers.getUrlVar('lng') != null)) {
          return Webservices.callService(this.getData().webservices.searchByPos, {
            lat: Helpers.getUrlVar("lat"),
            lng: Helpers.getUrlVar("lng")
          }, {}, this.successLoadList, this.failLoadList);
        } else {
          params = {};
          if (Helpers.getUrlVar('code_postal') != null) {
            params.code_postal = Helpers.getUrlVar('code_postal');
          }
          if (Helpers.getUrlVar('ville') != null) {
            params.ville = Helpers.getUrlVar('ville');
          }
          return Webservices.callService(this.getData().webservices.searchPosteOffices, {}, params, this.successLoadList, this.failLoadList);
        }
      } else {
        return this.failLoadList();
      }
    };

    MapList.prototype.successLoadList = function(data) {
      if (Helpers.isWebApp()) {
        return Bridge.writeJSON(this.getData().json.map, data, "MapList.readyParseData()", true, "LOC_BP");
      } else {
        return MapList.readyParseData();
      }
    };

    MapList.prototype.failLoadList = function(error) {
      Bridge.hideLoader(false);
      if (error != null) {
        return Bridge.alertPopin("", this.getLabel("error_loading_page"), {
          "title": "OK",
          "callback": ""
        });
      } else {
        return Bridge.alertPopin("", this.getLabel("error_loading_page"), {
          "title": "OK",
          "callback": ""
        });
      }
    };

    MapList.prototype.successLoadWriteJson = function(data) {
      var newTitle;
      this.dataOffices = data;
      this.dataList = this.dataOffices.bureaux;
      this.favorite = data.favorite;
      newTitle = this.dataList.length;
      if (this.dataList.length === 1) {
        newTitle += " " + (this.getLabel("result"));
      } else {
        newTitle += " " + (this.getLabel("results"));
      }
      this.setOfficesList();
      this.setDetailsInfos();
      Bridge.hideLoader();
      Bridge.navigationTitle(newTitle);
      return Bridge.tracking(3, "page", {
        "myPageLabel": "liste_de_bureaux",
        "andPageChapter": "bureau_de_poste"
      });
    };

    MapList.prototype.failLoadWriteJson = function(error) {
      return Bridge.alertPopin("", this.getLabel("error_loading_page"), {
        "title": "OK",
        "callback": ""
      });
    };

    MapList.prototype.setOfficesList = function() {
      var i, _i, _ref, _results;
      this.nbOffices = this.dataList.length;
      _results = [];
      for (i = _i = 0, _ref = this.nbOffices; 0 <= _ref ? _i < _ref : _i > _ref; i = 0 <= _ref ? ++_i : --_i) {
        _results.push(this.offices.push(new this.DisplayOffice(this.dataList[i], this)));
      }
      return _results;
    };

    MapList.prototype.DisplayOffice = function(data, that) {
      this.name = data.libelleSite;
      this.address = data.adresse;
      this.city = "" + data.codePostal + " " + data.localite;
      if (data.fermeture) {
        return this.close = true;
      } else {
        return this.close = false;
      }
    };

    MapList.prototype.setDetailsInfos = function() {
      var data, detailLink, favoriteLink, i, office, urlLink, _i, _ref, _results;
      _results = [];
      for (i = _i = 0, _ref = this.nbOffices; 0 <= _ref ? _i < _ref : _i > _ref; i = 0 <= _ref ? ++_i : --_i) {
        office = $('.office-li')[i];
        data = this.dataList[i];
        this.checkOpenClose(office, data);
        detailLink = $(office).find('a.detail-link');
        urlLink = detailLink.attr('href');
        detailLink.attr('href', "" + urlLink + "?code_site=" + data.codeSite);
        favoriteLink = $(office).find('a.favorite');
        favoriteLink.attr('data-index', i);
        if (this.favorite.indexOf(data.codeSite) !== -1) {
          favoriteLink.find('.star').addClass('icon-star-active');
        } else {
          favoriteLink.find('.star').addClass('icon-star-inactive');
        }
        favoriteLink.on('mouseover', this.mouseOverFavoriteIconHandler);
        favoriteLink.on('mouseout', this.mouseOutFavoriteIconHandler);
        _results.push(favoriteLink.on('click', this.clickFavoriteIconHandler));
      }
      return _results;
    };

    MapList.prototype.mouseOverFavoriteIconHandler = function(e) {
      return $(e.currentTarget).css('cursor', 'pointer');
    };

    MapList.prototype.mouseOutFavoriteIconHandler = function(e) {
      return $(e.currentTarget).css('cursor', 'pointer');
    };

    MapList.prototype.clickFavoriteIconHandler = function(e) {
      var favoriteLink, index;
      favoriteLink = $(e.currentTarget);
      index = favoriteLink.data('index');
      if (favoriteLink.find('.star').hasClass('icon-star-active')) {
        return this.removeFavorite(favoriteLink, index);
      } else {
        return this.addFavorite(favoriteLink, index);
      }
    };

    MapList.prototype.addFavorite = function(favoriteLink, index) {
      this.favoriteLink = favoriteLink;
      if (Helpers.isWebApp()) {
        return Bridge.setFavorite(this.dataList[index].codeSite, this.dataList[index], "LOC_BP", "MapList.callbackAddFavorite()", "" + (Helpers.getCurrentPage().replace("mapList", "mapDetailsOffice").split('?')[0]) + "?code_site=" + this.dataList[index].codeSite);
      } else {
        return MapList.callbackAddFavorite();
      }
    };

    MapList.prototype.removeFavorite = function(favoriteLink, index) {
      var codeSite;
      this.favoriteLink = favoriteLink;
      if (Helpers.isWebApp()) {
        codeSite = this.dataList[index].codeSite;
        return Bridge.removeFavorite(codeSite, "LOC_BP", "MapList.callbackRemoveFavorite()");
      } else {
        return MapList.callbackRemoveFavorite();
      }
    };

    MapList.prototype.checkOpenClose = function(office, data) {
      var closeData, containerCloseOffice, diffTime, openCloseOffice, strCloseTime, strOpenTime;
      openCloseOffice = $(office).find('.open-close-office');
      diffTime = Helpers.calculateDiffTime(data.etat.date, data.etat.dateChangement);
      if (data.etat.ouvert) {
        openCloseOffice.find('.border-open-close-office .open-close-office-label').html(this.getLabel('open'));
        openCloseOffice.find('.border-open-close-office').addClass('open-office');
        if (diffTime !== "") {
          strCloseTime = this.formatTime(diffTime);
          openCloseOffice.find('.close-time-office').html("" + (this.getLabel('close_in')) + " " + strCloseTime);
        }
      } else {
        openCloseOffice.find('.border-open-close-office .open-close-office-label').html(this.getLabel('close'));
        openCloseOffice.find('.border-open-close-office').removeClass('open-office');
        if (diffTime !== "") {
          strOpenTime = this.formatTime(diffTime);
          openCloseOffice.find('.close-time-office').html("" + (this.getLabel('open_in')) + " " + strOpenTime);
        }
      }
      if (data.fermeture) {
        containerCloseOffice = $(office).find('.container-office-closed');
        closeData = data.fermeture;
        if (closeData.debutPeriodeJour === closeData.finPeriodeJour) {
          if (closeData.debutPeriodeHeure === "00:00:00" && closeData.finPeriodeHeure === "23:59:00") {
            return containerCloseOffice.find('.closing-line').html("" + (this.getLabel('close_exceptionnal')) + " " + closeData.debutPeriodeJour);
          } else {
            return containerCloseOffice.find('.closing-line').html("" + (this.getLabel('close_exceptionnal')) + " " + closeData.debutPeriodeJour + "<br>" + (this.getLabel('from_hour')) + " " + (closeData.debutPeriodeHeure.substr(0, 5)) + " " + (this.getLabel('to_hour')) + " " + (closeData.finPeriodeHeure.substr(0, 5)));
          }
        } else {
          return containerCloseOffice.find('.closing-line').html("" + (this.getLabel('close_temp_1')) + " " + closeData.debutPeriodeJour + " " + (this.getLabel('to_hour')) + " " + (closeData.debutPeriodeHeure.substr(0, 5)) + "<br>" + (this.getLabel('close_temp_2')) + " " + closeData.finPeriodeJour + " " + (this.getLabel('to_hour')) + " " + (closeData.finPeriodeHeure.substr(0, 5)));
        }
      }
    };

    MapList.prototype.formatTime = function(time) {
      var strTime;
      strTime = "";
      if (time.day === 0) {
        strTime = "" + time.hour + (this.getLabel('hour')) + time.min + (this.getLabel('minute'));
      } else if (time.day === 1) {
        strTime = "" + time.day + " " + (this.getLabel('day')) + " " + time.hour + (this.getLabel('hour')) + time.min + (this.getLabel('minute'));
      } else {
        strTime = "" + time.day + " " + (this.getLabel('days')) + " " + time.hour + (this.getLabel('hour')) + time.min + (this.getLabel('minute'));
      }
      return strTime;
    };

    MapList.getInstance = function(_this) {
      if (this.instance == null) {
        this.instance = _this;
      }
      return this.instance;
    };

    MapList.readyParseData = function() {
      var writeJsonPath;
      writeJsonPath = Helpers.convertAbsoluteToRelativeJsonPath(this.instance.getData().json.map);
      return Helpers.loadJson(writeJsonPath).done(this.instance.successLoadWriteJson).fail(this.instance.failLoadWriteJson);
    };

    MapList.callbackAddFavorite = function() {
      this.instance.favoriteLink.find('.star').removeClass('icon-star-inactive');
      return this.instance.favoriteLink.find('.star').addClass('icon-star-active');
    };

    MapList.callbackRemoveFavorite = function() {
      this.instance.favoriteLink.find('.star').removeClass('icon-star-active');
      return this.instance.favoriteLink.find('.star').addClass('icon-star-inactive');
    };

    return MapList;

  })(ManifestLoader);
  $(function() {
    return ko.applyBindings(new MapList());
  });
  return window.MapList = MapList;
})();
