var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

(function() {
  var International;
  International = (function(_super) {
    __extends(International, _super);

    International.prototype.instance = null;

    function International() {
      this.submitHandler = __bind(this.submitHandler, this);
      this.successLoadParams = __bind(this.successLoadParams, this);
      this.chooseDest = __bind(this.chooseDest, this);
      this.successLoad = __bind(this.successLoad, this);
      var data;
      this.links = ko.observableArray();
      this.filter = ko.observable('');
      this.filteredList = ko.computed(function() {
        var filter;
        filter = this.filter().toLowerCase();
        return ko.utils.arrayFilter(this.links(), function(link) {
          if (!!link.label.toLowerCase().match("^" + filter)) {
            return link.show(true);
          } else {
            return link.show(false);
          }
        });
      }, this);
      data = $('#app').data('json');
      International.__super__.constructor.call(this, data);
    }

    International.prototype.isSuccessLoaded = function() {
      return Helpers.loadJson(Helpers.convertAbsoluteToRelativeJsonPath(this.getData().json.international)).done(this.successLoad).fail(this.failLoad);
    };

    International.prototype.successLoad = function(data) {
      International.getInstance(this);
      this.displayLinks(data.liste_pays[1].pays);
      this.fillLabels();
      $('form').on('submit', this.submitHandler);
      Helpers.forceImgToRetina($('img'));
      Helpers.loadJson(Helpers.convertAbsoluteToRelativeJsonPath(this.getData().json.params)).done(this.successLoadParams).fail(this.failLoadParams);
      $('body').on('click', 'a', this.chooseDest);
      return Bridge.hideLoader();
    };

    International.prototype.displayLinks = function(data) {
      var i, _i, _ref, _results;
      _results = [];
      for (i = _i = 0, _ref = data.length; 0 <= _ref ? _i < _ref : _i > _ref; i = 0 <= _ref ? ++_i : --_i) {
        _results.push(this.links.push(new this.displayLink(data[i])));
      }
      return _results;
    };

    International.prototype.displayLink = function(data) {
      var step;
      this.label = data.libelle.toUpperCase();
      step = Helpers.getUrlVar("step");
      if (step != null) {
        this.link = "app_4/views/steps.html?step=" + step;
      } else {
        this.link = "app_4/views/steps.html";
      }
      this.value = JSON.stringify({
        "etranger": data.id
      });
      this.show = ko.observable(true);
    };

    International.prototype.chooseDest = function(e) {
      var destination;
      e.preventDefault();
      this.redirection = $(e.currentTarget).attr('href');
      $.extend(this.params.params, $(e.currentTarget).data('value'));
      destination = $(e.currentTarget).find('.label').text();
      $.extend(this.params.summary, {
        "destination": this.getLabel("destinationPrefix") + destination
      });
      $.extend(this.params.favorite, {
        "destination": destination
      });
      if (Helpers.isWebApp()) {
        return Bridge.writeJSON(this.getData().json.params, this.params, "International.gotoNext()", false, "");
      } else {
        return International.gotoNext();
      }
    };

    International.prototype.successLoadParams = function(data) {
      return this.params = data;
    };

    International.prototype.submitHandler = function(e) {
      e.preventDefault();
      return $(e.currentTarget).find('input').blur();
    };

    International.getInstance = function(_this) {
      if (this.instance == null) {
        this.instance = _this;
      }
      return this.instance;
    };

    International.gotoNext = function() {
      return Bridge.redirect(this.instance.redirection);
    };

    return International;

  })(ManifestLoader);
  window.International = International;
  return $(function() {
    return ko.applyBindings(new International());
  });
})();
