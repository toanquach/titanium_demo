var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

(function() {
  var ficheProduitCore;
  ficheProduitCore = (function(_super) {
    __extends(ficheProduitCore, _super);

    ficheProduitCore.prototype.instance = null;

    function ficheProduitCore() {
      this.successLoad = __bind(this.successLoad, this);
      var data;
      this.dataType = null;
      this.img = ko.observable();
      this.html = ko.observable();
      this.code = ko.observable();
      this.title = ko.observable();
      data = $('#app').data('json');
      ficheProduitCore.__super__.constructor.call(this, data);
    }

    ficheProduitCore.prototype.isSuccessLoaded = function() {
      this.codeStr = Helpers.getUrlVar("code");
      this.code(this.codeStr);
      return Helpers.loadJson(Helpers.convertAbsoluteToRelativeJsonPath(this.getData().json.ficheProduit)).done(this.successLoad).fail(this.failLoad);
    };

    ficheProduitCore.prototype.successLoad = function(data) {
      var product, _i, _len, _ref;
      _ref = data.products;
      for (_i = 0, _len = _ref.length; _i < _len; _i++) {
        product = _ref[_i];
        if (product.id === this.codeStr) {
          this.productData = product;
        }
      }
      if (!this.productData) {
        return console.error("Product data not found, code used is " + this.codeStr);
      }
      this.fillLabels();
      $('#app').trigger('dataloaded.ficheProduitCore');
      Helpers.forceImgToRetina($('img'));
      return Bridge.hideLoader();
    };

    ficheProduitCore.prototype.parseLine = function(o, tag, html) {
      var d, _i, _len, _ref, _ref1;
      if (html == null) {
        html = [];
      }
      if (!(o != null ? (_ref = o.data) != null ? _ref.length : void 0 : void 0)) {
        return "";
      }
      _ref1 = o.data;
      for (_i = 0, _len = _ref1.length; _i < _len; _i++) {
        d = _ref1[_i];
        html.push("<" + tag + ">" + d.label + (this.parseContent(d)) + "</" + tag + ">");
      }
      return html.join("");
    };

    ficheProduitCore.prototype.parseContent = function(o, html) {
      var c, _i, _len, _ref, _ref1;
      if (html == null) {
        html = [];
      }
      if (!(o != null ? (_ref = o.content) != null ? _ref.length : void 0 : void 0)) {
        return "";
      }
      _ref1 = o.content;
      for (_i = 0, _len = _ref1.length; _i < _len; _i++) {
        c = _ref1[_i];
        switch (c.type) {
          case 'text':
            html.push(this.parseLine(c, "p"));
            break;
          case 'list':
            html.push("<ul>", this.parseLine(c, "li"), "</ul>");
        }
      }
      return html.join('');
    };

    return ficheProduitCore;

  })(ManifestLoader);
  return window.ficheProduitCore = ficheProduitCore;
})();
