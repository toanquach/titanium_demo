var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

(function() {
  var AddressForm;
  AddressForm = (function(_super) {
    __extends(AddressForm, _super);

    AddressForm.prototype.instance = null;

    function AddressForm() {
      this.successLoadTempJson = __bind(this.successLoadTempJson, this);
      this.clickCrossErrorHandler = __bind(this.clickCrossErrorHandler, this);
      this.submitHandler = __bind(this.submitHandler, this);
      this.displayCountries = __bind(this.displayCountries, this);
      var data;
      this.error_name = ko.observable();
      this.error_address = ko.observable();
      this.error_zipcode = ko.observable();
      this.error_city = ko.observable();
      this.error_country = ko.observable();
      this.country = ko.observableArray();
      data = $('#app').data('json');
      AddressForm.__super__.constructor.call(this, data);
    }

    AddressForm.prototype.isSuccessLoaded = function() {
      var _this = this;
      AddressForm.getInstance(this);
      this.fillLabels();
      this.fillAttributes();
      if (Helpers.isWebApp()) {
        $.ajax({
          url: "" + (this.getData().webservices.base) + (this.getData().json.mcamconnect),
          type: "POST",
          data: "key=06281d1d6cf698f12e2cc78306e78b3d",
          success: function(data) {
            _this.sessid = data.sessid;
            return _this.loadCountries();
          }
        });
      } else {

      }
      Bridge.hideLoader();
      Bridge.navigationTitle(this.getLabel("title"));
      Bridge.tracking(7, "page", {
        "myPageLabel": "formulaire_contact",
        "andPageChapter": "envoyer_une_carte::formulaire_contact"
      });
      $('form').on('submit', this.submitHandler);
    };

    AddressForm.prototype.loadCountries = function() {
      var _this = this;
      if (Helpers.isWebApp()) {
        $.ajax({
          url: "" + (this.getData().webservices.base) + (this.getData().json.mcaminfo),
          type: "POST",
          data: "sessid=" + this.sessid,
          success: function(data) {
            _this.zone = data.zones;
            _this.displayCountries(data);
          },
          error: function(jqXHR, textStatus, errorThrown) {
            window.alert("loadCountries error");
            window.alert("AJAX Error: " + jqXHR);
            window.alert("AJAX Error: " + textStatus);
            return window.alert("AJAX Error: " + errorThrown);
          },
          fail: function(data) {
            return window.alert("loadCountries FAILED");
          }
        });
      } else {

      }
    };

    AddressForm.prototype.displayCountries = function(data) {
      var i, _i, _ref, _results;
      _results = [];
      for (i = _i = 0, _ref = data.pays.length; 0 <= _ref ? _i < _ref : _i > _ref; i = 0 <= _ref ? ++_i : --_i) {
        _results.push(this.country.push(new this.displayCountry(data.pays[i], data.zones)));
      }
      return _results;
    };

    AddressForm.prototype.displayCountry = function(country, zones) {
      var i, _i, _ref;
      for (i = _i = 0, _ref = zones.length; 0 <= _ref ? _i < _ref : _i > _ref; i = 0 <= _ref ? ++_i : --_i) {
        if (zones[i].codeZone === parseInt(country.codeZone)) {
          country.price = zones[i].prix;
        }
      }
      this.value = JSON.stringify(country);
      this.text = country.nomPays;
    };

    AddressForm.prototype.submitHandler = function(e) {
      e.preventDefault();
      $(e.currentTarget).find('input').blur();
      Bridge.displayLoader();
      return AddressForm.testAddress();
    };

    AddressForm.prototype.clickCrossErrorHandler = function(e) {
      if ($(e.currentTarget).parent().data('error') === "name") {
        this.error_name(false);
      }
      if ($(e.currentTarget).parent().data('error') === "address") {
        this.error_address(false);
      }
      if ($(e.currentTarget).parent().data('error') === "zipcode") {
        $('.form-input-texts').find('[name=zipcode]').val("");
        this.error_zipcode(false);
      }
      if ($(e.currentTarget).parent().data('error') === "city") {
        this.error_city(false);
      }
      if ($(e.currentTarget).parent().data('error') === "country") {
        return this.error_country(false);
      }
    };

    AddressForm.prototype.successResultTestAddress = function(data) {
      console.log(data);
      console.log('=> Si plusieurs résultats : load page "Affiner votre adresse"');
      return console.log('=> Sinon load page "Adresse corrigée"');
    };

    AddressForm.prototype.failResultTestAddress = function(error) {
      window.alert("failResultTestAddress");
      return console.log(error);
    };

    AddressForm.prototype.failLoadWriteJson = function() {
      window.alert("failLoadWriteJson");
      return console.log("failLoadWriteJson");
    };

    AddressForm.prototype.successLoadTempJson = function(data) {
      data.recipient = this.recipient;
      data.sessid = this.sessid;
      if (Helpers.isWebApp()) {
        return Bridge.writeJSON(this.getData().json.temp2, data, "AddressForm.gotoNext()", false, "");
      } else {
        return AddressForm.gotoNext();
      }
    };

    AddressForm.getInstance = function(_this) {
      if (this.instance == null) {
        this.instance = _this;
      }
      return this.instance;
    };

    AddressForm.testAddress = function() {
      var address, city, error, jsonPath, name, zipcode;
      error = 0;
      $('.icon-error').off('click', this.instance.clickCrossErrorHandler);
      this.instance.error_name(false);
      this.instance.error_address(false);
      this.instance.error_zipcode(false);
      this.instance.error_city(false);
      this.instance.recipient = {};
      name = $('form').find('[name=name]').val();
      if (name.trim() === "") {
        error++;
        this.instance.error_name(true);
        $('.form-input-texts').find('.error[data-error=name] p').html(this.instance.getLabel('name_empty'));
      } else {
        this.instance.recipient.name = name;
      }
      address = $('form').find('[name=address]').val();
      if (address.trim() === "") {
        error++;
        this.instance.error_address(true);
        $('.form-input-texts').find('.error[data-error=address] p').html(this.instance.getLabel('address_empty'));
      } else {
        this.instance.recipient.address = address;
      }
      zipcode = $('form').find('[name=zipcode]').val().trim();
      if (zipcode.trim() === "") {
        error++;
        this.instance.error_zipcode(true);
        $('.form-input-texts').find('.error[data-error=zipcode] p').html(this.instance.getLabel('code_postal_empty'));
      } else if (!Helpers.isZipcode(zipcode)) {
        error++;
        this.instance.error_zipcode(true);
        $('.form-input-texts').find('.error[data-error=zipcode] p').html(this.instance.getLabel('code_postal_error'));
      } else {
        this.instance.recipient.zipcode = zipcode;
      }
      city = $('form').find('[name=city]').val();
      if (city.trim() === "") {
        error++;
        this.instance.error_city(true);
        $('.form-input-texts').find('.error[data-error=city] p').html(this.instance.getLabel('city_empty'));
      } else {
        this.instance.recipient.city = city;
      }
      if ($('form').find('select').val() === "") {
        error++;
        this.instance.error_country(true);
        $('.form-input-texts').find('.error[data-error=country] p').html(this.instance.getLabel('country_empty'));
      } else {
        this.instance.error_country(false);
      }
      if (error > 0) {
        $('.icon-error').on('click', this.instance.clickCrossErrorHandler);
        return Bridge.hideLoader(false);
      } else {
        this.instance.recipient.address_comp = $('form').find('[name=city]').val();
        this.instance.recipient.country = $('form').find('select').val();
        if (this.instance.recipient.country !== "") {
          this.instance.recipient.country = $.parseJSON(this.instance.recipient.country);
        }
        jsonPath = Helpers.convertAbsoluteToRelativeJsonPath(this.instance.getData().json.temp2, true);
        Helpers.loadJson(jsonPath).done(this.instance.successLoadTempJson);
      }
    };

    AddressForm.failWS = function(data) {
      return console.log("failWS");
    };

    AddressForm.readResults = function() {
      var writeJsonPath;
      writeJsonPath = Helpers.convertAbsoluteToRelativeJsonPath(this.instance.getData().json.resultTestAddress);
      Helpers.loadJson(writeJsonPath).done(this.instance.checkResults).fail(this.instance.failLoadWriteJson);
    };

    AddressForm.gotoNext = function() {
      return Bridge.redirect("app_7/views/summary.html");
    };

    return AddressForm;

  }).call(this, ManifestLoader);
  window.AddressForm = AddressForm;
  return $(function() {
    return ko.applyBindings(new AddressForm());
  });
})();
