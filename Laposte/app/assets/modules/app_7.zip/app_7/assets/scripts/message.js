var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

(function() {
  var Message;
  Message = (function(_super) {
    __extends(Message, _super);

    function Message() {
      this.submitHandler = __bind(this.submitHandler, this);
      this.failLoadTempJson = __bind(this.failLoadTempJson, this);
      var data;
      data = $('#app').data('json');
      Message.__super__.constructor.call(this, data);
    }

    Message.prototype.isSuccessLoaded = function() {
      Message.getInstance(this);
      this.fillLabels();
      this.fillAttributes();
      $('form').on('submit', this.submitHandler);
      Bridge.hideLoader();
      Bridge.navigationTitle(this.getLabel("title"));
      return Bridge.tracking(7, "page", {
        "myPageLabel": "message",
        "andPageChapter": "envoyer_une_carte::message"
      });
    };

    Message.prototype.failLoadTempJson = function(error) {
      return console.log(error);
    };

    Message.prototype.submitHandler = function(e) {
      var temp;
      e.preventDefault();
      Bridge.displayLoader();
      temp = {
        "message": "" + ($(e.currentTarget).find('[name=msg]').val().replace(/\r?\n/g, '<br />'))
      };
      if (Helpers.isWebApp()) {
        Bridge.writeJSON(this.getData().json.temp2, temp, "Message.gotoNext()", false, "");
      } else {
        Message.gotoNext();
      }
    };

    Message.getInstance = function(_this) {
      if (this.instance == null) {
        this.instance = _this;
      }
      return this.instance;
    };

    Message.gotoNext = function() {
      return Bridge.redirect("app_7/views/visualization.html");
    };

    return Message;

  })(ManifestLoader);
  window.Message = Message;
  return $(function() {
    return ko.applyBindings(new Message());
  });
})();
