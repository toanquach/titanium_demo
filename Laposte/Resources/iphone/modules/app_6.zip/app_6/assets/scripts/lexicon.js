var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

(function() {
  var lexicon;
  lexicon = (function(_super) {
    __extends(lexicon, _super);

    lexicon.prototype.instance = null;

    function lexicon() {
      this.submitHandler = __bind(this.submitHandler, this);
      this.successLoad = __bind(this.successLoad, this);
      var data;
      this.list = ko.observableArray();
      this.filter = ko.observable('');
      this.filteredList = ko.computed(function() {
        var filter;
        filter = this.filter().toLowerCase();
        return ko.utils.arrayFilter(this.list(), function(link) {
          if (link.label.toLowerCase().indexOf(filter) !== -1) {
            return link.show(true);
          } else {
            return link.show(false);
          }
        });
      }, this);
      data = $('#app').data('json');
      lexicon.__super__.constructor.call(this, data);
    }

    lexicon.prototype.isSuccessLoaded = function() {
      return Helpers.loadJson(Helpers.convertAbsoluteToRelativeJsonPath(this.getData().json.lexicon)).done(this.successLoad).fail(this.failLoad);
    };

    lexicon.prototype.successLoad = function(data) {
      this.displayList(data.lexicon);
      this.fillLabels();
      this.fillAttributes();
      $('form').on('submit', this.submitHandler);
      Bridge.hideLoader();
      return Bridge.tracking(2, "page", {
        "myPageLabel": "liste",
        "andPageChapter": "lexique"
      });
    };

    lexicon.prototype.displayList = function(data) {
      var i, _i, _ref, _results;
      _results = [];
      for (i = _i = 0, _ref = data.length; 0 <= _ref ? _i < _ref : _i > _ref; i = 0 <= _ref ? ++_i : --_i) {
        _results.push(this.list.push(new this.displayLink(data[i], i, this)));
      }
      return _results;
    };

    lexicon.prototype.displayLink = function(data, idx, that) {
      this.label = data.label;
      this.link = "definition.html?idx=" + idx;
      this.show = ko.observable(true);
    };

    lexicon.prototype.submitHandler = function(e) {
      e.preventDefault();
      return $(e.currentTarget).find('input').blur();
    };

    return lexicon;

  })(ManifestLoader);
  return $(function() {
    return ko.applyBindings(new lexicon());
  });
})();
