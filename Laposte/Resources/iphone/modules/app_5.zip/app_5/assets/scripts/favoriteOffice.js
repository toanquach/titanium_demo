(function() {
  var FavoriteOffice;
  FavoriteOffice = (function() {
    function FavoriteOffice() {}

    FavoriteOffice.activateFavorite = function(codeSite) {
      var favoriteLink, url;
      favoriteLink = $('#app').find('a.favorite').data('code-site', codeSite);
      url = favoriteLink.attr('href').split("#setAsFavorite")[0];
      favoriteLink.find('.star').removeClass('icon-star-inactive');
      favoriteLink.find('.star').addClass('icon-star-active');
      return favoriteLink.attr('href', "" + url + "#removeFavorite");
    };

    FavoriteOffice.deactivateFavorite = function(codeSite) {
      var favoriteLink, url;
      favoriteLink = $('#app').find('a.favorite').data('code-site', codeSite);
      url = favoriteLink.attr('href').split("#removeFavorite")[0];
      favoriteLink.find('.star').removeClass('icon-star-active');
      favoriteLink.find('.star').addClass('icon-star-inactive');
      return favoriteLink.attr('href', "" + url + "#setAsFavorite");
    };

    return FavoriteOffice;

  })();
  return window.FavoriteOffice = FavoriteOffice;
})();
