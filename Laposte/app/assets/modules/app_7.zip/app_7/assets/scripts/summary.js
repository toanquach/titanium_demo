var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

(function() {
  var Summary;
  Summary = (function(_super) {
    __extends(Summary, _super);

    function Summary() {
      this.clickAdviceHandler = __bind(this.clickAdviceHandler, this);
      this.submitHandler = __bind(this.submitHandler, this);
      this.successLoadTemp2Json = __bind(this.successLoadTemp2Json, this);
      this.successLoadTempJson = __bind(this.successLoadTempJson, this);
      var data;
      this.temp = {};
      this.image = ko.observable();
      this.name = ko.observable();
      this.address = ko.observable();
      this.address_comp = ko.observable();
      this.zipcode = ko.observable();
      this.city = ko.observable();
      this.country = ko.observable();
      this.price = ko.observable();
      this.error_mail = ko.observable();
      this.error_confirmmail = ko.observable();
      data = $('#app').data('json');
      Summary.__super__.constructor.call(this, data);
    }

    Summary.prototype.isSuccessLoaded = function() {
      Summary.getInstance(this);
      this.fillLabels();
      this.fillAttributes();
      this.loadTempData();
      $('form').on('submit', this.submitHandler);
      $('.need-help').on('click', this.clickAdviceHandler);
      Bridge.hideLoader();
      Bridge.navigationTitle(this.getLabel("title"));
      return Bridge.tracking(5, "page", {
        "myPageLabel": "recapitulatif",
        "andPageChapter": "envoyer_une_carte::recapitulatif"
      });
    };

    Summary.prototype.loadTempData = function() {
      var jsonPath;
      jsonPath = Helpers.convertAbsoluteToRelativeJsonPath(this.getData().json.temp, true);
      return Helpers.loadJson(jsonPath).done(this.successLoadTempJson).fail(this.failLoadTempJson);
    };

    Summary.prototype.successLoadTempJson = function(data) {
      var jsonPath;
      this.tempData = data;
      jsonPath = Helpers.convertAbsoluteToRelativeJsonPath(this.getData().json.temp2, true);
      return Helpers.loadJson(jsonPath).done(this.successLoadTemp2Json).fail(this.failLoadTempJson);
    };

    Summary.prototype.successLoadTemp2Json = function(data) {
      this.temp = data;
      this.image(this.tempData.image.crop);
      this.name(data.recipient.name);
      this.address(data.recipient.address);
      if (data.recipient.address_comp != null) {
        this.address_comp(data.recipient.address_comp);
      }
      this.zipcode(data.recipient.zipcode);
      this.city(data.recipient.city);
      this.country(data.recipient.country.nomPays);
      return this.price("" + data.recipient.country.price + " €");
    };

    Summary.prototype.submitHandler = function(e) {
      e.preventDefault();
      $(e.currentTarget).find('input').blur();
      Bridge.displayLoader();
      Summary.testForm();
      return Bridge.tracking(7, 'click', {
        "myPageLabel": "paiement",
        "andPageChapter": "envoyer_une_carte::paiement"
      }, "sortie");
    };

    Summary.prototype.openCGV = function() {
      Bridge.hideLoader();
      Bridge.alertPopin(this.getLabel("popin_cgv_title"), this.getLabel("popin_cgv"), {
        "title": this.getLabel("popin_cgv_ko"),
        "callback": ""
      }, {
        "title": this.getLabel("popin_cgv_ok"),
        "callback": "Summary.getInstance(" + this.instance + ").uploadImage()"
      });
    };

    Summary.prototype.uploadImage = function() {
      var base64, xhr,
        _this = this;
      xhr = new XMLHttpRequest();
      xhr.open("POST", "" + (this.getData().webservices.base) + (this.getData().json.mcamimage) + "?sessid=" + this.temp.sessid);
      xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
      xhr.onreadystatechange = function() {};
      xhr.onload = function() {
        _this.temp.image_id = JSON.parse(xhr.responseText).image_id;
        _this.createOrder();
      };
      base64 = this.tempData.image.crop;
      base64 = base64.replace(/^data:image\/(png|jpeg);base64,/, "");
      return xhr.send("fichierbase64=" + base64);
    };

    Summary.prototype.createOrder = function() {
      var xhr,
        _this = this;
      xhr = new XMLHttpRequest();
      xhr.open("POST", "" + (this.getData().webservices.base) + (this.getData().json.mcamorder) + "?sessid=" + this.temp.sessid);
      xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
      xhr.onreadystatechange = function() {};
      xhr.onload = function() {
        _this.temp.oid = JSON.parse(xhr.responseText).oid;
        _this.beginPayment();
      };
      return xhr.send("cartes={\"cartes\": [{\"email\": \"" + this.temp.mail + "\",\"message\": \"" + this.temp.message + "\",\"image_id\": \"" + this.temp.image_id + "\",\"destinataire\": [{\"dest_1\": \"" + this.temp.recipient.name + "\",\"dest_2\": \"" + this.temp.recipient.address_comp + "\",\"dest_3\": \"" + this.temp.recipient.address + "\",\"dest_4\": \"\",\"dest_5\": \"" + this.temp.recipient.zipcode + " " + this.temp.recipient.city + "\",\"dest_6\": \"" + this.temp.recipient.country.nomPays + "\"}]}]}");
    };

    Summary.prototype.beginPayment = function() {
      Bridge.hideLoader(false);
      $('<iframe></iframe>').attr({
        'src': "" + (this.getData().webservices.payment) + "/bomcam/mobile/review?oid=" + this.temp.oid,
        'height': '100%',
        'width': '100%'
      }).appendTo('body');
      return $('#app').hide();
    };

    Summary.prototype.clickAdviceHandler = function(e) {
      var $target, completeUrl, url;
      e.preventDefault();
      $target = $(e.currentTarget);
      url = $target.attr('href');
      $target.attr('href', "" + ($target.attr('href').split('&')[0]) + "&=" + (Math.random()));
      completeUrl = "" + (Helpers.getCurrentApp()) + "/views/" + url;
      return Bridge.displayPopin(completeUrl, null, $target.find('.advice-label').html());
    };

    Summary.getInstance = function(_this) {
      if (this.instance == null) {
        this.instance = _this;
      }
      return this.instance;
    };

    Summary.testForm = function() {
      var confirmmail, error, mail;
      error = 0;
      $('.icon-error').off('click', this.instance.clickCrossErrorHandler);
      this.instance.error_mail(false);
      this.instance.error_confirmmail(false);
      mail = $('form').find('[name=mail]').val();
      if (mail.trim() === "") {
        error++;
        this.instance.error_mail(true);
        $('.form-input-texts').find('.error[data-error=mail] p').html(this.instance.getLabel('summary_email_empty'));
      } else if (!Helpers.isEmail(mail)) {
        error++;
        this.instance.error_mail(true);
        $('.form-input-texts').find('.error[data-error=mail] p').html(this.instance.getLabel('summary_email_error'));
      }
      confirmmail = $('form').find('[name=confirmmail]').val();
      if (confirmmail.trim() === "") {
        error++;
        this.instance.error_confirmmail(true);
        $('.form-input-texts').find('.error[data-error=confirmmail] p').html(this.instance.getLabel('summary_email_empty'));
      } else if (mail !== confirmmail) {
        error++;
        this.instance.error_confirmmail(true);
        $('.form-input-texts').find('.error[data-error=confirmmail] p').html(this.instance.getLabel('summary_email_error'));
      }
      if (error > 0) {
        $('.icon-error').on('click', this.instance.clickCrossErrorHandler);
        Bridge.hideLoader(false);
      } else {
        this.instance.temp.mail = mail;
        this.instance.openCGV();
      }
    };

    return Summary;

  })(ManifestLoader);
  window.Summary = Summary;
  return $(function() {
    return ko.applyBindings(new Summary());
  });
})();
