var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

(function() {
  var definition;
  definition = (function(_super) {
    __extends(definition, _super);

    definition.prototype.instance = null;

    function definition() {
      this.successLoad = __bind(this.successLoad, this);
      var data;
      this.label = ko.observable();
      this.definition = ko.observable();
      data = $('#app').data('json');
      definition.__super__.constructor.call(this, data);
    }

    definition.prototype.isSuccessLoaded = function() {
      return Helpers.loadJson(Helpers.convertAbsoluteToRelativeJsonPath(this.getData().json.lexicon)).done(this.successLoad).fail(this.failLoad);
    };

    definition.prototype.successLoad = function(data) {
      var idx;
      idx = parseInt(Helpers.getUrlVar("idx"), 10);
      this.label(data.lexicon[idx].label);
      this.definition(data.lexicon[idx].definition);
      $('.text').on('click', 'a', function(e) {
        e.preventDefault();
        return Bridge.externalLink($(e.currentTarget).attr('href'));
      });
      this.fillLabels();
      Bridge.hideLoader();
      return Bridge.tracking(2, "page", {
        "myPageLabel": "" + data.lexicon[idx].label,
        "andPageChapter": "lexique"
      });
    };

    return definition;

  })(ManifestLoader);
  return $(function() {
    return ko.applyBindings(new definition());
  });
})();
