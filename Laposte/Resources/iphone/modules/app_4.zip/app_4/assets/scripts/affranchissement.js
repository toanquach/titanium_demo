var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

(function() {
  var Affranchissement;
  Affranchissement = (function(_super) {
    __extends(Affranchissement, _super);

    Affranchissement.prototype.instance = null;

    function Affranchissement() {
      this.clickFavoriteIconHandler = __bind(this.clickFavoriteIconHandler, this);
      this.clickAdviceHandler = __bind(this.clickAdviceHandler, this);
      this.failWS = __bind(this.failWS, this);
      this.successWS = __bind(this.successWS, this);
      this.successLoadParams = __bind(this.successLoadParams, this);
      var data;
      this.nature = ko.observable();
      this.infos = ko.observable();
      this.price = ko.observable();
      this.img = ko.observable();
      data = $('#app').data('json');
      Affranchissement.__super__.constructor.call(this, data);
    }

    Affranchissement.prototype.isSuccessLoaded = function() {
      var params;
      Affranchissement.getInstance(this);
      this.fillLabels();
      params = Helpers.getUrlVar('params');
      if (!!params) {
        Bridge.writeJSON(this.getData().json.params, $.parseJSON(decodeURIComponent(params)), "Affranchissement.setInfos()");
      } else {
        Affranchissement.setInfos();
      }
      $('.poste').find('a').on('click', this.bindClick);
      $('.favorite').on('click', this.clickFavoriteIconHandler);
      $('.need-help').on('click', this.clickAdviceHandler);
      return Bridge.hideLoader();
    };

    Affranchissement.prototype.successLoadParams = function(data) {
      var infos, key, value, _ref;
      this.params = data;
      infos = "";
      _ref = data.summary;
      for (key in _ref) {
        value = _ref[key];
        if (key !== "image") {
          if (infos === "") {
            infos = value;
          } else {
            infos += ", " + value;
          }
          if (key === "nature") {
            this.nature(value);
            if (value === "Document Prioritaire") {
              this.type = "doc";
            }
            if (value === "Marchandise Prioritaire") {
              this.type = "march";
            }
          }
        } else {
          this.img(value);
        }
      }
      this.infos(infos);
      Helpers.forceImgToRetina($('img'));
      Bridge.displayLoader();
      WebservicesCalculDeTarifs.callService(this.getData().webservices.affranchir, data.params, {}, this.successWS, this.failWS);
    };

    Affranchissement.prototype.successWS = function(data) {
      var montant, montant2, msg;
      Bridge.hideLoader(false);
      if ($(data).find("error").length) {
        switch ($(data).find("error").text()) {
          case "Erreur : ce Tarif n'est pas disponible":
            msg = this.getLabel('errorPrice');
            break;
          case "Erreur : le code site \"dom_com\" n'éxiste pas":
            msg = this.getLabel('errorProduct');
            break;
          case "Erreur : parametres \"gr\" invalide":
            msg = this.getLabel('errorPrice');
        }
        return Bridge.alertPopin('', msg, {
          "title": "OK",
          "callback": ""
        });
      } else {
        montant = $(data).find("montant").text();
        if (montant.length) {
          this.price(("" + (parseFloat(montant).toFixed(2)) + " €").replace('.', ','));
        } else if (this.params.task === "colis") {
          this.price(("" + (parseFloat($(data).find("montant_colis").text()).toFixed(2)) + " €").replace('.', ','));
        } else {
          this.price(("" + (parseFloat($(data).find("montant_enveloppe").text()).toFixed(2)) + " €").replace('.', ','));
        }
        montant2 = $(data).find("montant_" + this.type).text();
        if (montant2.length) {
          return this.price(("" + (parseFloat(montant2).toFixed(2)) + " €").replace('.', ','));
        }
      }
    };

    Affranchissement.prototype.failWS = function(data) {
      Bridge.hideLoader(false);
      return Bridge.alertPopin('', $(data).find("error").text(), {
        "title": "OK",
        "callback": ""
      });
    };

    Affranchissement.prototype.clickAdviceHandler = function(e) {
      var $target, completeUrl, url;
      e.preventDefault();
      $target = $(e.currentTarget);
      url = $target.attr('href');
      $target.attr('href', "" + ($target.attr('href').split('&')[0]) + "&=" + (Math.random()));
      completeUrl = "" + (Helpers.getCurrentApp()) + "/views/" + url;
      return Bridge.displayPopin(completeUrl, null, $target.find('.advice-label').html());
    };

    Affranchissement.prototype.bindClick = function(e) {
      e.preventDefault();
      return Bridge.switchModule("app_5", "app_5/views/map.html");
    };

    Affranchissement.prototype.clickFavoriteIconHandler = function(e) {
      if ($(e.currentTarget).find('.star').hasClass('icon-star-active')) {
        return this.removeFavorite();
      } else {
        return this.addFavorite();
      }
    };

    Affranchissement.prototype.addFavorite = function() {
      var data;
      if (Helpers.isWebApp()) {
        this.id = new Date().getTime();
        data = {
          "destination": this.params.favorite.destination,
          "details": "Depuis la France\n" + this.params.favorite.details
        };
        return Bridge.setFavorite(this.id, data, "AFF_RCH", "Affranchissement.callbackAddFavorite()", "" + (Helpers.getCurrentPage()) + "?params=" + (encodeURIComponent(JSON.stringify(this.params))));
      } else {
        return Affranchissement.callbackAddFavorite();
      }
    };

    Affranchissement.prototype.removeFavorite = function() {
      if (Helpers.isWebApp()) {
        return Bridge.removeFavorite(this.id, "AFF_RCH", "Affranchissement.callbackRemoveFavorite()");
      } else {
        return Affranchissement.callbackRemoveFavorite();
      }
    };

    Affranchissement.getInstance = function(_this) {
      if (this.instance == null) {
        this.instance = _this;
      }
      return this.instance;
    };

    Affranchissement.setInfos = function() {
      return Helpers.loadJson(Helpers.convertAbsoluteToRelativeJsonPath(this.instance.getData().json.params)).done(this.instance.successLoadParams).fail(this.instance.failLoadParams);
    };

    Affranchissement.callbackAddFavorite = function() {
      $('.star').removeClass('icon-star-inactive');
      return $('.star').addClass('icon-star-active');
    };

    Affranchissement.callbackRemoveFavorite = function() {
      $('.star').removeClass('icon-star-active');
      return $('.star').addClass('icon-star-inactive');
    };

    window.Affranchissement = Affranchissement;

    return Affranchissement;

  })(ManifestLoader);
  return $(function() {
    return ko.applyBindings(new Affranchissement());
  });
})();
