var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

(function() {
  var MapDetailsOffice;
  MapDetailsOffice = (function(_super) {
    __extends(MapDetailsOffice, _super);

    function MapDetailsOffice() {
      this.resize = __bind(this.resize, this);
      this.clickOpenClosePackageHoursHandler = __bind(this.clickOpenClosePackageHoursHandler, this);
      this.clickOpenClosePeriodsHandler = __bind(this.clickOpenClosePeriodsHandler, this);
      this.clickFavoriteIconHandler = __bind(this.clickFavoriteIconHandler, this);
      this.mouseOutFavoriteIconHandler = __bind(this.mouseOutFavoriteIconHandler, this);
      this.mouseOverFavoriteIconHandler = __bind(this.mouseOverFavoriteIconHandler, this);
      this.localizeOffice = __bind(this.localizeOffice, this);
      this.failLoadWriteJson = __bind(this.failLoadWriteJson, this);
      this.successLoadWriteJson = __bind(this.successLoadWriteJson, this);
      this.failDataOffice = __bind(this.failDataOffice, this);
      this.successDataOffice = __bind(this.successDataOffice, this);
      this.initializeMap = __bind(this.initializeMap, this);
      var data,
        _this = this;
      this.close = ko.observable();
      this.periods = ko.observableArray();
      this.days_package = ko.observableArray();
      this.services = ko.observableArray();
      data = $('#app').data('json');
      MapDetailsOffice.__super__.constructor.call(this, data);
      google.maps.event.addDomListener(window, 'load', (function() {
        return setTimeout(_this.initializeMap, 200);
      }));
    }

    MapDetailsOffice.prototype.initializeMap = function() {
      var mapOptions;
      if (this.dataOffice != null) {
        this.mapInitialize = true;
        this.mapCanvas = $('.container-map .map-canvas')[0];
        mapOptions = {
          zoom: 15,
          streetViewControl: false,
          disableDefaultUI: true,
          mapTypeId: google.maps.MapTypeId.RODMAP
        };
        this.map = new google.maps.Map(this.mapCanvas, mapOptions);
        return this.localizeOffice();
      }
    };

    MapDetailsOffice.prototype.isSuccessLoaded = function() {
      this.code_site = Helpers.getUrlVar("code_site");
      if (this.code_site !== null) {
        MapDetailsOffice.getInstance(this);
        return Webservices.callService(this.getData().webservices.detailPosteOffice, {
          code_site: this.code_site
        }, {}, this.successDataOffice, this.failDataOffice);
      } else {
        return this.failDataOffice();
      }
    };

    MapDetailsOffice.prototype.successDataOffice = function(data) {
      if (Helpers.isWebApp()) {
        return Bridge.writeJSON(this.getData().json.mapDetailsOffice, data, "MapDetailsOffice.readyParseData()", true, "LOC_BP");
      } else {
        return MapDetailsOffice.readyParseData();
      }
    };

    MapDetailsOffice.prototype.failDataOffice = function(error) {
      if (error != null) {
        return Bridge.alertPopin("", this.getLabel("error_loading_page"), {
          "title": "OK",
          "callback": ""
        });
      } else {
        return Bridge.alertPopin("", this.getLabel("error_loading_page"), {
          "title": "OK",
          "callback": ""
        });
      }
    };

    MapDetailsOffice.prototype.successLoadWriteJson = function(data) {
      this.dataOffice = data.bureaux;
      this.favorite = data.favorite;
      this.initializeMap();
      this.setOfficeDatas();
      this.checkOpenClose();
      this.setOfficePeriods();
      this.checkMultiPeriods();
      this.setPackageHours();
      this.openClosePackageHours();
      this.setOfficeServices();
      this.setMapLink();
      this.fillLabels();
      setTimeout(this.resize, 100);
      $(window).bind('resize', this.resize);
      Bridge.hideLoader();
      Bridge.navigationTitle(this.dataOffice.libelleSite);
      return Bridge.tracking(3, "page", {
        "myPageLabel": "" + data.bureaux.libelleSite,
        "andPageChapter": "bureau_de_poste"
      });
    };

    MapDetailsOffice.prototype.failLoadWriteJson = function(error) {
      return Bridge.alertPopin("", this.getLabel("error_loading_page"), {
        "title": "OK",
        "callback": ""
      });
    };

    MapDetailsOffice.prototype.localizeOffice = function() {
      var icon, latlng, marker;
      latlng = new google.maps.LatLng(this.dataOffice.lat, this.dataOffice.lng);
      this.map.setCenter(latlng);
      icon = {
        url: this.getData().images.pinRetina,
        scaledSize: new google.maps.Size(38, 55)
      };
      return marker = new google.maps.Marker({
        position: latlng,
        icon: icon,
        map: this.map
      });
    };

    MapDetailsOffice.prototype.setOfficeDatas = function() {
      $('.name-office').html(this.dataOffice.libelleSite);
      $('.address-office').html(this.dataOffice.adresse);
      $('.city-office').html("" + this.dataOffice.codePostal + " " + this.dataOffice.localite);
      this.favoriteLink = $('a.favorite');
      if (this.favorite.indexOf(this.dataOffice.codeSite) !== -1) {
        this.favoriteLink.find('.star').addClass('icon-star-active');
      } else {
        this.favoriteLink.find('.star').addClass('icon-star-inactive');
      }
      this.favoriteLink.on('mouseover', this.mouseOverFavoriteIconHandler);
      this.favoriteLink.on('mouseout', this.mouseOutFavoriteIconHandler);
      return this.favoriteLink.on('click', this.clickFavoriteIconHandler);
    };

    MapDetailsOffice.prototype.mouseOverFavoriteIconHandler = function(e) {
      return $(e.currentTarget).css('cursor', 'pointer');
    };

    MapDetailsOffice.prototype.mouseOutFavoriteIconHandler = function(e) {
      return $(e.currentTarget).css('cursor', 'auto');
    };

    MapDetailsOffice.prototype.clickFavoriteIconHandler = function(e) {
      if (this.favoriteLink.find('.star').hasClass('icon-star-active')) {
        return this.removeFavorite();
      } else {
        return this.addFavorite();
      }
    };

    MapDetailsOffice.prototype.addFavorite = function() {
      var dataOffice;
      if (Helpers.isWebApp()) {
        dataOffice = {
          codeSite: this.dataOffice.codeSite,
          libelleSite: this.dataOffice.libelleSite,
          adresse: this.dataOffice.adresse,
          codePostal: this.dataOffice.codePostal,
          localite: this.dataOffice.localite,
          telephoneIndigo: this.dataOffice.telephoneIndigo,
          telephoneStandard: this.dataOffice.telephoneStandard,
          lng: this.dataOffice.lng,
          lat: this.dataOffice.lat,
          etat: {
            date: this.dataOffice.etat.date,
            ouvert: this.dataOffice.etat.ouvert,
            dateChangement: this.dataOffice.etat.dateChangement
          }
        };
        return Bridge.setFavorite(this.dataOffice.codeSite, dataOffice, "LOC_BP", "MapDetailsOffice.callbackAddFavorite()");
      } else {
        return MapDetailsOffice.callbackAddFavorite();
      }
    };

    MapDetailsOffice.prototype.removeFavorite = function() {
      if (Helpers.isWebApp()) {
        return Bridge.removeFavorite(this.dataOffice.codeSite, "LOC_BP", "MapDetailsOffice.callbackRemoveFavorite()");
      } else {
        return MapDetailsOffice.callbackRemoveFavorite();
      }
    };

    MapDetailsOffice.prototype.checkOpenClose = function() {
      var closeData, containerCloseOffice, diffTime, openCloseOffice, strCloseTime, strOpenTime;
      openCloseOffice = $('.open-close-office');
      diffTime = Helpers.calculateDiffTime(this.dataOffice.etat.date, this.dataOffice.etat.dateChangement);
      if (this.dataOffice.etat.ouvert) {
        openCloseOffice.find('.border-open-close-office .open-close-office-label').html(this.getLabel('open'));
        openCloseOffice.find('.border-open-close-office').addClass('open-office');
        if (diffTime !== "") {
          strCloseTime = this.formatTime(diffTime);
          openCloseOffice.find('.close-time-office').html("" + (this.getLabel('close_in')) + " " + strCloseTime);
        }
      } else {
        openCloseOffice.find('.border-open-close-office .open-close-office-label').html(this.getLabel('close'));
        openCloseOffice.find('.border-open-close-office').removeClass('open-office');
        if (diffTime !== "") {
          strOpenTime = this.formatTime(diffTime);
          openCloseOffice.find('.close-time-office').html("" + (this.getLabel('open_in')) + " " + strOpenTime);
        }
      }
      if (this.dataOffice.fermeture) {
        this.close(true);
        containerCloseOffice = $('.container-office-closed');
        closeData = this.dataOffice.fermeture;
        if (closeData.debutPeriodeJour === closeData.finPeriodeJour) {
          if (closeData.debutPeriodeHeure === "00:00:00" && closeData.finPeriodeHeure === "23:59:00") {
            return containerCloseOffice.find('.closing-line').html("" + (this.getLabel('close_exceptionnal')) + " " + closeData.debutPeriodeJour);
          } else {
            return containerCloseOffice.find('.closing-line').html("" + (this.getLabel('close_exceptionnal')) + " " + closeData.debutPeriodeJour + "<br>" + (this.getLabel('from_hour')) + " " + (closeData.debutPeriodeHeure.substr(0, 5)) + " " + (this.getLabel('to_hour')) + " " + (closeData.finPeriodeHeure.substr(0, 5)));
          }
        } else {
          return containerCloseOffice.find('.closing-line').html("" + (this.getLabel('close_temp_1')) + " " + closeData.debutPeriodeJour + " " + (this.getLabel('to_hour')) + " " + (closeData.debutPeriodeHeure.substr(0, 5)) + "<br>" + (this.getLabel('close_temp_2')) + " " + closeData.finPeriodeJour + " " + (this.getLabel('to_hour')) + " " + (closeData.finPeriodeHeure.substr(0, 5)));
        }
      } else {
        return this.close(false);
      }
    };

    MapDetailsOffice.prototype.formatTime = function(time) {
      var strTime;
      strTime = "";
      if (time !== "") {
        if (time.day === 0) {
          strTime = "" + time.hour + (this.getLabel('hour')) + time.min + (this.getLabel('minute'));
        } else if (time.day === 1) {
          strTime = "" + time.day + " " + (this.getLabel('day')) + " " + time.hour + (this.getLabel('hour')) + time.min + (this.getLabel('minute'));
        } else {
          strTime = "" + time.day + " " + (this.getLabel('days')) + " " + time.hour + (this.getLabel('hour')) + time.min + (this.getLabel('minute'));
        }
      }
      return strTime;
    };

    MapDetailsOffice.prototype.setOfficePeriods = function() {
      var i, periodDatas, _i, _ref, _results;
      periodDatas = this.dataOffice.periodes;
      _results = [];
      for (i = _i = 0, _ref = periodDatas.length; 0 <= _ref ? _i < _ref : _i > _ref; i = 0 <= _ref ? ++_i : --_i) {
        _results.push(this.periods.push(new this.DisplayPeriod(periodDatas[i], this)));
      }
      return _results;
    };

    MapDetailsOffice.prototype.DisplayPeriod = function(periodData, that) {
      var dayData, endPeriod, i, startPeriod, _i, _ref;
      this.days = ko.observableArray();
      dayData = periodData.jours;
      for (i = _i = 0; _i < 8; i = ++_i) {
        if ((_ref = dayData["jour" + (i + 1)]) != null ? _ref.plagesHoraires.length : void 0) {
          this.days.push(new that.DisplayDay(dayData["jour" + (i + 1)], "jour" + (i + 1), that));
        }
      }
      startPeriod = that.transformDate(periodData.debutPeriode);
      endPeriod = that.transformDate(periodData.finPeriode);
      return this.period = "" + (that.getLabel('from_date')) + " " + startPeriod + " " + (that.getLabel('to_date')) + " " + endPeriod;
    };

    MapDetailsOffice.prototype.DisplayDay = function(dayData, day, that) {
      var i, timeSlotsData, _i, _ref;
      this.time_slots = ko.observableArray();
      timeSlotsData = dayData.plagesHoraires;
      for (i = _i = 0, _ref = timeSlotsData.length; 0 <= _ref ? _i < _ref : _i > _ref; i = 0 <= _ref ? ++_i : --_i) {
        this.time_slots.push(new that.DisplayTimeSlots(timeSlotsData[i], that));
      }
      return this.day = that.getLabel(day);
    };

    MapDetailsOffice.prototype.DisplayTimeSlots = function(timeSlotsData, that) {
      var closeHour, openHour;
      openHour = that.transformHour(timeSlotsData.debutPlage);
      closeHour = that.transformHour(timeSlotsData.finPlage);
      return this.hours = "" + (that.getLabel('from_hour')) + " " + openHour + " " + (that.getLabel('to_hour')) + " " + closeHour;
    };

    MapDetailsOffice.prototype.transformDate = function(date) {
      var dateArray, day, month;
      dateArray = date.split("/");
      day = dateArray[0];
      if (day.substr(0, 1) === "0") {
        day = day.substr(1, 1);
        if (day === "1") {
          day = day + this.getLabel('first');
        }
      }
      month = this.getLabel("month" + dateArray[1]);
      return "" + day + " " + month;
    };

    MapDetailsOffice.prototype.transformHour = function(hour) {
      var hourArray;
      hourArray = hour.split(":");
      return "" + hourArray[0] + (this.getLabel('hour')) + hourArray[1];
    };

    MapDetailsOffice.prototype.checkMultiPeriods = function() {
      var i, nbPeriods, periodsLi, _i;
      periodsLi = $('.periods-ul .periods-li');
      nbPeriods = periodsLi.length;
      if (nbPeriods > 1) {
        for (i = _i = 1; 1 <= nbPeriods ? _i < nbPeriods : _i > nbPeriods; i = 1 <= nbPeriods ? ++_i : --_i) {
          $(periodsLi[i]).find('.hours-ul').hide();
          $(periodsLi[i]).find('.container-hours').on('click', this.clickOpenClosePeriodsHandler);
        }
      }
    };

    MapDetailsOffice.prototype.clickOpenClosePeriodsHandler = function(e) {
      var $target, hoursUl;
      $target = $(e.currentTarget);
      $target.toggleClass('open');
      hoursUl = $target.parent().find('.hours-ul');
      return hoursUl.slideToggle(250);
    };

    MapDetailsOffice.prototype.setPackageHours = function() {
      var i, nbDays, packageHoursDatas, _i, _results;
      packageHoursDatas = this.dataOffice.limiteDepot;
      nbDays = _.keys(packageHoursDatas).length;
      _results = [];
      for (i = _i = 0; 0 <= nbDays ? _i < nbDays : _i > nbDays; i = 0 <= nbDays ? ++_i : --_i) {
        if (packageHoursDatas["jour" + (i + 1)] != null) {
          _results.push(this.days_package.push(new this.DisplayPackageHours(packageHoursDatas["jour" + (i + 1)], "jour" + (i + 1), this)));
        } else {
          _results.push(void 0);
        }
      }
      return _results;
    };

    MapDetailsOffice.prototype.openClosePackageHours = function() {
      $('.container-limit-hours-package').on('click', this.clickOpenClosePackageHoursHandler);
    };

    MapDetailsOffice.prototype.clickOpenClosePackageHoursHandler = function(e) {
      var $target, hoursUl;
      $target = $(e.currentTarget);
      $target.toggleClass('open');
      hoursUl = $target.find('.hours-ul');
      return hoursUl.slideToggle(250);
    };

    MapDetailsOffice.prototype.DisplayPackageHours = function(dayData, day, that) {
      this.day = that.getLabel(day);
      return this.hour = that.transformHour(dayData);
    };

    MapDetailsOffice.prototype.setOfficeServices = function() {
      var item, servicesDatas, servicesKeys, _i, _len, _results;
      servicesDatas = this.dataOffice.services;
      servicesKeys = Object.keys(servicesDatas);
      _results = [];
      for (_i = 0, _len = servicesKeys.length; _i < _len; _i++) {
        item = servicesKeys[_i];
        if (servicesDatas[item] === 'O') {
          _results.push(this.services.push(new this.DisplayService(item, servicesDatas[item], this)));
        }
      }
      return _results;
    };

    MapDetailsOffice.prototype.DisplayService = function(key, answer, that) {
      return this.service = that.getLabel(key);
    };

    MapDetailsOffice.prototype.setMapLink = function() {
      var itinerary;
      itinerary = $('.itinerary');
      itinerary.attr('href', "http://maps.apple.com/?q=" + this.dataOffice.adresse + " " + this.dataOffice.codePostal + " " + this.dataOffice.localite);
      return itinerary.on('click', function() {
        return Bridge.tracking(3, 'click', {
          "myPageLabel": "afficher_itineraire",
          "andPageChapter": "fiche_bureau"
        }, "navigation");
      });
    };

    MapDetailsOffice.prototype.resize = function() {
      var w;
      w = $('#app').width() - $('.container-hours .day-row').width() - $('.container-hours .hours-row').width() - 45;
      $('.container-hours .line-row').width(w);
      w = $('#app').width() - $('.container-limit-hours-package .day-row').width() - $('.container-limit-hours-package .hour-row').width() - 45;
      return $('.container-limit-hours-package .line-row').width(w);
    };

    MapDetailsOffice.getInstance = function(_this) {
      if (this.instance == null) {
        this.instance = _this;
      }
      return this.instance;
    };

    MapDetailsOffice.readyParseData = function() {
      var writeJsonPath;
      writeJsonPath = Helpers.convertAbsoluteToRelativeJsonPath(this.instance.getData().json.mapDetailsOffice);
      return Helpers.loadJson(writeJsonPath).done(this.instance.successLoadWriteJson).fail(this.instance.failLoadWriteJson);
    };

    MapDetailsOffice.callbackAddFavorite = function() {
      this.instance.favoriteLink.find('.star').removeClass('icon-star-inactive');
      return this.instance.favoriteLink.find('.star').addClass('icon-star-active');
    };

    MapDetailsOffice.callbackRemoveFavorite = function() {
      this.instance.favoriteLink.find('.star').removeClass('icon-star-active');
      return this.instance.favoriteLink.find('.star').addClass('icon-star-inactive');
    };

    return MapDetailsOffice;

  })(ManifestLoader);
  $(function() {
    return ko.applyBindings(new MapDetailsOffice());
  });
  return window.MapDetailsOffice = MapDetailsOffice;
})();
