var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

(function() {
  var ChooseTheGoodPacking;
  ChooseTheGoodPacking = (function(_super) {
    __extends(ChooseTheGoodPacking, _super);

    function ChooseTheGoodPacking() {
      this.setSlideshow = __bind(this.setSlideshow, this);
      this.failLoadChooseTheGoodPacking = __bind(this.failLoadChooseTheGoodPacking, this);
      this.successLoadChooseTheGoodPacking = __bind(this.successLoadChooseTheGoodPacking, this);
      var data;
      this.advices = ko.observableArray();
      data = $('#app').data('json');
      ChooseTheGoodPacking.__super__.constructor.call(this, data);
    }

    ChooseTheGoodPacking.prototype.isSuccessLoaded = function() {
      var jsonPath;
      jsonPath = Helpers.convertAbsoluteToRelativeJsonPath(this.getData().json.chooseTheGoodPacking);
      return Helpers.loadJson(jsonPath).done(this.successLoadChooseTheGoodPacking).fail(this.failLoadChooseTheGoodPacking);
    };

    ChooseTheGoodPacking.prototype.successLoadChooseTheGoodPacking = function(data) {
      this.data = data.advices;
      this.setAdvices();
      this.setSlideshow();
      Helpers.forceImgToRetina($('img'));
      Bridge.hideLoader();
      return Bridge.tracking(5, "page", {
        "myPageLabel": "choisir_un_emballage_adapte",
        "andPageChapter": "conseils_emballage"
      });
    };

    ChooseTheGoodPacking.prototype.failLoadChooseTheGoodPacking = function(error) {
      return console.log(error);
    };

    ChooseTheGoodPacking.prototype.setAdvices = function() {
      var i, _i, _ref, _results;
      _results = [];
      for (i = _i = 0, _ref = this.data.length; 0 <= _ref ? _i < _ref : _i > _ref; i = 0 <= _ref ? ++_i : --_i) {
        _results.push(this.advices.push(new this.DisplayAdvice(this.data[i], this)));
      }
      return _results;
    };

    ChooseTheGoodPacking.prototype.DisplayAdvice = function(data, that) {
      this.img = data.img;
      this.title = data.title;
      return this.description = data.description;
    };

    ChooseTheGoodPacking.prototype.setSlideshow = function() {
      var _this = this;
      return $('.flexslider').flexslider({
        animation: "slide",
        animationLoop: false,
        slideshow: false,
        directionNav: false,
        touch: true,
        start: function() {
          var nb;
          $('.flexslider').resize();
          nb = $('.flexslider').data('flexslider').count;
          if (nb > 4) {
            $('.flexslider .flex-control-nav li').css("margin", "0px");
            return $('.flexslider .flex-control-nav li a').css("width", "" + (($('#app').width() - 30) / nb) + "px");
          }
        }
      });
    };

    return ChooseTheGoodPacking;

  })(ManifestLoader);
  return $(function() {
    return ko.applyBindings(new ChooseTheGoodPacking());
  });
})();
