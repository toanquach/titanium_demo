var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

(function() {
  var ficheProduit;
  ficheProduit = (function(_super) {
    __extends(ficheProduit, _super);

    ficheProduit.prototype.instance = null;

    function ficheProduit() {
      this.clickAdviceHandler = __bind(this.clickAdviceHandler, this);
      this.successLoad = __bind(this.successLoad, this);
      var data;
      this.code = ko.observable();
      this.image = ko.observable();
      this.desc = ko.observable();
      this.prix = ko.observable();
      this.format = ko.observable();
      this.links = ko.observableArray();
      data = $('#app').data('json');
      ficheProduit.__super__.constructor.call(this, data);
    }

    ficheProduit.prototype.isSuccessLoaded = function() {
      this.codeStr = Helpers.getUrlVar("code");
      if (!this.codeStr) {
        window.location.href = "" + window.location.href + "?code=65489";
      }
      this.code(this.codeStr);
      return Helpers.loadJson(Helpers.convertAbsoluteToRelativeJsonPath(this.getData().json.ficheProduit)).done(this.successLoad).fail(this.failLoad);
    };

    ficheProduit.prototype.successLoad = function(data) {
      var product, productData, _i, _len, _ref;
      _ref = data.products;
      for (_i = 0, _len = _ref.length; _i < _len; _i++) {
        product = _ref[_i];
        if (product.id === this.codeStr) {
          productData = product;
        }
      }
      if (!productData) {
        return console.error("Product data not found, code used is " + this.codeStr);
      }
      this.fillLabels();
      $('.need-help').on('click', this.clickAdviceHandler);
      this.image(productData.image);
      this.desc(productData.desc);
      this.prix(productData.prix);
      this.format(productData.format);
      this.displayLinks(productData.links);
      Helpers.forceImgToRetina($('img'));
      Bridge.hideLoader();
      return Bridge.tracking(productData.tracking.setLevel2, "page", {
        "myPageLabel": "" + productData.tracking.myPageLabel,
        "andPageChapter": "" + productData.tracking.andPageChapter
      });
    };

    ficheProduit.prototype.displayLinks = function(data) {
      var i, _i, _ref, _results;
      _results = [];
      for (i = _i = 0, _ref = data.length; 0 <= _ref ? _i < _ref : _i > _ref; i = 0 <= _ref ? ++_i : --_i) {
        _results.push(this.links.push(new this.displayLink(data[i], this)));
      }
      return _results;
    };

    ficheProduit.prototype.displayLink = function(data, that) {
      this.label = data.label;
      this.link = data.link;
    };

    ficheProduit.prototype.clickAdviceHandler = function(e) {
      var completeUrl, target, url;
      e.preventDefault();
      target = e.currentTarget;
      url = $(target).attr('href');
      completeUrl = "" + (Helpers.getCurrentApp()) + "/views/" + url;
      return Bridge.displayPopin(completeUrl, null, "Service Conso");
    };

    return ficheProduit;

  })(ManifestLoader);
  return $(function() {
    return ko.applyBindings(new ficheProduit());
  });
})();
