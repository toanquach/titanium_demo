var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

(function() {
  var solutions;
  solutions = (function(_super) {
    __extends(solutions, _super);

    solutions.prototype.instance = null;

    function solutions() {
      this.successLoad = __bind(this.successLoad, this);
      var data;
      this.categories = ko.observableArray();
      data = $('#app').data('json');
      solutions.__super__.constructor.call(this, data);
    }

    solutions.prototype.isSuccessLoaded = function() {
      return Helpers.loadJson(Helpers.convertAbsoluteToRelativeJsonPath(this.getData().json.solutions)).done(this.successLoad).fail(this.failLoad);
    };

    solutions.prototype.successLoad = function(data) {
      this.data = data.cat;
      this.displayCategories();
      Bridge.hideLoader();
      return Bridge.tracking(4, "page", {
        "myPageLabel": "solutions",
        "andPageChapter": "expedier_avec_suivi::vue_d_ensemble"
      });
    };

    solutions.prototype.displayCategories = function() {
      var i, _i, _ref, _results;
      _results = [];
      for (i = _i = 0, _ref = this.data.length; 0 <= _ref ? _i < _ref : _i > _ref; i = 0 <= _ref ? ++_i : --_i) {
        _results.push(this.categories.push(new this.displayCategory(this.data[i], this)));
      }
      return _results;
    };

    solutions.prototype.displayCategory = function(data, that) {
      this.title = data.title;
      this.desc = data.desc;
      this.links = ko.observableArray();
      that.displayLinks(data.links, this);
    };

    solutions.prototype.displayLinks = function(data, that) {
      var i, _i, _ref, _results;
      _results = [];
      for (i = _i = 0, _ref = data.length; 0 <= _ref ? _i < _ref : _i > _ref; i = 0 <= _ref ? ++_i : --_i) {
        _results.push(that.links.push(new this.displayLink(data[i])));
      }
      return _results;
    };

    solutions.prototype.displayLink = function(data) {
      this.label = data.label;
      return this.link = data.link;
    };

    return solutions;

  })(ManifestLoader);
  return $(function() {
    return ko.applyBindings(new solutions());
  });
})();
