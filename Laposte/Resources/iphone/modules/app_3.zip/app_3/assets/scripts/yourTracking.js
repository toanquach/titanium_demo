var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

(function() {
  var yourTracking;
  yourTracking = (function(_super) {
    __extends(yourTracking, _super);

    yourTracking.prototype.instance = null;

    function yourTracking() {
      this.setNotification = __bind(this.setNotification, this);
      this.successLoad = __bind(this.successLoad, this);
      var data;
      this.code = ko.observable();
      this.steps = ko.observableArray();
      this.link = ko.observable();
      this.display = false;
      data = $('#app').data('json');
      yourTracking.__super__.constructor.call(this, data);
    }

    yourTracking.prototype.isSuccessLoaded = function() {
      return Helpers.loadJson(Helpers.convertAbsoluteToRelativeJsonPath(this.getData().json.yourTracking)).done(this.successLoad).fail(this.failLoad);
    };

    yourTracking.prototype.successLoad = function(data) {
      this.fillLabels();
      this.pkg = data;
      this.id = data.code;
      this.code(this.id);
      this.link(data.link);
      this.steps.push(new this.displayStep(data, this));
      if (data.favorite === 1) {
        yourTracking.callbackAddNotification();
      }
      return $(".notification").on('click', this.setNotification);
    };

    yourTracking.prototype.testShowPage = function() {
      if (!this.display) {
        this.display = true;
        return this.showPage();
      }
    };

    yourTracking.prototype.showPage = function() {
      Helpers.forceImgToRetina($('img'));
      $('.need-help').on('click', function(e) {
        var url;
        e.preventDefault();
        url = $(e.currentTarget).attr('href');
        url = url.replace(" ", "");
        return Bridge.externalLink(url);
      });
      Bridge.hideLoader();
      return Bridge.tracking(4, "page", {
        "myPageLabel": "fiche_suivi_detaille",
        "andPageChapter": "suivi_des_envois"
      });
    };

    yourTracking.prototype.displayStep = function(data, that) {
      var step;
      step = this;
      this.label = data.message;
      this.time = "Le " + data.date;
      this.type = ko.observable();
      Helpers.loadJson(Helpers.convertAbsoluteToRelativeJsonPath(that.getData().json.trackingMessage)).done(function(data) {
        var i, y, _i, _j, _ref, _ref1;
        step.type("../assets/images/step2.png");
        for (i = _i = 0, _ref = data.types.length; 0 <= _ref ? _i < _ref : _i > _ref; i = 0 <= _ref ? ++_i : --_i) {
          for (y = _j = 0, _ref1 = data.types[i].msg.length; 0 <= _ref1 ? _j < _ref1 : _j > _ref1; y = 0 <= _ref1 ? ++_j : --_j) {
            if (step.label === data.types[i].msg[y]) {
              step.type("../assets/images/" + data.types[i].type + ".png");
              that.testShowPage();
            }
          }
        }
        that.testShowPage();
      });
    };

    yourTracking.prototype.setNotification = function(e) {
      e.preventDefault();
      if ($(e.currentTarget).find('.icon-bell-active').length) {
        if (Helpers.isWebApp()) {
          Bridge.addNotif("unsubscribe", this.id);
          return yourTracking.callbackRemoveNotification();
        } else {
          Bridge.addNotif("unsubscribe", this.id);
          return yourTracking.callbackRemoveNotification();
        }
      } else {
        if (Helpers.isWebApp()) {
          Bridge.addNotif("subscribe", this.id);
          return yourTracking.callbackAddNotification();
        } else {
          Bridge.addNotif("subscribe", this.id);
          return yourTracking.callbackAddNotification();
        }
      }
    };

    yourTracking.callbackAddNotification = function() {
      return $(".icon-bell-inactive").removeClass("icon-bell-inactive").addClass("icon-bell-active");
    };

    yourTracking.callbackRemoveNotification = function() {
      return $(".icon-bell-active").removeClass("icon-bell-active").addClass("icon-bell-inactive");
    };

    return yourTracking;

  })(ManifestLoader);
  return $(function() {
    return ko.applyBindings(new yourTracking());
  });
})();
