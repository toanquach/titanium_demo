var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

(function() {
  var ResultZipcodeCity;
  ResultZipcodeCity = (function(_super) {
    __extends(ResultZipcodeCity, _super);

    function ResultZipcodeCity() {
      this.failLoadResult = __bind(this.failLoadResult, this);
      this.successLoadResult = __bind(this.successLoadResult, this);
      var data;
      this.codePostal = ko.observable();
      this.commune = ko.observable();
      this.infos = ko.observable();
      data = $('#app').data('json');
      ResultZipcodeCity.__super__.constructor.call(this, data);
    }

    ResultZipcodeCity.prototype.isSuccessLoaded = function() {
      var jsonPath;
      jsonPath = Helpers.convertAbsoluteToRelativeJsonPath(this.getData().json.resultZipcodeCity);
      return Helpers.loadJson(jsonPath).done(this.successLoadResult).fail(this.failLoadResult);
    };

    ResultZipcodeCity.prototype.successLoadResult = function(data) {
      var id;
      id = Helpers.getUrlVar("id");
      if (id == null) {
        id = 0;
      }
      this.dataResult = data.codePostaux[id];
      this.fillLabels();
      this.fillDatas();
      Bridge.hideLoader();
      Bridge.navigationTitle(this.getLabel("navigation_title"));
      return Bridge.tracking(5, "page", {
        "myPageLabel": "resultat_recherche",
        "andPageChapter": "recherche_cp_ville"
      });
    };

    ResultZipcodeCity.prototype.failLoadResult = function(error) {
      return console.log(error);
    };

    ResultZipcodeCity.prototype.fillDatas = function() {
      this.codePostal(this.dataResult.codePostal);
      this.commune(this.dataResult.commune);
      this.infos("" + (this.getLabel('search-contact-point')) + " " + (this.dataResult.commune.toUpperCase()) + " " + (this.getLabel('interrogation')));
      return this.bindClick("" + this.dataResult.codePostal + " " + this.dataResult.commune);
    };

    ResultZipcodeCity.prototype.bindClick = function(param) {
      return $('.poste').find('a').on('click', function(e) {
        e.preventDefault();
        return Bridge.switchModule("app_5", "app_5/views/map.html?query=" + param);
      });
    };

    return ResultZipcodeCity;

  })(ManifestLoader);
  return $(function() {
    return ko.applyBindings(new ResultZipcodeCity());
  });
})();
