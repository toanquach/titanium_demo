var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

(function() {
  var TestAddressForm;
  TestAddressForm = (function(_super) {
    __extends(TestAddressForm, _super);

    TestAddressForm.prototype.instance = null;

    function TestAddressForm() {
      this.checkResults = __bind(this.checkResults, this);
      this.clickCrossErrorHandler = __bind(this.clickCrossErrorHandler, this);
      this.submitHandler = __bind(this.submitHandler, this);
      var data;
      this.error_address = ko.observable();
      this.error_zipcode = ko.observable();
      this.error_city = ko.observable();
      data = $('#app').data('json');
      TestAddressForm.__super__.constructor.call(this, data);
    }

    TestAddressForm.prototype.isSuccessLoaded = function() {
      TestAddressForm.getInstance(this);
      this.fillLabels();
      this.fillAttributes();
      Bridge.hideLoader();
      Bridge.tracking(5, "page", {
        "myPageLabel": "formulaire",
        "andPageChapter": "test_d_adresse"
      });
      $('form').on('submit', this.submitHandler);
    };

    TestAddressForm.prototype.submitHandler = function(e) {
      e.preventDefault();
      $(e.currentTarget).find('input').blur();
      Bridge.displayLoader();
      return TestAddressForm.testAddress();
    };

    TestAddressForm.prototype.clickCrossErrorHandler = function(e) {
      if ($(e.currentTarget).parent().data('error') === "address") {
        this.error_address(false);
      }
      if ($(e.currentTarget).parent().data('error') === "zipcode") {
        $('.form-input-texts').find('[name=zipcode]').val("");
        this.error_zipcode(false);
      }
      if ($(e.currentTarget).parent().data('error') === "city") {
        return this.error_city(false);
      }
    };

    TestAddressForm.prototype.successResultTestAddress = function(data) {
      console.log(data);
      console.log('=> Si plusieurs résultats : load page "Affiner votre adresse"');
      return console.log('=> Sinon load page "Adresse corrigée"');
    };

    TestAddressForm.prototype.failResultTestAddress = function(error) {
      return console.log(error);
    };

    TestAddressForm.prototype.failLoadWriteJson = function() {
      return console.log("failLoadWriteJson");
    };

    TestAddressForm.prototype.checkResults = function(data) {
      if (data.adresse.ligne1.feu.couleur !== "rouge" && data.adresse.ligne2.feu.couleur !== "rouge" && data.adresse.ligne3.feu.couleur !== "rouge" && data.adresse.ligne4.feu.couleur !== "rouge" && data.adresse.ligne6.feu.couleur !== "rouge") {
        return Bridge.redirect("app_2/views/resultAddress.html");
      } else {
        return Bridge.redirect("app_2/views/refineAddress.html");
      }
    };

    TestAddressForm.getInstance = function(_this) {
      if (this.instance == null) {
        this.instance = _this;
      }
      return this.instance;
    };

    TestAddressForm.testAddress = function() {
      var address, address2, city, error, firstname, floor, lastname, params, residence, zipcode;
      error = 0;
      $('.icon-error').off('click', this.instance.clickCrossErrorHandler);
      this.instance.error_address(false);
      this.instance.error_zipcode(false);
      this.instance.error_city(false);
      params = {};
      address = $('form').find('[name=address]').val();
      if (address.trim() === "") {
        error++;
        this.instance.error_address(true);
        $('.form-input-texts').find('.error[data-error=address] p').html(this.instance.getLabel('address_empty'));
      } else {
        params.ligne4 = address;
      }
      zipcode = $('form').find('[name=zipcode]').val().trim();
      if (zipcode.trim() === "") {
        error++;
        this.instance.error_zipcode(true);
        $('.form-input-texts').find('.error[data-error=zipcode] p').html(this.instance.getLabel('code_postal_empty'));
      } else if (!Helpers.isZipcode(zipcode)) {
        error++;
        this.instance.error_zipcode(true);
        $('.form-input-texts').find('.error[data-error=zipcode] p').html(this.instance.getLabel('code_postal_error'));
      } else {
        params.ligne6 = zipcode;
      }
      city = $('form').find('[name=city]').val();
      if (city.trim() === "") {
        error++;
        this.instance.error_city(true);
        $('.form-input-texts').find('.error[data-error=city] p').html(this.instance.getLabel('city_empty'));
      } else {
        if (params.ligne6 != null) {
          params.ligne6 += ' ';
        }
        params.ligne6 += city;
      }
      if (error > 0) {
        $('.icon-error').on('click', this.instance.clickCrossErrorHandler);
        return Bridge.hideLoader(false);
      } else {
        lastname = $('form').find('[name=lastname]').val();
        if (lastname.trim() !== "") {
          params.nom = lastname;
        }
        firstname = $('form').find('[name=firstname]').val();
        if (firstname.trim() !== "") {
          params.prenom = firstname;
        }
        residence = $('form').find('[name=residence]').val();
        if (residence.trim() !== "") {
          params.ligne3 = residence;
        }
        floor = $('form').find('[name=floor]').val();
        if (floor.trim() !== "") {
          params.ligne2 = floor;
        }
        address2 = $('form').find('[name=address2]').val();
        if (address2.trim() !== "") {
          params.ligne5 = address2;
        }
        console.log(params);
        Webservices.callService(this.instance.getData().webservices.addressTest, {}, params, this.successWS, this.failWS);
      }
    };

    TestAddressForm.successWS = function(data) {
      if (Helpers.isWebApp()) {
        return Bridge.writeJSON(TestAddressForm.instance.getData().json.resultTestAddress, data, "TestAddressForm.readResults()", false, "");
      } else {
        return TestAddressForm.instance.checkResults(data);
      }
    };

    TestAddressForm.failWS = function(data) {
      return console.log("failWS");
    };

    TestAddressForm.readResults = function() {
      var writeJsonPath;
      writeJsonPath = Helpers.convertAbsoluteToRelativeJsonPath(this.instance.getData().json.resultTestAddress);
      Helpers.loadJson(writeJsonPath).done(this.instance.checkResults).fail(this.instance.failLoadWriteJson);
    };

    return TestAddressForm;

  }).call(this, ManifestLoader);
  window.TestAddressForm = TestAddressForm;
  return $(function() {
    return ko.applyBindings(new TestAddressForm());
  });
})();
