var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

(function() {
  var servicesConso;
  servicesConso = (function(_super) {
    __extends(servicesConso, _super);

    function servicesConso() {
      this.successLoad = __bind(this.successLoad, this);
      var data;
      this.illustration = ko.observable();
      this.mail = ko.observable();
      this.informations = ko.observable();
      this.socials = ko.observableArray();
      this.phone = ko.observable();
      data = $('#app').data('json');
      servicesConso.__super__.constructor.call(this, data);
    }

    servicesConso.prototype.isSuccessLoaded = function() {
      return Helpers.loadJson(Helpers.convertAbsoluteToRelativeJsonPath(this.getData().json.serviceConso)).done(this.successLoad).fail(this.failLoad);
    };

    servicesConso.prototype.successLoad = function(data) {
      this.illustration(data.img);
      this.mail(new this.setMail(data.mail));
      this.informations(new this.setInfos(data.infos, this));
      this.displaySocials(data.socials);
      this.phone(new this.setPhone(data.phone, this));
      this.fillLabels();
      if (Helpers.isAndroid()) {
        Helpers.forceImgToRetina();
      }
      Bridge.hideLoader();
      return Bridge.navigationTitle(data.title);
    };

    servicesConso.prototype.setMail = function(data) {
      this.title = data.title;
      this.img = data.img;
      return this.address = data.address;
    };

    servicesConso.prototype.setInfos = function(data, that) {
      this.text = data.text;
      this.details = ko.observableArray();
      that.displayDetails(data.details, this.details);
    };

    servicesConso.prototype.displayDetails = function(data, details) {
      var i, _i, _ref, _results;
      _results = [];
      for (i = _i = 0, _ref = data.length; 0 <= _ref ? _i < _ref : _i > _ref; i = 0 <= _ref ? ++_i : --_i) {
        _results.push(details.push(new this.displayDetail(data[i])));
      }
      return _results;
    };

    servicesConso.prototype.displayDetail = function(data) {
      return this.detail = data;
    };

    servicesConso.prototype.displaySocials = function(data) {
      var i, _i, _ref, _results;
      _results = [];
      for (i = _i = 0, _ref = data.length; 0 <= _ref ? _i < _ref : _i > _ref; i = 0 <= _ref ? ++_i : --_i) {
        _results.push(this.socials.push(new this.displaySocial(data[i])));
      }
      return _results;
    };

    servicesConso.prototype.displaySocial = function(data) {
      this.title = data.title;
      this.img = data.img;
      return this.desc = data.desc;
    };

    servicesConso.prototype.setPhone = function(data, that) {
      this.title = data.title;
      this.img = data.img;
      this.contacts = ko.observableArray();
      that.displayContacts(data.details, this.contacts);
    };

    servicesConso.prototype.displayContacts = function(data, contacts) {
      var i, _i, _ref, _results;
      _results = [];
      for (i = _i = 0, _ref = data.length; 0 <= _ref ? _i < _ref : _i > _ref; i = 0 <= _ref ? ++_i : --_i) {
        _results.push(contacts.push(new this.displayContact(data[i])));
      }
      return _results;
    };

    servicesConso.prototype.displayContact = function(data) {
      this.number = data.number;
      this.name = data.name;
      this.infos = data.infos;
      return this.horaires = data.horaires;
    };

    return servicesConso;

  })(ManifestLoader);
  return $(function() {
    return ko.applyBindings(new servicesConso());
  });
})();
