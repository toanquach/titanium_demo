var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

(function() {
  var multichoices;
  multichoices = (function(_super) {
    __extends(multichoices, _super);

    multichoices.prototype.instance = null;

    function multichoices() {
      this.successLoad = __bind(this.successLoad, this);
      var data;
      this.categories = ko.observableArray();
      this.title = ko.observable();
      data = $('#app').data('json');
      multichoices.__super__.constructor.call(this, data);
    }

    multichoices.prototype.isSuccessLoaded = function() {
      return Helpers.loadJson(Helpers.convertAbsoluteToRelativeJsonPath(this.getData().json[$('body').attr("class").replace("multichoices", "").replace(" ", "")])).done(this.successLoad).fail(this.failLoad);
    };

    multichoices.prototype.successLoad = function(data) {
      var andPageChapter;
      this.title(data.title);
      this.data = data.cat;
      this.displayCategories();
      Helpers.forceImgToRetina($('img'));
      Bridge.hideLoader();
      if (data.tracking != null) {
        if (Helpers.getUrlVar("type") != null) {
          andPageChapter = data.tracking.andPageChapter.replace("_TYPE_", Helpers.getUrlVar("type"));
        } else {
          andPageChapter = data.tracking.andPageChapter;
        }
        return Bridge.tracking(data.tracking.setLevel2, "page", {
          "myPageLabel": data.tracking.myPageLabel,
          "andPageChapter": andPageChapter
        });
      }
    };

    multichoices.prototype.displayCategories = function() {
      var i, _i, _ref, _results;
      _results = [];
      for (i = _i = 0, _ref = this.data.length; 0 <= _ref ? _i < _ref : _i > _ref; i = 0 <= _ref ? ++_i : --_i) {
        _results.push(this.categories.push(new this.displayCategory(this.data[i], this)));
      }
      return _results;
    };

    multichoices.prototype.displayCategory = function(data, that) {
      this.title = data.title;
      this.links = ko.observableArray();
      that.displayLinks(data.links, this);
    };

    multichoices.prototype.displayLinks = function(data, that) {
      var i, _i, _ref, _results;
      _results = [];
      for (i = _i = 0, _ref = data.length; 0 <= _ref ? _i < _ref : _i > _ref; i = 0 <= _ref ? ++_i : --_i) {
        _results.push(that.links.push(new this.displayLink(data[i])));
      }
      return _results;
    };

    multichoices.prototype.displayLink = function(data) {
      this.label = data.label;
      if (Helpers.getUrlVar("type") != null) {
        this.link = "" + data.link + "?type=" + (Helpers.getUrlVar("type"));
      } else {
        this.link = data.link;
      }
      if (data.type.length) {
        this.type = data.type;
      } else {
        this.type = "";
      }
      return this.desc = data.desc;
    };

    return multichoices;

  })(ManifestLoader);
  return $(function() {
    return ko.applyBindings(new multichoices());
  });
})();
