var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

(function() {
  var Facebook;
  Facebook = (function(_super) {
    __extends(Facebook, _super);

    function Facebook() {
      this.failGetFacebookAlbums = __bind(this.failGetFacebookAlbums, this);
      this.successGetFacebookAlbums = __bind(this.successGetFacebookAlbums, this);
      var data;
      this.albums = ko.observableArray();
      data = $('#app').data('json');
      Facebook.__super__.constructor.call(this, data);
    }

    Facebook.prototype.isSuccessLoaded = function() {
      if (Helpers.getUrlVar('accesstoken') != null) {
        this.accessToken = Helpers.getUrlVar('accesstoken');
        this.getFacebookAlbums();
      } else {
        this.loginFacebook();
      }
      this.fillLabels();
      Bridge.hideLoader();
      Bridge.navigationTitle(this.getLabel("title"));
      return Bridge.tracking(7, "page", {
        "myPageLabel": "facebook",
        "andPageChapter": "envoyer_une_carte::selection::facebook"
      });
    };

    Facebook.prototype.loginFacebook = function() {
      var appId, currentUrl, permissionUrl, redirectPage, scope;
      appId = this.getData().facebook.appId;
      scope = this.getData().facebook.scope;
      redirectPage = this.getData().facebook.redirect;
      permissionUrl = "https://www.facebook.com/dialog/oauth?client_id=" + appId + "&client_secret=6aee16ceecf89b72ace0b4c0ddadb6fd&response_type=token&redirect_uri=" + redirectPage + "&scope=" + scope;
      currentUrl = window.location.href;
      return Bridge.socialNetworkCnx(permissionUrl, currentUrl);
    };

    Facebook.prototype.getFacebookAlbums = function() {
      var graphUrl;
      Bridge.displayLoader();
      graphUrl = "https://graph.facebook.com/me/albums?access_token=" + this.accessToken;
      return $.getJSON(graphUrl).done(this.successGetFacebookAlbums).fail(this.failGetFacebookAlbums);
    };

    Facebook.prototype.successGetFacebookAlbums = function(response) {
      var item, _i, _len, _ref, _results;
      Bridge.hideLoader(false);
      _ref = response.data;
      _results = [];
      for (_i = 0, _len = _ref.length; _i < _len; _i++) {
        item = _ref[_i];
        _results.push(this.albums.push(new this.DisplayAlbum(item, this)));
      }
      return _results;
    };

    Facebook.prototype.failGetFacebookAlbums = function(error) {
      Bridge.hideLoader(false);
      return console.log(error);
    };

    Facebook.prototype.DisplayAlbum = function(data, that) {
      this.link = "facebookAlbum.html?id=" + data.id + "&name=" + (encodeURI(data.name)) + "&accesstoken=" + that.accessToken;
      this.img = ko.observable("url(https://graph.facebook.com/" + data.cover_photo + "/picture?type=album&access_token=" + that.accessToken + ")");
      this.title = data.name;
      return this;
    };

    return Facebook;

  })(ManifestLoader);
  return $(function() {
    return ko.applyBindings(new Facebook());
  });
})();
