var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

(function() {
  var Emballage;
  Emballage = (function(_super) {
    __extends(Emballage, _super);

    Emballage.prototype.instance = null;

    function Emballage() {
      this.choosePath = __bind(this.choosePath, this);
      this.successWS = __bind(this.successWS, this);
      this.successLoadParams = __bind(this.successLoadParams, this);
      var data;
      this.links = ko.observableArray();
      this.title = ko.observable();
      data = $('#app').data('json');
      Emballage.__super__.constructor.call(this, data);
    }

    Emballage.prototype.isSuccessLoaded = function() {
      return Helpers.loadJson(Helpers.convertAbsoluteToRelativeJsonPath(this.getData().json.params)).done(this.successLoadParams).fail(this.failLoadParams);
    };

    Emballage.prototype.successLoadParams = function(data) {
      var params, type;
      this.params = data;
      if (data.params.destination === "international") {
        type = "etranger";
      } else {
        type = data.params.destination;
      }
      params = $.extend({
        'task': 'emballage'
      }, {
        'type': type,
        'nature': Helpers.getUrlVar('nature')
      });
      return WebservicesCalculDeTarifs.callService(this.getData().webservices.affranchir, params, {}, this.successWS, this.failWS);
    };

    Emballage.prototype.successWS = function(data) {
      Emballage.getInstance(this);
      this.title(this.getLabel("contenuMainTitle"));
      data = Helpers.xmlToJson(data);
      this.link = data.Requete.liste_emballage.emballage;
      this.displayLinks();
      Helpers.forceImgToRetina($('img'));
      $('body').on('click', 'a', this.choosePath);
      return Bridge.hideLoader();
    };

    Emballage.prototype.displayLinks = function() {
      var i, _i, _ref, _results;
      _results = [];
      for (i = _i = 0, _ref = this.link.length; 0 <= _ref ? _i < _ref : _i > _ref; i = 0 <= _ref ? ++_i : --_i) {
        if (this.link[i].id_emballage['#text'] !== "P" && this.link[i].id_emballage['#text'] !== "SPL" && !(this.params.params.destination === "France Métropolitaine" && this.link[i].id_emballage['#text'] === "P2")) {
          _results.push(this.links.push(new this.displayLink(this.link[i], this)));
        } else {
          _results.push(void 0);
        }
      }
      return _results;
    };

    Emballage.prototype.displayLink = function(data, that) {
      var destination;
      this.link = "app_4/views/affranchissement.html";
      this.value = JSON.stringify({
        "emballage": data.id_emballage['#text']
      });
      switch (that.params.params.destination) {
        case "France Métropolitaine":
          destination = "FR";
          break;
        case "DOM/TOM":
          destination = "OM";
          break;
        case "international":
          destination = "INT";
      }
      this.type = "../assets/images/" + data.id_emballage['#text'] + "-" + destination + ".png";
      return this.label = data.nom_fr['#text'];
    };

    Emballage.prototype.choosePath = function(e) {
      e.preventDefault();
      this.redirection = $(e.currentTarget).attr('href');
      $.extend(this.params.params, $(e.currentTarget).data('value'));
      $.extend(this.params.summary, {
        "emballage": $(e.currentTarget).find('.label').text(),
        "image": $(e.currentTarget).find('img').attr('src').replace('@2x', '')
      });
      if (Helpers.isWebApp()) {
        return Bridge.writeJSON(this.getData().json.params, this.params, "Emballage.gotoNext()", false, "");
      } else {
        return Emballage.gotoNext();
      }
    };

    Emballage.getInstance = function(_this) {
      if (this.instance == null) {
        this.instance = _this;
      }
      return this.instance;
    };

    Emballage.gotoNext = function() {
      return Bridge.redirect(this.instance.redirection);
    };

    return Emballage;

  })(ManifestLoader);
  window.Emballage = Emballage;
  return $(function() {
    return ko.applyBindings(new Emballage());
  });
})();
