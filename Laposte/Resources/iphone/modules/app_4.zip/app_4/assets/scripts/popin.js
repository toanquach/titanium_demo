var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

(function() {
  var popin;
  popin = (function(_super) {
    __extends(popin, _super);

    function popin() {
      this.clickHandler = __bind(this.clickHandler, this);
      this.successLoad = __bind(this.successLoad, this);
      var data;
      this.illustration = ko.observable();
      this.categories = ko.observableArray();
      this.number = ko.observable();
      data = $('#app').data('json');
      popin.__super__.constructor.call(this, data);
    }

    popin.prototype.isSuccessLoaded = function() {
      return Helpers.loadJson(Helpers.convertAbsoluteToRelativeJsonPath(this.getData().json.popin)).done(this.successLoad).fail(this.failLoad);
    };

    popin.prototype.successLoad = function(data) {
      data = data[Helpers.getUrlVar("page")];
      this.illustration(data.img);
      this.displayCategories(data.cat);
      if (data.number != null) {
        this.number(data.number);
      }
      Helpers.forceImgToRetina($('img'));
      $('body').on('click', '.link', this.clickHandler);
      return Bridge.hideLoader();
    };

    popin.prototype.displayCategories = function(cat) {
      var i, _i, _ref, _results;
      _results = [];
      for (i = _i = 0, _ref = cat.length; 0 <= _ref ? _i < _ref : _i > _ref; i = 0 <= _ref ? ++_i : --_i) {
        _results.push(this.categories.push(new this.displayCategory(cat[i], this)));
      }
      return _results;
    };

    popin.prototype.displayCategory = function(data, that) {
      this.title = data.title;
      this.text = data.text;
      this.suppinfos = data.suppinfos;
      this.link = data.link;
    };

    popin.prototype.clickHandler = function(e) {
      e.preventDefault();
      return Bridge.externalLink($(e.currentTarget).find('a').attr('href'));
    };

    return popin;

  })(ManifestLoader);
  return $(function() {
    return ko.applyBindings(new popin());
  });
})();
