(function() {
  var WebservicesCalculDeTarifs;
  WebservicesCalculDeTarifs = (function() {
    function WebservicesCalculDeTarifs() {}

    WebservicesCalculDeTarifs.cpt = 0;

    WebservicesCalculDeTarifs.webservices = null;

    WebservicesCalculDeTarifs.token = "";

    WebservicesCalculDeTarifs.callService = function(wsPath, paramsMandatory, paramsOptionnal, callbackSuccess, callbackError) {
      var commonDataPath;
      this.wsPath = wsPath;
      this.paramsMandatory = paramsMandatory;
      this.paramsOptionnal = paramsOptionnal;
      this.callbackSuccess = callbackSuccess;
      this.callbackError = callbackError;
      if (this.webservices == null) {
        commonDataPath = $('#app').data('common-json');
        return this.loadCommsonJson(commonDataPath);
      } else {
        this.buildWebserviceUrl();
        return this.callWebservice();
      }
    };

    WebservicesCalculDeTarifs.loadCommsonJson = function(commonDataPath) {
      $.ajaxSetup({
        cache: false
      });
      return $.getJSON(commonDataPath).done(this.successLoadCommonJson).fail(this.failLoadCommonJson);
    };

    WebservicesCalculDeTarifs.buildWebserviceUrl = function() {
      this.token = md5("" + this.webservices.key + this.token);
      this.id = this.webservices.id;
      this.urlService = "" + this.wsPath;
      return this.params = $.extend({
        "id": this.id,
        "session": this.token
      }, this.paramsMandatory);
    };

    WebservicesCalculDeTarifs.callWebservice = function() {
      var _this = this;
      setTimeout((function() {
        $.ajax({
          url: _this.urlService,
          dataType: 'xml',
          data: _this.params,
          type: "POST",
          error: _this.errorWebservice,
          success: _this.successWebservice,
          fail: _this.failWebservice
        });
      }), 500);
    };

    WebservicesCalculDeTarifs.successLoadCommonJson = function(data) {
      WebservicesCalculDeTarifs.webservices = data.data.webservices;
      WebservicesCalculDeTarifs.token = WebservicesCalculDeTarifs.webservices.token;
      return WebservicesCalculDeTarifs.callService(WebservicesCalculDeTarifs.wsPath, WebservicesCalculDeTarifs.paramsMandatory, WebservicesCalculDeTarifs.paramsOptionnal, WebservicesCalculDeTarifs.callbackSuccess, WebservicesCalculDeTarifs.callbackError);
    };

    WebservicesCalculDeTarifs.failLoadCommonJson = function(error) {
      return WebservicesCalculDeTarifs.callbackError();
    };

    WebservicesCalculDeTarifs.retryCallWebservice = function(dataObj) {
      if (this.cpt < 5) {
        this.cpt++;
        this.buildWebserviceUrl();
        return this.callWebservice();
      } else {
        return this.callbackError(dataObj);
      }
    };

    WebservicesCalculDeTarifs.successWebservice = function(dataObj, status) {
      var error;
      WebservicesCalculDeTarifs.token = $(dataObj).find("token").text();
      error = $(dataObj).find("error").text();
      Bridge.writeToken(WebservicesCalculDeTarifs.token);
      if (error.length) {
        switch (error) {
          case "Erreur : ce Tarif n'est pas disponible":
          case "Erreur : le code site \"dom_com\" n'éxiste pas":
          case "Erreur : parametres \"gr\" invalide":
            return WebservicesCalculDeTarifs.callbackSuccess(dataObj);
          default:
            return WebservicesCalculDeTarifs.retryCallWebservice(dataObj);
        }
      } else {
        return WebservicesCalculDeTarifs.callbackSuccess(dataObj);
      }
    };

    WebservicesCalculDeTarifs.failWebservice = function(dataObj, status, typeError) {
      WebservicesCalculDeTarifs.error = dataObj.error;
      WebservicesCalculDeTarifs.token = dataObj.token;
      Bridge.writeToken(WebservicesCalculDeTarifs.token);
      return WebservicesCalculDeTarifs.retryCallWebservice(dataObj);
    };

    WebservicesCalculDeTarifs.errorWebservice = function(dataObj, status, typeError) {
      WebservicesCalculDeTarifs.error = $(dataObj).responseXML.error;
      WebservicesCalculDeTarifs.token = dataObj.responseXML.token;
      Bridge.writeToken(WebservicesCalculDeTarifs.token);
      return WebservicesCalculDeTarifs.retryCallWebservice(dataObj.responseXML);
    };

    return WebservicesCalculDeTarifs;

  }).call(this);
  return window.WebservicesCalculDeTarifs = WebservicesCalculDeTarifs;
})();
