var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

(function() {
  var MenuFormatPicture;
  MenuFormatPicture = (function(_super) {
    __extends(MenuFormatPicture, _super);

    function MenuFormatPicture() {
      this.clickChoosePicture = __bind(this.clickChoosePicture, this);
      this.clickTakePicture = __bind(this.clickTakePicture, this);
      this.failLoadMenuDatas = __bind(this.failLoadMenuDatas, this);
      this.successLoadMenuDatas = __bind(this.successLoadMenuDatas, this);
      var data;
      this.items = ko.observableArray();
      this.id = 1;
      data = $('#app').data('json');
      MenuFormatPicture.__super__.constructor.call(this, data);
    }

    MenuFormatPicture.prototype.isSuccessLoaded = function() {
      var jsonPath;
      jsonPath = Helpers.convertAbsoluteToRelativeJsonPath(this.getData().json.menuFormatPicture);
      return Helpers.loadJson(jsonPath).done(this.successLoadMenuDatas).fail(this.failLoadMenuDatas);
    };

    MenuFormatPicture.prototype.successLoadMenuDatas = function(data) {
      this.setMenu(data.menu);
      Helpers.forceImgToRetina($('img'));
      Bridge.hideLoader();
      Bridge.navigationTitle(this.getLabel("title"));
      return Bridge.tracking(7, "page", {
        "myPageLabel": "accueil",
        "andPageChapter": "envoyer_une_carte::accueil"
      });
    };

    MenuFormatPicture.prototype.failLoadMenuDatas = function(error) {
      return console.log(error);
    };

    MenuFormatPicture.prototype.setMenu = function(data) {
      var item, _i, _len;
      for (_i = 0, _len = data.length; _i < _len; _i++) {
        item = data[_i];
        this.items.push(new this.DisplayMenuItem(item, this));
      }
      $('.take-picture').on('click', this.clickTakePicture);
      return $('.choose-picture').on('click', this.clickChoosePicture);
    };

    MenuFormatPicture.prototype.DisplayMenuItem = function(data, that) {
      this.link = data.link;
      this.img = data.img;
      this.title = data.title;
      return this.className = data["class"];
    };

    MenuFormatPicture.prototype.clickTakePicture = function(e) {
      e.preventDefault();
      if (this.id === 1) {
        this.id = 2;
        return Bridge.openCamera("app_7/views/cropImage.html");
      } else {
        this.id = 1;
        return Bridge.openCamera("app_7/views/cropImage2.html");
      }
    };

    MenuFormatPicture.prototype.clickChoosePicture = function(e) {
      e.preventDefault();
      if (this.id === 1) {
        this.id = 2;
        return Bridge.openPhotoLibrary("app_7/views/cropImage.html");
      } else {
        this.id = 1;
        return Bridge.openPhotoLibrary("app_7/views/cropImage2.html");
      }
    };

    return MenuFormatPicture;

  })(ManifestLoader);
  return $(function() {
    return ko.applyBindings(new MenuFormatPicture());
  });
})();
