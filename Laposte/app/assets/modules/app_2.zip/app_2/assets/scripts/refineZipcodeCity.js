var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

(function() {
  var RefineZipcodeCity;
  RefineZipcodeCity = (function(_super) {
    __extends(RefineZipcodeCity, _super);

    function RefineZipcodeCity() {
      this.failLoadResults = __bind(this.failLoadResults, this);
      this.successLoadResults = __bind(this.successLoadResults, this);
      var data;
      this.results = ko.observableArray();
      data = $('#app').data('json');
      RefineZipcodeCity.__super__.constructor.call(this, data);
    }

    RefineZipcodeCity.prototype.isSuccessLoaded = function() {
      var jsonPath;
      jsonPath = Helpers.convertAbsoluteToRelativeJsonPath(this.getData().json.resultZipcodeCity);
      return Helpers.loadJson(jsonPath).done(this.successLoadResults).fail(this.failLoadResults);
    };

    RefineZipcodeCity.prototype.successLoadResults = function(data) {
      this.datas = data.codePostaux;
      this.nbResults = this.datas.length;
      this.fillLabels();
      this.fillNbResults();
      this.setResultsList();
      return Bridge.hideLoader();
    };

    RefineZipcodeCity.prototype.failLoadResults = function(error) {
      return console.log(error);
    };

    RefineZipcodeCity.prototype.fillNbResults = function() {
      if (this.nbResults === 1) {
        return $('.nb-results').html("" + this.nbResults + " " + (this.getLabel('one_result')));
      } else {
        return $('.nb-results').html("" + this.nbResults + " " + (this.getLabel('multi_results')));
      }
    };

    RefineZipcodeCity.prototype.setResultsList = function() {
      var i, _i, _ref, _results;
      _results = [];
      for (i = _i = 0, _ref = this.nbResults; 0 <= _ref ? _i < _ref : _i > _ref; i = 0 <= _ref ? ++_i : --_i) {
        _results.push(this.results.push(new this.DisplayResult(this.datas[i], i, this)));
      }
      return _results;
    };

    RefineZipcodeCity.prototype.DisplayResult = function(data, idx, that) {
      this.zipcode = data.codePostal;
      this.city = data.commune;
      return this.link = "resultZipcodeCity.html?id=" + idx;
    };

    return RefineZipcodeCity;

  })(ManifestLoader);
  return $(function() {
    return ko.applyBindings(new RefineZipcodeCity());
  });
})();
