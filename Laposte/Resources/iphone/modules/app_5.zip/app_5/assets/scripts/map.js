var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

(function() {
  var Map;
  Map = (function(_super) {
    var instance, markerCluster;

    __extends(Map, _super);

    instance = null;

    Map.prototype.markers = [];

    markerCluster = null;

    function Map() {
      this.clickFavoriteIconHandler = __bind(this.clickFavoriteIconHandler, this);
      this.mouseOutFavoriteIconHandler = __bind(this.mouseOutFavoriteIconHandler, this);
      this.mouseOverFavoriteIconHandler = __bind(this.mouseOverFavoriteIconHandler, this);
      this.officeAroundMe = __bind(this.officeAroundMe, this);
      this.successOfficeAroundMe = __bind(this.successOfficeAroundMe, this);
      this.failLoadWriteJson = __bind(this.failLoadWriteJson, this);
      this.failWS = __bind(this.failWS, this);
      this.displayNewOffices = __bind(this.displayNewOffices, this);
      this.successWSGeocode = __bind(this.successWSGeocode, this);
      this.successDisplayNewOffices = __bind(this.successDisplayNewOffices, this);
      this.successGeocode = __bind(this.successGeocode, this);
      this.isCity = __bind(this.isCity, this);
      this.submitHandler = __bind(this.submitHandler, this);
      this.initMap = __bind(this.initMap, this);
      this.initialize = __bind(this.initialize, this);
      var data;
      this.position = {};
      data = $('#app').data('json');
      Map.__super__.constructor.call(this, data);
      google.maps.event.addDomListener(window, 'load', this.initialize);
    }

    Map.prototype.initialize = function() {
      var geocoder, mapOptions, mapStyles,
        _this = this;
      this.mapInitialize = true;
      mapStyles = [
        {
          featureType: 'poi',
          stylers: [
            {
              visibility: 'off'
            }
          ]
        }
      ];
      mapOptions = {
        disableDefaultUI: true,
        styles: mapStyles
      };
      this.map = new google.maps.Map($(".gmap").get(0), mapOptions);
      geocoder = new google.maps.Geocoder();
      geocoder.geocode({
        'address': 'France'
      }, function(results, status) {
        if (status === google.maps.GeocoderStatus.OK) {
          _this.map.setCenter(results[0].geometry.location);
          return _this.map.fitBounds(results[0].geometry.viewport);
        }
      });
      google.maps.event.addListener(this.map, 'click', (function() {
        return _this.removeInfoboxes();
      }));
      return this.addGeolocationControl();
    };

    Map.getInstance = function(_this) {
      if (this.instance == null) {
        this.instance = _this;
      }
      return this.instance;
    };

    Map.prototype.isSuccessLoaded = function() {
      Map.getInstance(this);
      return this.initMap();
    };

    Map.prototype.initMap = function() {
      this.geolocation(true);
      this.fillLabels();
      this.fillAttributes();
      $('form').on('submit', this.submitHandler);
      Bridge.hideLoader();
      setTimeout((function() {
        Bridge.displayLoader();
      }), 100);
      return Bridge.tracking(3, "page", {
        "myPageLabel": "google_map",
        "andPageChapter": "bureau_de_poste"
      });
    };

    Map.prototype.submitHandler = function(e) {
      var $input, cp;
      e.preventDefault();
      this.removeInfoboxes();
      $input = $(e.currentTarget).find('input');
      Bridge.tracking(3, 'click', {
        "myPageLabel": $input.val(),
        "andPageChapter": $input.val()
      });
      $input.blur();
      Bridge.displayLoader();
      this.params = {};
      cp = Helpers.containsZipcode($('#search').val());
      if (cp !== null) {
        this.params.code_postal = cp;
      }
      Helpers.containsCommune($('#search').val(), this.isCity);
      return $input.blur();
    };

    Map.prototype.changeLink = function(type, params) {
      var newParams;
      if (type === "coordinates") {
        newParams = "lat=" + params.lat + "&lng=" + params.lng;
      } else {
        newParams = "";
        if (!!params.code_postal) {
          newParams += "code_postal=" + params.code_postal;
        }
        if (!!params.ville) {
          if (!!params.code_postal) {
            newParams += "&";
          }
          newParams += "ville=" + params.ville;
        }
      }
      $('.results-list').attr('href', "mapList.html?" + newParams);
      return $('.results-list').show();
    };

    Map.prototype.emptyLink = function() {
      $('.results-list').removeAttr('href');
      return $('.results-list').hide();
    };

    Map.prototype.isCity = function(result) {
      if (result !== null) {
        this.params.ville = result;
      }
      if (Object.getOwnPropertyNames(this.params).length) {
        return Webservices.callService(this.getData().webservices.searchPosteOffices, {}, this.params, this.successDisplayNewOffices, this.failWS);
      } else {
        return $.getJSON("https://maps.googleapis.com/maps/api/geocode/json?address=" + ($('#search').val()) + "&sensor=false").done(this.successGeocode);
      }
    };

    Map.prototype.successGeocode = function(data) {
      if (data.results.length === 1) {
        Webservices.callService(this.getData().webservices.searchByPos, {
          lat: data.results[0].geometry.location.lat,
          lng: data.results[0].geometry.location.lng
        }, {}, this.successWSGeocode, this.failWS);
        return this.changeLink("coordinates", {
          lat: data.results[0].geometry.location.lat,
          lng: data.results[0].geometry.location.lng
        });
      } else {
        Bridge.hideLoader(false);
        return Bridge.alertPopin('', this.getLabel("error_address_search"), {
          "title": "OK",
          "callback": ""
        });
      }
    };

    Map.prototype.successDisplayNewOffices = function(data) {
      this.changeLink("", this.params);
      if (Helpers.isWebApp()) {
        return Bridge.writeJSON(this.getData().json.map, data, "Map.newOfficesParseData()", true, "LOC_BP");
      } else {
        return Map.newOfficesParseData();
      }
    };

    Map.prototype.successWSGeocode = function(data) {
      if (Helpers.isWebApp()) {
        return Bridge.writeJSON(this.getData().json.map, data, "Map.newOfficesParseData()", true, "LOC_BP");
      } else {
        return Map.newOfficesParseData();
      }
    };

    Map.prototype.displayNewOffices = function(data) {
      this.bounds = new google.maps.LatLngBounds();
      this.favorite = data.favorite;
      this.createAllMarkers(data.bureaux);
      return this.fitAllMarkers();
    };

    Map.prototype.failWS = function(data) {
      this.emptyLink();
      Bridge.hideLoader(false);
      return Bridge.alertPopin('', this.getLabel("error_no_result"), {
        "title": "OK",
        "callback": ""
      });
    };

    Map.prototype.failLoadWriteJson = function(error) {
      return console.log(error);
    };

    Map.prototype.successOfficeAroundMe = function(data) {
      if (Helpers.isWebApp()) {
        return Bridge.writeJSON(this.getData().json.map, data, "Map.officeParseData()", true, "LOC_BP");
      } else {
        return Map.officeParseData();
      }
    };

    Map.prototype.officeAroundMe = function(data) {
      this.favorite = data.favorite;
      Bridge.hideLoader(false);
      this.createAllMarkers(data.bureaux);
      this.fitAllMarkers();
    };

    Map.prototype.createAllMarkers = function(data) {
      var i, style, _i, _j, _ref, _ref1;
      for (i = _i = 0, _ref = this.markers.length; 0 <= _ref ? _i < _ref : _i > _ref; i = 0 <= _ref ? ++_i : --_i) {
        this.markers[i].setMap(null);
        this.markerCluster.clearMarkers();
      }
      this.markers = [];
      for (i = _j = 0, _ref1 = data.length; 0 <= _ref1 ? _j < _ref1 : _j > _ref1; i = 0 <= _ref1 ? ++_j : --_j) {
        this.createMarker(new google.maps.LatLng(data[i].lat, data[i].lng), data[i]);
      }
      style = [
        {
          url: this.getData().images.clusterPinRetina,
          height: 53,
          width: 28,
          textSize: 16
        }
      ];
      this.markerCluster = new MarkerClusterer(this.map, this.markers, {
        enableRetinaIcons: true,
        styles: style
      });
    };

    Map.prototype.geolocation = function(offices) {
      var _this = this;
      this.bounds = new google.maps.LatLngBounds();
      $(document).on('geolocReady', function() {
        var icon, query, _ref;
        $(document).off('geolocReady');
        if (_this.user != null) {
          _this.user.setMap(null);
        }
        _this.pos = new google.maps.LatLng(_this.position.latitude, _this.position.longitude);
        icon = {
          url: _this.getData().images.geolocUserRetina,
          scaledSize: new google.maps.Size(12, 12)
        };
        _this.user = new google.maps.Marker({
          position: _this.pos,
          icon: icon,
          map: _this.map
        });
        if (!offices) {
          _this.removeInfoboxes();
          _this.map.panTo(_this.pos);
        } else {
          _this.bounds.extend(_this.pos);
          _this.changeLink("coordinates", {
            lat: _this.position.latitude,
            lng: _this.position.longitude
          });
          query = (_ref = Helpers.getUrlVar("query")) != null ? _ref.split('#')[0] : void 0;
          if (query != null) {
            $('#search').val(decodeURIComponent(query));
            $('form').trigger('submit');
          } else {
            Webservices.callService(_this.getData().webservices.searchByPos, {
              lat: _this.position.latitude,
              lng: _this.position.longitude
            }, {}, _this.successOfficeAroundMe, _this.failWS);
          }
        }
      });
      Bridge.getUserLocation("Map.getUserLocation(%f,%f)");
    };

    Map.prototype.addGeolocationControl = function() {
      var geolocCtrlDiv, geolocCtrlInner, icon,
        _this = this;
      geolocCtrlDiv = document.createElement('div');
      geolocCtrlDiv.className = 'geolocalize-me';
      geolocCtrlInner = document.createElement('div');
      geolocCtrlInner.className = 'inner';
      geolocCtrlDiv.appendChild(geolocCtrlInner);
      icon = document.createElement('span');
      icon.className = 'icon-compass';
      geolocCtrlInner.appendChild(icon);
      google.maps.event.addDomListener(geolocCtrlDiv, 'click', (function() {
        return _this.geolocation();
      }));
      geolocCtrlDiv.index = 1;
      return this.map.controls[google.maps.ControlPosition.TOP_RIGHT].push(geolocCtrlDiv);
    };

    Map.prototype.createOverlay = function(marker, id) {
      var details, detailsContainer, detailsFavorite, detailsFavoriteFirst, detailsFifth, detailsFirst, detailsForth, detailsSecond, detailsThird, height, openClose, openCloseDetails, openCloseFirst, openCloseSecond, openCloseThird, template, templateInner, width;
      this.removeInfoboxes();
      this.id = id;
      template = document.createElement('div');
      template.style.position = "absolute";
      template.style.backgroundColor = "white";
      template.style.display = "none";
      templateInner = document.createElement('div');
      templateInner.style.position = "relative";
      detailsContainer = document.createElement('a');
      detailsContainer.setAttribute('href', "mapDetailsOffice.html?code_site=" + id.codeSite);
      detailsContainer.className = 'infobox';
      templateInner.appendChild(detailsContainer);
      details = document.createElement('div');
      details.className = 'container-details-office';
      detailsContainer.appendChild(details);
      detailsFirst = document.createElement('h1');
      detailsFirst.className = 'name-office';
      detailsFirst.textContent = id.libelleSite;
      details.appendChild(detailsFirst);
      detailsSecond = document.createElement('p');
      detailsSecond.className = 'address-office';
      detailsSecond.textContent = id.adresse;
      details.appendChild(detailsSecond);
      detailsThird = document.createElement('p');
      detailsThird.className = 'city-office';
      detailsThird.textContent = "" + id.codePostal + " " + id.localite;
      details.appendChild(detailsThird);
      detailsForth = document.createElement('div');
      detailsForth.className = 'arrow';
      details.appendChild(detailsForth);
      detailsFifth = document.createElement('span');
      detailsFifth.className = 'icon-big-right';
      detailsForth.appendChild(detailsFifth);
      openCloseDetails = this.checkOpenClose(id);
      openClose = document.createElement('div');
      openClose.className = 'open-close-office';
      detailsContainer.appendChild(openClose);
      openCloseFirst = document.createElement('div');
      openCloseFirst.className = "border-open-close-office " + openCloseDetails.newClass;
      openClose.appendChild(openCloseFirst);
      openCloseSecond = document.createElement('p');
      openCloseSecond.className = "open-close-office-label";
      openCloseSecond.textContent = openCloseDetails.label;
      openCloseFirst.appendChild(openCloseSecond);
      openCloseThird = document.createElement('p');
      openCloseThird.className = 'close-time-office';
      openCloseThird.textContent = openCloseDetails.changeState;
      openClose.appendChild(openCloseThird);
      detailsFavorite = document.createElement('a');
      detailsFavorite.className = 'favorite';
      templateInner.appendChild(detailsFavorite);
      detailsFavoriteFirst = document.createElement('span');
      detailsFavoriteFirst.className = 'star';
      if (this.favorite != null) {
        if (this.favorite.indexOf(id.codeSite) !== -1) {
          detailsFavoriteFirst.className = "" + detailsFavoriteFirst.className + " icon-star-active";
        } else {
          detailsFavoriteFirst.className = "" + detailsFavoriteFirst.className + " icon-star-inactive";
        }
      } else {
        detailsFavoriteFirst.className = "" + detailsFavoriteFirst.className + " icon-star-inactive";
      }
      detailsFavorite.appendChild(detailsFavoriteFirst);
      $(detailsFavorite).on('mouseover', this.mouseOverFavoriteIconHandler);
      $(detailsFavorite).on('mouseout', this.mouseOutFavoriteIconHandler);
      $(detailsFavorite).on('click', this.clickFavoriteIconHandler);
      width = 290;
      document.getElementById('hidden-div').appendChild(templateInner);
      document.getElementById('hidden-div').style.width = "" + width + "px";
      height = document.getElementById('hidden-div').clientHeight;
      document.getElementById('hidden-div').innerHTML = "";
      template.appendChild(templateInner);
      return this.infobox.push(new Infobox({
        latlng: marker.getPosition(),
        map: this.map,
        content: template,
        height: height,
        width: width
      }));
    };

    Map.prototype.mouseOverFavoriteIconHandler = function(e) {
      return $(e.currentTarget).css('cursor', 'pointer');
    };

    Map.prototype.mouseOutFavoriteIconHandler = function(e) {
      return $(e.currentTarget).css('cursor', 'auto');
    };

    Map.prototype.clickFavoriteIconHandler = function(e) {
      var favoriteLink;
      e.preventDefault();
      favoriteLink = $(e.currentTarget);
      if (favoriteLink.find('.star').hasClass('icon-star-active')) {
        return this.removeFavorite(favoriteLink);
      } else {
        return this.addFavorite(favoriteLink);
      }
    };

    Map.prototype.addFavorite = function(favoriteLink) {
      this.favoriteLink = favoriteLink;
      if (Helpers.isWebApp()) {
        return Bridge.setFavorite(this.id.codeSite, this.id, "LOC_BP", "Map.callbackAddFavorite()", "" + (Helpers.getCurrentPage().split('map.html')[0]) + "mapDetailsOffice.html?code_site=" + this.id.codeSite);
      } else {
        return Map.callbackAddFavorite();
      }
    };

    Map.prototype.removeFavorite = function(favoriteLink) {
      this.favoriteLink = favoriteLink;
      if (Helpers.isWebApp()) {
        return Bridge.removeFavorite(this.id.codeSite, "LOC_BP", "Map.callbackRemoveFavorite()");
      } else {
        return Map.callbackRemoveFavorite();
      }
    };

    Map.prototype.createMarker = function(pos, id) {
      var icon, marker,
        _this = this;
      icon = {
        url: this.getData().images.mapPinRetina,
        scaledSize: new google.maps.Size(28, 40)
      };
      marker = new google.maps.Marker({
        position: pos,
        icon: icon
      });
      this.markers.push(marker);
      this.bounds.extend(pos);
      return google.maps.event.addListener(marker, "click", function(e) {
        return _this.createOverlay(marker, id);
      });
    };

    Map.prototype.removeInfoboxes = function() {
      var i, _i, _ref;
      if (this.infobox != null) {
        for (i = _i = 0, _ref = this.infobox.length; 0 <= _ref ? _i < _ref : _i > _ref; i = 0 <= _ref ? ++_i : --_i) {
          this.infobox[i].setMap(null);
        }
      }
      return this.infobox = [];
    };

    Map.prototype.fitAllMarkers = function() {
      this.map.fitBounds(this.bounds);
      return Bridge.hideLoader(false);
    };

    Map.prototype.checkOpenClose = function(data) {
      var diffTime, openCloseDetails, strTime;
      diffTime = Helpers.calculateDiffTime(data.etat.date, data.etat.dateChangement);
      openCloseDetails = {};
      strTime = this.formatTime(diffTime);
      if (data.etat.ouvert) {
        openCloseDetails.label = this.getLabel('open');
        openCloseDetails.newClass = "open-office";
        if (diffTime !== "") {
          openCloseDetails.changeState = "" + (this.getLabel('close_in')) + " " + strTime;
        }
      } else {
        openCloseDetails.label = this.getLabel('close');
        if (diffTime !== "") {
          openCloseDetails.changeState = "" + (this.getLabel('open_in')) + " " + strTime;
        }
      }
      return openCloseDetails;
    };

    Map.prototype.formatTime = function(time) {
      var strTime;
      strTime = "";
      if (time.day === 0) {
        strTime = "" + time.hour + (this.getLabel('hour')) + time.min + (this.getLabel('minute'));
      } else if (time.day === 1) {
        strTime = "" + time.day + " " + (this.getLabel('day')) + " " + time.hour + (this.getLabel('hour')) + time.min + (this.getLabel('minute'));
      } else {
        strTime = "" + time.day + " " + (this.getLabel('days')) + " " + time.hour + (this.getLabel('hour')) + time.min + (this.getLabel('minute'));
      }
      return strTime;
    };

    Map.officeParseData = function() {
      var writeJsonPath;
      writeJsonPath = Helpers.convertAbsoluteToRelativeJsonPath(this.instance.getData().json.map);
      return Helpers.loadJson(writeJsonPath).done(this.instance.officeAroundMe).fail(this.instance.failLoadWriteJson);
    };

    Map.newOfficesParseData = function() {
      var writeJsonPath;
      writeJsonPath = Helpers.convertAbsoluteToRelativeJsonPath(this.instance.getData().json.map);
      return Helpers.loadJson(writeJsonPath).done(this.instance.displayNewOffices).fail(this.instance.failLoadWriteJson);
    };

    Map.callbackAddFavorite = function() {
      this.instance.favoriteLink.find('.star').removeClass('icon-star-inactive');
      return this.instance.favoriteLink.find('.star').addClass('icon-star-active');
    };

    Map.callbackRemoveFavorite = function() {
      this.instance.favoriteLink.find('.star').removeClass('icon-star-active');
      return this.instance.favoriteLink.find('.star').addClass('icon-star-inactive');
    };

    Map.getUserLocation = function(longitude, latitude) {
      if (longitude > 9000) {
        return setTimeout((function() {
          Bridge.hideLoader(false);
        }), 200);
      } else {
        this.instance.position = {
          'latitude': latitude,
          'longitude': longitude
        };
        Bridge.tracking(3, "page", {
          "myPageLabel": "autoriser_la_localisation",
          "andPageChapter": "bureau_de_poste::autoriser_la_localisation"
        });
        return $(document).trigger('geolocReady');
      }
    };

    return Map;

  })(ManifestLoader);
  window.Map = Map;
  return $(function() {
    return new Map();
  });
})();
