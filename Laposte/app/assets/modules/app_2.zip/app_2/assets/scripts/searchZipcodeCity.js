var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

(function() {
  var SearchZipcodeCity;
  SearchZipcodeCity = (function(_super) {
    __extends(SearchZipcodeCity, _super);

    SearchZipcodeCity.prototype.instance = null;

    function SearchZipcodeCity() {
      this.checkResults = __bind(this.checkResults, this);
      this.clickCrossErrorHandler = __bind(this.clickCrossErrorHandler, this);
      this.submitHandler = __bind(this.submitHandler, this);
      var data;
      this.error = ko.observable();
      data = $('#app').data('json');
      SearchZipcodeCity.__super__.constructor.call(this, data);
    }

    SearchZipcodeCity.prototype.isSuccessLoaded = function() {
      SearchZipcodeCity.getInstance(this);
      Bridge.navigationTitle(this.getLabel("navigation_title"));
      this.fillLabels();
      this.fillAttributes();
      Bridge.hideLoader();
      Bridge.tracking(5, "page", {
        "myPageLabel": "formulaire_recherche_cp_ville",
        "andPageChapter": "recherche_cp_ville"
      });
      return $('form').on('submit', this.submitHandler);
    };

    SearchZipcodeCity.prototype.submitHandler = function(e) {
      e.preventDefault();
      $(e.currentTarget).find('input').blur();
      Bridge.displayLoader();
      return SearchZipcodeCity.search();
    };

    SearchZipcodeCity.prototype.clickCrossErrorHandler = function(e) {
      $('.form-input-texts').find('[name=q]').val("");
      return this.error(false);
    };

    SearchZipcodeCity.prototype.checkResults = function(data) {
      if (data.codePostaux.length === 0) {
        return Bridge.alertPopin('', 'Saisie erronée, pas de résultat', {
          "title": "OK",
          "callback": "Bridge.hideLoader(false)"
        });
      } else if (data.codePostaux.length > 1) {
        return Bridge.redirect("app_2/views/refineZipcodeCity.html");
      } else {
        return Bridge.redirect("app_2/views/resultZipcodeCity.html");
      }
    };

    SearchZipcodeCity.getInstance = function(_this) {
      if (this.instance == null) {
        this.instance = _this;
      }
      return this.instance;
    };

    SearchZipcodeCity.search = function() {
      var cp, error;
      error = 0;
      $('.icon-error').off('click', this.instance.clickCrossErrorHandler);
      this.instance.error(false);
      this.query = $('form').find('[name=q]').val();
      this.instance.params = {};
      if (this.query.trim() === "") {
        error++;
        this.instance.error(true);
        Bridge.hideLoader(false);
        $('.form-input-texts').find('.error p').html(this.instance.getLabel('query_empty'));
      } else {
        cp = Helpers.containsZipcode(this.query);
        if (cp !== null) {
          this.instance.params.codePostal = cp;
          this.query = this.query.replace(cp, "").trim();
        }
      }
      if (error > 0) {
        return $('.icon-error').on('click', this.instance.clickCrossErrorHandler);
      } else {
        return this.sendToWS();
      }
    };

    SearchZipcodeCity.sendToWS = function() {
      Bridge.displayLoader();
      if (this.query != null) {
        this.instance.params.commune = this.query;
      }
      Webservices.callService(this.instance.getData().webservices.postalCodeResolution, {}, this.instance.params, this.successWS, this.failWS);
    };

    SearchZipcodeCity.successWS = function(data) {
      if (Helpers.isWebApp()) {
        return Bridge.writeJSON(SearchZipcodeCity.instance.getData().json.resultZipcodeCity, data, "SearchZipcodeCity.readResults()", false, "");
      }
    };

    SearchZipcodeCity.readResults = function() {
      var writeJsonPath;
      writeJsonPath = Helpers.convertAbsoluteToRelativeJsonPath(this.instance.getData().json.resultZipcodeCity);
      Helpers.loadJson(writeJsonPath).done(this.instance.checkResults).fail(this.instance.failLoadWriteJson);
    };

    return SearchZipcodeCity;

  }).call(this, ManifestLoader);
  window.SearchZipcodeCity = SearchZipcodeCity;
  return $(function() {
    return ko.applyBindings(new SearchZipcodeCity());
  });
})();
