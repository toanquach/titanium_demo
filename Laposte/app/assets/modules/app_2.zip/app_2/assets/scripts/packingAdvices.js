var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

(function() {
  var PackingAdvices;
  PackingAdvices = (function(_super) {
    __extends(PackingAdvices, _super);

    function PackingAdvices() {
      this.clickAdviceHandler = __bind(this.clickAdviceHandler, this);
      this.failLoadPackingAdvices = __bind(this.failLoadPackingAdvices, this);
      this.successLoadPackingAdvices = __bind(this.successLoadPackingAdvices, this);
      var data;
      this.advices = ko.observableArray();
      data = $('#app').data('json');
      PackingAdvices.__super__.constructor.call(this, data);
    }

    PackingAdvices.prototype.isSuccessLoaded = function() {
      var jsonPath;
      jsonPath = Helpers.convertAbsoluteToRelativeJsonPath(this.getData().json.packingAdvices);
      return Helpers.loadJson(jsonPath).done(this.successLoadPackingAdvices).fail(this.failLoadPackingAdvices);
    };

    PackingAdvices.prototype.successLoadPackingAdvices = function(data) {
      this.menu = data.menu;
      this.setAdvices();
      this.fillLabels();
      $('.need-help').on('click', this.clickAdviceHandler);
      Helpers.forceImgToRetina($('img'));
      return Bridge.hideLoader();
    };

    PackingAdvices.prototype.failLoadPackingAdvices = function(error) {
      return console.log(error);
    };

    PackingAdvices.prototype.setAdvices = function() {
      var i, _i, _ref;
      for (i = _i = 0, _ref = this.menu.length; 0 <= _ref ? _i < _ref : _i > _ref; i = 0 <= _ref ? ++_i : --_i) {
        this.advices.push(new this.DisplayAdvice(this.menu[i], this));
      }
      return $('.advice-wrapper').on('click', 'a', this.clickAdviceHandler);
    };

    PackingAdvices.prototype.DisplayAdvice = function(data, that) {
      this.link = data.link;
      this.img = data.img;
      this.title = data.title;
      this.tracking = JSON.stringify(data.tracking);
    };

    PackingAdvices.prototype.clickAdviceHandler = function(e) {
      var $target, completeUrl, url;
      e.preventDefault();
      $target = $(e.currentTarget);
      url = $target.attr('href');
      completeUrl = "" + (Helpers.getCurrentApp()) + "/views/" + url;
      return Bridge.displayPopin(completeUrl, null, $target.find('.advice-label').html());
    };

    return PackingAdvices;

  })(ManifestLoader);
  return $(function() {
    return ko.applyBindings(new PackingAdvices());
  });
})();
