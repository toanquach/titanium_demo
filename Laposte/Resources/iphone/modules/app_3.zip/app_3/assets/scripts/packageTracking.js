var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

(function() {
  var packageTracking;
  packageTracking = (function(_super) {
    __extends(packageTracking, _super);

    packageTracking.prototype.instance = null;

    function packageTracking() {
      this.clickCrossErrorHandler = __bind(this.clickCrossErrorHandler, this);
      this.submitHandler = __bind(this.submitHandler, this);
      var data;
      this.error = ko.observable();
      data = $('#app').data('json');
      packageTracking.__super__.constructor.call(this, data);
    }

    packageTracking.prototype.isSuccessLoaded = function() {
      packageTracking.getInstance(this);
      this.fillLabels();
      this.fillAttributes();
      $('form').on('submit', this.submitHandler);
      Bridge.hideLoader();
      return Bridge.tracking(4, "page", {
        "myPageLabel": "formulaire_recherche",
        "andPageChapter": "suivi_des_envois"
      });
    };

    packageTracking.prototype.submitHandler = function(e) {
      e.preventDefault();
      return packageTracking.validateForm();
    };

    packageTracking.prototype.clickCrossErrorHandler = function(e) {
      $('.package-number').find('[name=tracking-number]').val("");
      return this.error(false);
    };

    packageTracking.getInstance = function(_this) {
      if (this.instance == null) {
        this.instance = _this;
      }
      return this.instance;
    };

    packageTracking.validateForm = function(ajax) {
      var error, pattern, query;
      if (ajax == null) {
        ajax = true;
      }
      error = 0;
      $('.icon-error').off('click', this.instance.clickCrossErrorHandler);
      this.instance.error(false);
      if (ajax) {
        query = $('.package-number').find('[name=tracking-number]').val();
        pattern = /^[A-Z|0-9|a-z]{13}$/;
        if (query.trim() === "") {
          error++;
          this.instance.error(true);
          $('.package-number').find('.error p').html(this.instance.getLabel('packageTrackingEmpty'));
        } else if (!pattern.test(query)) {
          error++;
          this.instance.error(true);
          $('.package-number').find('.error p').html(this.instance.getLabel('packageTrackingNumberError'));
        }
      } else {
        error++;
        this.instance.error(true);
        $('.package-number').find('.error p').html(this.instance.getLabel('packageTrackingNumberError'));
      }
      if (error > 0) {
        $('.icon-error').on('click', this.instance.clickCrossErrorHandler);
      } else {
        Bridge.displayLoader();
        $.ajax({
          url: "http://www.laposte.fr/outilsuivi/web/suiviInterMetiers.php?code=" + query + "&key=6b252eb30d3afb15c47cf3fccee3dc17352dc2d6&method=jsonp&slp_sendRequestCallback=packageTracking.successResultPackageTracking",
          dataType: "jsonp"
        });
      }
    };

    packageTracking.successResultPackageTracking = function(data) {
      if (data.status) {
        if (Helpers.isWebApp()) {
          this.instance["package"] = data;
          this.instance["package"].isLast = true;
          return Bridge.setFavorite(this.instance["package"].code, this.instance["package"], "SVE_NUM", "packageTracking.writePackageJson()");
        } else {
          return packageTracking.redirect();
        }
      } else {
        Bridge.hideLoader(false);
        return this.validateForm(false);
      }
    };

    packageTracking.failResultPackageTracking = function(error) {
      return console.log(error);
    };

    packageTracking.writePackageJson = function() {
      return Bridge.writeJSON(this.instance.getData().json.yourTracking, this.instance["package"], "packageTracking.redirect()", true, "SVE_NUM");
    };

    packageTracking.redirect = function() {
      return Bridge.redirect("app_3/views/yourTracking.html");
    };

    return packageTracking;

  })(ManifestLoader);
  window.packageTracking = packageTracking;
  return $(function() {
    return ko.applyBindings(new packageTracking());
  });
})();
