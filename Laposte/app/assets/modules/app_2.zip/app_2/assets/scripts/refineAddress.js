var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

(function() {
  var RefineAddress;
  RefineAddress = (function(_super) {
    __extends(RefineAddress, _super);

    function RefineAddress() {
      this.successLoad = __bind(this.successLoad, this);
      var data;
      this.type = ko.observable();
      this.errormsg = ko.observable();
      this.choices = ko.observableArray();
      data = $('#app').data('json');
      RefineAddress.__super__.constructor.call(this, data);
    }

    RefineAddress.prototype.isSuccessLoaded = function() {
      return Helpers.loadJson(Helpers.convertAbsoluteToRelativeJsonPath(this.getData().json.resultTestAddress)).done(this.successLoad).fail(this.failLoad);
    };

    RefineAddress.prototype.successLoad = function(data) {
      var first, i, idx, j, _i, _j, _ref;
      data = data.adresse;
      this.params = Helpers.getUrlVars();
      this.newParams = "";
      first = 1;
      if (this.params != null) {
        first = parseInt(this.params.idx, 10) + 1;
        for (i = _i = 1; _i < 7; i = ++_i) {
          if (this.params["ligne" + i] != null) {
            this.newParams += "ligne" + i + "=" + this.params["ligne" + i] + "&";
          }
        }
      }
      j = 0;
      for (i = _j = first; first <= 7 ? _j < 7 : _j > 7; i = first <= 7 ? ++_j : --_j) {
        if (((_ref = data["ligne" + i]) != null ? _ref.feu.couleur : void 0) === "rouge") {
          j++;
          if (j === 2) {
            this.next = true;
            break;
          } else {
            idx = i;
          }
        }
      }
      this.type("refine_search");
      if (data["ligne" + idx].values.length === 1) {
        this.errormsg("" + data["ligne" + idx].values.length + " " + (this.getLabel("one_result")));
      } else {
        this.errormsg("" + data["ligne" + idx].values.length + " " + (this.getLabel("multi_results")));
      }
      this.displayChoices(data["ligne" + idx].values, idx, this);
      this.fillLabels();
      Bridge.hideLoader();
      return Bridge.tracking(5, "page", {
        "myPageLabel": "affiner_resultat_recherche_d_adresse",
        "andPageChapter": "test_d_adresse"
      });
    };

    RefineAddress.prototype.displayChoices = function(data, ligne, that) {
      var i, _i, _ref, _results;
      _results = [];
      for (i = _i = 0, _ref = data.length; 0 <= _ref ? _i < _ref : _i > _ref; i = 0 <= _ref ? ++_i : --_i) {
        _results.push(that.choices.push(new this.displayChoice(data[i], ligne, i, that)));
      }
      return _results;
    };

    RefineAddress.prototype.displayChoice = function(data, ligne, idx, that) {
      this.value = data.value;
      if (that.next) {
        return this.link = "refineAddress.html?" + that.newParams + "ligne" + ligne + "=" + idx + "&idx=" + ligne;
      } else {
        return this.link = "resultAddress.html?" + that.newParams + "ligne" + ligne + "=" + idx;
      }
    };

    return RefineAddress;

  })(ManifestLoader);
  return $(function() {
    return ko.applyBindings(new RefineAddress());
  });
})();
