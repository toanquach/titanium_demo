var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

(function() {
  var CropImage;
  CropImage = (function(_super) {
    __extends(CropImage, _super);

    function CropImage() {
      this.getCropImg = __bind(this.getCropImg, this);
      this.generateCropImage = __bind(this.generateCropImage, this);
      this.selectSens = __bind(this.selectSens, this);
      this.isReady = __bind(this.isReady, this);
      this.failLoadTempJson = __bind(this.failLoadTempJson, this);
      this.successLoadTempJson = __bind(this.successLoadTempJson, this);
      this.loadImageDone = __bind(this.loadImageDone, this);
      var data;
      data = $('#app').data('json');
      CropImage.__super__.constructor.call(this, data);
    }

    CropImage.prototype.isSuccessLoaded = function() {
      var jsonPath;
      jsonPath = Helpers.convertAbsoluteToRelativeJsonPath(this.getData().json.temp, true);
      return Helpers.loadJson(jsonPath).done(this.successLoadTempJson).fail(this.failLoadTempJson);
    };

    CropImage.prototype.test = function() {
      this.fillLabels();
      return this.resizeCanvasElement();
    };

    CropImage.prototype.test2 = function() {
      if (this.imgSrc.indexOf("data:image") !== -1) {
        this.tempImage = new Image();
        this.tempImage.onload = this.loadImageDone;
        return this.tempImage.src = this.imgSrc;
      } else {
        this.queue = new createjs.LoadQueue(false, "", true);
        this.queue.on("complete", this.loadImageDone, this);
        return this.queue.loadManifest([this.imgSrc]);
      }
    };

    CropImage.prototype.loadImageDone = function() {
      var $mpCanvas, height, limit, megaPixImage, sc, width,
        _this = this;
      if (this.imgSrc.indexOf("data:image") !== -1) {
        this.img = new createjs.Bitmap(this.imgSrc);
      } else {
        this.img = new createjs.Bitmap(this.queue.getItem(this.imgSrc).tag);
      }
      limit = 3000000;
      if (this.img.image.width * this.img.image.height >= limit) {
        sc = Math.sqrt(limit / (this.img.image.width * this.img.image.height));
        width = this.img.image.width * sc;
        height = this.img.image.height * sc;
        this.imgTemp = new Image();
        this.imgTemp.src = this.imgSrc;
        megaPixImage = new MegaPixImage(this.imgTemp);
        $mpCanvas = $('#megapixel');
        megaPixImage.render($mpCanvas.get(0), {
          "width": width,
          "height": height
        });
        setTimeout((function() {
          _this.imgSrc = $mpCanvas.get(0).toDataURL();
          return $mpCanvas.remove();
        }), 500);
      }
      return setTimeout((function() {
        return _this.initCanvas();
      }), 600);
    };

    CropImage.prototype.successLoadTempJson = function(data) {
      var _this = this;
      Bridge.navigationTitle(this.getLabel("title"));
      this.imgSrc = data.image.original;
      setTimeout((function() {
        return _this.test();
      }), 100);
      return setTimeout((function() {
        return _this.test2();
      }), 200);
    };

    CropImage.prototype.failLoadTempJson = function(error) {
      return console.log(error);
    };

    CropImage.prototype.resizeCanvasElement = function() {
      var sc;
      this.canvas = $('canvas');
      this.canvas.attr("width", "" + (this.getData().crop.final_width) + "px");
      this.canvas.attr("height", "" + (this.getData().crop.final_width / this.getData().crop.ratio_canvas) + "px");
      sc = $('#app').width() / this.getData().crop.final_width;
      this.canvas.css({
        "transform-origin": "top left",
        "transform": "scale(" + sc + ")",
        "display": "block"
      });
      $('.container-canvas').height(this.canvas.width());
      return $('.container-canvas').height(this.canvas.height() * sc);
    };

    CropImage.prototype.initCanvas = function() {
      return this.cropImageCanvas = new CropImageCanvas(this.canvas, this.imgSrc, this.isReady);
    };

    CropImage.prototype.isReady = function() {
      this.checkQuality();
      $('.horizontal-vertical').on('click touch', this.selectSens);
      return $('.container-btn-next').find('a').on('click touch', this.generateCropImage);
    };

    CropImage.prototype.checkQuality = function() {
      var sc;
      Bridge.navigationTitle(this.getLabel("title"));
      sc = this.cropImageCanvas.checkQuality();
      if (sc.scW > this.getData().crop.min_scale_quality && sc.scH > this.getData().crop.min_scale_quality) {
        Bridge.alertPopin(this.getLabel("poorQualityTitle"), this.getLabel("poorQualityMessage"), {
          "title": "" + (this.getLabel('poorQualityCancel')),
          "callback": "Bridge.navBack('view')"
        }, {
          "title": "" + (this.getLabel('poorQualityContinue')),
          "callback": ""
        });
        return Bridge.tracking(7, "page", {
          "myPageLabel": "qualite_insuffisante",
          "andPageChapter": "envoyer_une_carte::selection::qualite_insuffisante"
        });
      }
    };

    CropImage.prototype.selectSens = function(e) {
      var sens, target;
      target = e.currentTarget;
      sens = $(target).data('sens');
      if (!$(target).hasClass('active')) {
        $(target).addClass('active');
        if (sens === "horizontal") {
          $(".horizontal-vertical[data-sens='vertical']").removeClass('active');
        } else {
          $(".horizontal-vertical[data-sens='horizontal']").removeClass('active');
        }
        return this.cropImageCanvas.buildRatioLayer(sens);
      }
    };

    CropImage.prototype.generateCropImage = function(e) {
      e.preventDefault();
      Bridge.displayLoader();
      return this.cropImageCanvas.generateCropImage(this.getCropImg);
    };

    CropImage.prototype.getCropImg = function() {
      var nextPage;
      this.writeTempJson();
      nextPage = $('.btn-next').attr("href");
      return Bridge.redirect("app_7/views/" + nextPage);
    };

    CropImage.prototype.writeTempJson = function() {
      var temp;
      temp = {
        "image": {
          "original": "" + this.imgSrc,
          "crop": "" + this.cropImageCanvas.cropImageSrc
        }
      };
      return Bridge.writeTempJSON(temp);
    };

    CropImage.redirectPreviousPage = function() {
      Bridge.navBack();
    };

    return CropImage;

  })(ManifestLoader);
  return $(function() {
    return new CropImage();
  });
})();
