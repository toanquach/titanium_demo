var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

(function() {
  var ResultAddress;
  ResultAddress = (function(_super) {
    __extends(ResultAddress, _super);

    function ResultAddress() {
      this.successLoad = __bind(this.successLoad, this);
      var data;
      this.values = ko.observableArray();
      this.form = ['name', 'floor_result', 'residence', 'addresses', 'complement', 'locality'];
      data = $('#app').data('json');
      ResultAddress.__super__.constructor.call(this, data);
    }

    ResultAddress.prototype.isSuccessLoaded = function() {
      return Helpers.loadJson(Helpers.convertAbsoluteToRelativeJsonPath(this.getData().json.resultTestAddress)).done(this.successLoad).fail(this.failLoad);
    };

    ResultAddress.prototype.successLoad = function(data) {
      this.displayValues(data.adresse, this);
      this.fillLabels();
      Bridge.hideLoader();
      return Bridge.tracking(5, "page", {
        "myPageLabel": "resultat_recherche",
        "andPageChapter": "test_d_adresse"
      });
    };

    ResultAddress.prototype.displayValues = function(data, that) {
      var i, _i;
      for (i = _i = 1; _i < 7; i = ++_i) {
        if (data["ligne" + i] != null) {
          this.values.push(new this.displayValue(data, i, that.form[i - 1]));
        }
      }
    };

    ResultAddress.prototype.displayValue = function(data, idx, type) {
      var _ref;
      this.type = type;
      if (data["ligne" + idx].value != null) {
        if (typeof data["ligne" + idx].value === "object") {
          this.value = (_ref = data["ligne" + idx].value[0]) != null ? _ref.libelle : void 0;
        } else {
          this.value = data["ligne" + idx].value;
        }
      } else {
        this.value = data["ligne" + idx].values[Helpers.getUrlVars()["ligne" + idx]].value;
      }
      switch (data["ligne" + idx].feu.couleur) {
        case "vert":
          this.error = false;
          break;
        case "orange":
          this.error = true;
          this.corrected = true;
          this.errormsg = data["ligne" + idx].feu.errormsg;
          break;
        case "rouge":
          if (data["ligne" + idx].value != null) {
            this.error = true;
            this.corrected = false;
          } else {
            this.error = false;
          }
      }
    };

    return ResultAddress;

  })(ManifestLoader);
  return $(function() {
    return ko.applyBindings(new ResultAddress());
  });
})();
