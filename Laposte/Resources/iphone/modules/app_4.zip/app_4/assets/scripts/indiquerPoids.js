var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

(function() {
  var IndiquerPoids;
  IndiquerPoids = (function(_super) {
    __extends(IndiquerPoids, _super);

    IndiquerPoids.prototype.instance = null;

    function IndiquerPoids() {
      this.submitHandler = __bind(this.submitHandler, this);
      this.successLoadParams = __bind(this.successLoadParams, this);
      var data;
      this.error = ko.observable();
      this.colis = ko.observable(false);
      this.annextitle = ko.observable();
      this.annextext = ko.observable();
      data = $('#app').data('json');
      IndiquerPoids.__super__.constructor.call(this, data);
    }

    IndiquerPoids.prototype.isSuccessLoaded = function() {
      var type;
      IndiquerPoids.getInstance(this);
      type = Helpers.getUrlVar("type");
      if ((type != null) && type === "colis") {
        this.colis(true);
        $('.main').find('p').attr('data-label', 'poidsMainTitleColis');
        $('.subtitle').attr('data-label', 'poidsSubTitleColis');
        this.annextitle(this.getLabel("annextitle"));
        this.annextext(this.getLabel("annextext"));
      }
      this.fillLabels();
      this.fillAttributes();
      $('form').on('submit', this.submitHandler);
      Helpers.forceImgToRetina($('img'));
      Helpers.loadJson(Helpers.convertAbsoluteToRelativeJsonPath(this.getData().json.params)).done(this.successLoadParams).fail(this.failLoadParams);
      return Bridge.hideLoader();
    };

    IndiquerPoids.prototype.successLoadParams = function(data) {
      this.params = data;
    };

    IndiquerPoids.prototype.submitHandler = function(e) {
      var $form, $input;
      e.preventDefault();
      this.error(false);
      $form = $('form');
      $input = $form.find('[type=number]');
      $input.removeClass('error');
      this.query = $input.val();
      if (!/^\d+$/.test(this.query)) {
        this.error(true);
        $form.find('.error p').html(this.getLabel('poidsError'));
        return $input.addClass('error');
      } else {
        $.extend(this.params.params, {
          "gr": parseInt(this.query, 10)
        });
        $.extend(this.params.summary, {
          "poids": "" + (parseInt(this.query, 10)) + "g"
        });
        if (Helpers.isWebApp()) {
          return Bridge.writeJSON(this.getData().json.params, this.params, "IndiquerPoids.gotoNext()", false, "");
        } else {
          return IndiquerPoids.gotoNext();
        }
      }
    };

    IndiquerPoids.getInstance = function(_this) {
      if (this.instance == null) {
        this.instance = _this;
      }
      return this.instance;
    };

    IndiquerPoids.gotoNext = function() {
      return Bridge.redirect("app_4/views/affranchissement.html");
    };

    return IndiquerPoids;

  })(ManifestLoader);
  window.IndiquerPoids = IndiquerPoids;
  return $(function() {
    return ko.applyBindings(new IndiquerPoids());
  });
})();
