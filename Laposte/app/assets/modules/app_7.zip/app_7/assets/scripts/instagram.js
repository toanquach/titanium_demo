var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

(function() {
  var Instagram;
  Instagram = (function(_super) {
    __extends(Instagram, _super);

    function Instagram() {
      this.selectPicture = __bind(this.selectPicture, this);
      this.failGetInstagramPictures = __bind(this.failGetInstagramPictures, this);
      this.successGetInstagramPictures = __bind(this.successGetInstagramPictures, this);
      var data;
      this.pictures = ko.observableArray();
      data = $('#app').data('json');
      Instagram.__super__.constructor.call(this, data);
    }

    Instagram.prototype.isSuccessLoaded = function() {
      if (Helpers.getUrlVar('accesstoken') != null) {
        this.accessToken = Helpers.getUrlVar('accesstoken');
        this.userId = this.accessToken.split(".")[0];
        this.getInstagramPictures();
      } else {
        this.loginInstagram();
      }
      this.fillLabels();
      Bridge.hideLoader();
      Bridge.navigationTitle(this.getLabel("title"));
      return Bridge.tracking(7, "page", {
        "myPageLabel": "instagram",
        "andPageChapter": "envoyer_une_carte::selection::instagram"
      });
    };

    Instagram.prototype.loginInstagram = function() {
      var clientId, currentUrl, permissionUrl, redirectPage;
      redirectPage = this.getData().instagram.redirect;
      clientId = this.getData().instagram.clientId;
      permissionUrl = "https://api.instagram.com/oauth/authorize/?client_id=" + clientId + "&redirect_uri=" + redirectPage + "&response_type=token";
      currentUrl = window.location.href;
      return Bridge.socialNetworkCnx(permissionUrl, currentUrl);
    };

    Instagram.prototype.getInstagramPictures = function() {
      var apiUrl, limitPhotos;
      Bridge.displayLoader();
      limitPhotos = this.getData().instagram.limit_photos;
      apiUrl = "https://api.instagram.com/v1/users/" + this.userId + "/media/recent?access_token=" + this.accessToken + "&count=" + limitPhotos + "&callback=?";
      return $.getJSON(apiUrl).done(this.successGetInstagramPictures).fail(this.failGetInstagramPictures);
    };

    Instagram.prototype.successGetInstagramPictures = function(response) {
      var cpt, imgWidth, item, _i, _len, _ref;
      Bridge.hideLoader(false);
      cpt = 0;
      this.data = response.data;
      _ref = this.data;
      for (_i = 0, _len = _ref.length; _i < _len; _i++) {
        item = _ref[_i];
        this.pictures.push(new this.DisplayPicture(item, this));
        imgWidth = ($('#app').width() - 2) / 3;
        $('.picture-img').css({
          width: "" + imgWidth + "px",
          height: "" + imgWidth + "px"
        });
        $('.picture-selected-layer').css({
          width: "" + imgWidth + "px",
          height: "" + imgWidth + "px"
        });
        if ((cpt + 1) % 3 === 0) {
          $($('.picture-li')[cpt]).css("margin-right", "0");
        }
        cpt++;
      }
      this.height = $('#app').height();
      return $('.picture-container').on('click touch', this.selectPicture);
    };

    Instagram.prototype.failGetInstagramPictures = function(error) {
      Bridge.hideLoader(false);
      return console.log(error);
    };

    Instagram.prototype.DisplayPicture = function(data, that) {
      this.img = ko.observable("url(" + data.images.thumbnail.url + ")");
      return this;
    };

    Instagram.prototype.selectPicture = function(e) {
      var i, imgSrc, temp, _i, _ref;
      for (i = _i = 0, _ref = $('.picture-container').length; 0 <= _ref ? _i < _ref : _i > _ref; i = 0 <= _ref ? ++_i : --_i) {
        if ($('.picture-container')[i] !== e.currentTarget) {
          $($('.picture-container')[i]).removeClass('active');
        } else {
          this.pictureSelected = i;
        }
      }
      if (!$(e.currentTarget).hasClass('active')) {
        $(e.currentTarget).addClass('active');
        $('.container-btn-next').css('bottom', '0');
        $('#app').height(this.height + $('.container-btn-next').height());
      } else {
        $(e.currentTarget).removeClass('active');
        $('.container-btn-next').css('bottom', '-100px');
        $('#app').height(this.height - $('.container-btn-next').height());
      }
      imgSrc = this.data[this.pictureSelected].images.standard_resolution.url;
      temp = {
        "image": {
          "original": "" + imgSrc
        }
      };
      return Bridge.writeTempJSON(temp);
    };

    return Instagram;

  })(ManifestLoader);
  return $(function() {
    return ko.applyBindings(new Instagram());
  });
})();
