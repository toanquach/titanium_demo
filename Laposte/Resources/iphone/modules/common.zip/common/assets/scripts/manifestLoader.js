var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

(function() {
  var ManifestLoader;
  ManifestLoader = (function() {
    function ManifestLoader(path) {
      this.successLoaded = __bind(this.successLoaded, this);
      $.getJSON(path).done(this.successLoaded);
    }

    ManifestLoader.prototype.successLoaded = function(data) {
      if (typeof data === 'string') {
        data = $.parseJSON(data);
      }
      this.data = data;
      return this.isSuccessLoaded();
    };

    ManifestLoader.prototype.getData = function() {
      return this.data.data;
    };

    ManifestLoader.prototype.getLabel = function(key) {
      return this.data.labels[key];
    };

    ManifestLoader.prototype.fillLabels = function() {
      var i, label, labels, _i, _ref, _results;
      labels = $('[data-label]');
      _results = [];
      for (i = _i = 0, _ref = labels.length; 0 <= _ref ? _i < _ref : _i > _ref; i = 0 <= _ref ? ++_i : --_i) {
        label = $(labels[i]);
        _results.push(label.html(this.getLabel(label.data('label'))));
      }
      return _results;
    };

    ManifestLoader.prototype.fillAttributes = function() {
      var attr, attributes, elmt, elmtAttrs, i, idx, _i, _ref, _results;
      attributes = $('[data-attributes]');
      _results = [];
      for (i = _i = 0, _ref = attributes.length; 0 <= _ref ? _i < _ref : _i > _ref; i = 0 <= _ref ? ++_i : --_i) {
        elmt = $(attributes[i]);
        elmtAttrs = $(attributes[i]).data('attributes');
        _results.push((function() {
          var _results1;
          _results1 = [];
          for (idx in elmtAttrs) {
            attr = elmtAttrs[idx];
            _results1.push(elmt.attr(idx, this.getLabel(attr)));
          }
          return _results1;
        }).call(this));
      }
      return _results;
    };

    return ManifestLoader;

  })();
  return window.ManifestLoader = ManifestLoader;
})();
