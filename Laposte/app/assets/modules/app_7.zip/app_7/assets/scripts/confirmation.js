var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

(function() {
  var Confirmation;
  Confirmation = (function(_super) {
    __extends(Confirmation, _super);

    function Confirmation() {
      this.successLoad = __bind(this.successLoad, this);
      var data;
      this.title = ko.observable();
      this.img = ko.observable();
      this.text = ko.observable();
      this.links = ko.observableArray();
      data = $('#app').data('json');
      Confirmation.__super__.constructor.call(this, data);
    }

    Confirmation.prototype.isSuccessLoaded = function() {
      return Helpers.loadJson(Helpers.convertAbsoluteToRelativeJsonPath(this.getData().json.confirmation)).done(this.successLoad).fail(this.failLoad);
    };

    Confirmation.prototype.successLoad = function(data) {
      var newdata,
        _this = this;
      if (Helpers.getUrlVar('status') === 'cancel') {
        newdata = data.cancel;
      } else {
        newdata = data.complete;
      }
      this.title(newdata.title);
      this.img(newdata.visual);
      this.android = Helpers.isAndroid();
      if (this.android && (newdata.text.android != null)) {
        this.text(newdata.text.android);
      } else {
        this.text(newdata.text.ios);
      }
      this.displayLinks(newdata.links, this);
      $("li").on('click', '[href=#accueil]', function(e) {
        e.preventDefault();
        return Bridge.navBack("root");
      });
      Bridge.hideLoader();
      Bridge.navigationTitle(this.getLabel("title"));
      return Bridge.tracking(7, "page", {
        "myPageLabel": "confirmation",
        "andPageChapter": "envoyer_une_carte::confirmation"
      });
    };

    Confirmation.prototype.displayLinks = function(data, that) {
      var i, _i, _ref, _results;
      _results = [];
      for (i = _i = 0, _ref = data.length; 0 <= _ref ? _i < _ref : _i > _ref; i = 0 <= _ref ? ++_i : --_i) {
        _results.push(that.links.push(new this.displayLink(data[i], that)));
      }
      return _results;
    };

    Confirmation.prototype.displayLink = function(data, that) {
      if (data.android != null) {
        if (that.android) {
          data = data.android;
        } else {
          data = data.ios;
        }
      }
      this.label = data.label;
      if (Helpers.getUrlVar("type") != null) {
        this.link = "" + data.link + "?type=" + (Helpers.getUrlVar("type"));
      } else {
        this.link = data.link;
      }
      if (data.type.length) {
        this.type = data.type;
      } else {
        this.type = "";
      }
      return this.desc = data.desc;
    };

    return Confirmation;

  })(ManifestLoader);
  return $(function() {
    return ko.applyBindings(new Confirmation());
  });
})();
