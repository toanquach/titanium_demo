var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

(function() {
  var Steps;
  Steps = (function(_super) {
    __extends(Steps, _super);

    Steps.prototype.instance = null;

    function Steps() {
      this.clickAdviceHandler = __bind(this.clickAdviceHandler, this);
      this.successLoadParams = __bind(this.successLoadParams, this);
      this.choosePath = __bind(this.choosePath, this);
      this.successLoad = __bind(this.successLoad, this);
      var data;
      this.categories = ko.observableArray();
      this.title = ko.observable();
      this.sublink = ko.observable();
      data = $('#app').data('json');
      Steps.__super__.constructor.call(this, data);
    }

    Steps.prototype.isSuccessLoaded = function() {
      return Helpers.loadJson(Helpers.convertAbsoluteToRelativeJsonPath(this.getData().json.steps)).done(this.successLoad).fail(this.failLoad);
    };

    Steps.prototype.successLoad = function(data) {
      var idx, link, step, steps, _i, _j, _len, _len1, _ref;
      Steps.getInstance(this);
      this.attr = Helpers.getUrlVar("step");
      if (this.attr != null) {
        steps = this.attr.split(',');
        for (_i = 0, _len = steps.length; _i < _len; _i++) {
          step = steps[_i];
          _ref = data.cat[0].links;
          for (idx = _j = 0, _len1 = _ref.length; _j < _len1; idx = ++_j) {
            link = _ref[idx];
            if (link.id === parseInt(step, 10)) {
              data = data.cat[0].links[idx].submenu;
            }
          }
        }
      }
      this.title(data.title);
      this.cat = data.cat;
      this.sublink(data.sublink);
      this.displayCategories();
      Helpers.forceImgToRetina($('img'));
      Helpers.loadJson(Helpers.convertAbsoluteToRelativeJsonPath(this.getData().json.params)).done(this.successLoadParams).fail(this.failLoadParams);
      $('body ul').on('click', 'a', this.choosePath);
      $('.need-help').on('click', this.clickAdviceHandler);
      return Bridge.hideLoader();
    };

    Steps.prototype.displayCategories = function() {
      var i, _i, _ref, _results;
      _results = [];
      for (i = _i = 0, _ref = this.cat.length; 0 <= _ref ? _i < _ref : _i > _ref; i = 0 <= _ref ? ++_i : --_i) {
        _results.push(this.categories.push(new this.displayCategory(this.cat[i], this)));
      }
      return _results;
    };

    Steps.prototype.displayCategory = function(data, that) {
      this.title = data.title;
      this.links = ko.observableArray();
      that.displayLinks(data.links, this);
    };

    Steps.prototype.displayLinks = function(data, that) {
      var i, _i, _ref, _results;
      _results = [];
      for (i = _i = 0, _ref = data.length; 0 <= _ref ? _i < _ref : _i > _ref; i = 0 <= _ref ? ++_i : --_i) {
        _results.push(that.links.push(new this.displayLink(data[i])));
      }
      return _results;
    };

    Steps.prototype.displayLink = function(data) {
      this.label = data.label;
      this.attr = Helpers.getUrlVar("step");
      if (this.attr != null) {
        if (data.link.indexOf('?') !== -1) {
          this.link = "" + data.link + "&step=" + this.attr + "," + data.id;
        } else {
          this.link = "" + data.link + "?step=" + this.attr + "," + data.id;
        }
      } else {
        if (data.link.indexOf('?') !== -1) {
          this.link = "" + data.link + "&step=" + data.id;
        } else {
          this.link = "" + data.link + "?step=" + data.id;
        }
      }
      this.value = JSON.stringify(data.param);
      if (data.img.length) {
        this.type = data.img;
      } else {
        this.type = "";
      }
      return this.desc = data.desc;
    };

    Steps.prototype.choosePath = function(e) {
      var destination, nature, _ref, _ref1, _ref2;
      e.preventDefault();
      this.redirection = $(e.currentTarget).attr('href');
      if (!!((_ref = $(e.currentTarget).data('value')) != null ? _ref["task"] : void 0)) {
        this.params = {
          "params": {},
          "summary": {},
          "favorite": {}
        };
      }
      $.extend(this.params.params, $(e.currentTarget).data('value'));
      if (!!((_ref1 = $(e.currentTarget).data('value')) != null ? _ref1["destination"] : void 0)) {
        destination = this.getLabel("destinationPrefix") + $(e.currentTarget).find('.label').text();
        $.extend(this.params.summary, {
          "destination": destination
        });
        $.extend(this.params.favorite, {
          "destination": "France"
        });
      }
      if (!!((_ref2 = $(e.currentTarget).data('value')) != null ? _ref2["nature"] : void 0) || $(e.currentTarget).find('p').eq(0).text() === "Document Prioritaire" || $(e.currentTarget).find('p').eq(0).text() === "Marchandise prioritaire" || $(e.currentTarget).find('p').eq(0).text() === "Prêt-à-poster Postexport") {
        nature = $(e.currentTarget).find('.label').text();
        $.extend(this.params.summary, {
          "nature": nature
        }, {
          "image": $(e.currentTarget).find('img').attr('src').replace('@2x', '')
        });
        $.extend(this.params.favorite, {
          "details": nature
        });
      }
      if (Helpers.isWebApp()) {
        return Bridge.writeJSON(this.getData().json.params, this.params, "Steps.gotoNext()", false, "");
      } else {
        return Steps.gotoNext();
      }
    };

    Steps.prototype.successLoadParams = function(data) {
      return this.params = data;
    };

    Steps.prototype.clickAdviceHandler = function(e) {
      var $target, completeUrl, url;
      e.preventDefault();
      $target = $(e.currentTarget);
      url = $target.attr('href');
      $target.attr('href', "" + ($target.attr('href').split('&')[0]) + "&=" + (Math.random()));
      completeUrl = "" + (Helpers.getCurrentApp()) + "/views/" + url;
      return Bridge.displayPopin(completeUrl, null, $target.find('.advice-label').html());
    };

    Steps.getInstance = function(_this) {
      if (this.instance == null) {
        this.instance = _this;
      }
      return this.instance;
    };

    Steps.gotoNext = function() {
      return Bridge.redirect(this.instance.redirection);
    };

    return Steps;

  })(ManifestLoader);
  window.Steps = Steps;
  return $(function() {
    return ko.applyBindings(new Steps());
  });
})();
