var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

(function() {
  var Visualization;
  Visualization = (function(_super) {
    __extends(Visualization, _super);

    Visualization.prototype.flip = false;

    function Visualization() {
      this.switchImgMsg = __bind(this.switchImgMsg, this);
      this.failLoadTempJson = __bind(this.failLoadTempJson, this);
      this.successLoadTemp2Json = __bind(this.successLoadTemp2Json, this);
      this.successLoadTempJson = __bind(this.successLoadTempJson, this);
      var data;
      this.imgPreview = ko.observable();
      this.message = ko.observable();
      data = $('#app').data('json');
      Visualization.__super__.constructor.call(this, data);
    }

    Visualization.prototype.isSuccessLoaded = function() {
      var jsonPath;
      jsonPath = Helpers.convertAbsoluteToRelativeJsonPath(this.getData().json.temp, true);
      return Helpers.loadJson(jsonPath).done(this.successLoadTempJson).fail(this.failLoadTempJson);
    };

    Visualization.prototype.successLoadTempJson = function(data) {
      var jsonPath;
      this.tempData = data;
      jsonPath = Helpers.convertAbsoluteToRelativeJsonPath(this.getData().json.temp2, true);
      return Helpers.loadJson(jsonPath).done(this.successLoadTemp2Json).fail(this.failLoadTempJson);
    };

    Visualization.prototype.successLoadTemp2Json = function(data) {
      this.fillLabels();
      this.message(data.message);
      this.imgPreview(this.tempData.image.crop);
      this.replaceElements();
      Helpers.forceImgToRetina($('img'));
      Bridge.hideLoader();
      Bridge.navigationTitle(this.getLabel("title"));
      Bridge.tracking(7, "page", {
        "myPageLabel": "Visualization",
        "andPageChapter": "envoyer_une_carte::visuealisation"
      });
      return $('.switch').on('click touch', this.switchImgMsg);
    };

    Visualization.prototype.failLoadTempJson = function(error) {
      return console.log(error);
    };

    Visualization.prototype.replaceElements = function() {
      var _this = this;
      return $('.container-img .preview').load(function() {
        var lineY, msgWidth;
        $('.container-msg').height($('.container-img').height());
        msgWidth = $('.container-msg').width() - 126 - 20;
        $('.container-msg .msg').width("" + msgWidth + "px");
        lineY = $('.container-msg').height() - $('.container-msg .line').height() >> 1;
        return $('.container-msg .line').css("top", "" + lineY + "px");
      });
    };

    Visualization.prototype.switchImgMsg = function(e) {
      var value;
      this.flip = !this.flip;
      if (this.flip) {
        value = "180deg";
      } else {
        value = "0deg";
      }
      return $('.flipper').css({
        "transform": "rotateY(" + value + ")"
      });
    };

    return Visualization;

  })(ManifestLoader);
  return $(function() {
    return ko.applyBindings(new Visualization());
  });
})();
