var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

(function() {
  var livraisonColissimo;
  livraisonColissimo = (function(_super) {
    __extends(livraisonColissimo, _super);

    livraisonColissimo.prototype.instance = null;

    function livraisonColissimo() {
      this.successLoad = __bind(this.successLoad, this);
      var data;
      this.title = ko.observable();
      this.links = ko.observableArray();
      data = $('#app').data('json');
      livraisonColissimo.__super__.constructor.call(this, data);
    }

    livraisonColissimo.prototype.isSuccessLoaded = function() {
      return Helpers.loadJson(Helpers.convertAbsoluteToRelativeJsonPath(this.getData().json.livraisonColissimo)).done(this.successLoad).fail(this.failLoad);
    };

    livraisonColissimo.prototype.successLoad = function(data) {
      this.title(data.title);
      this.data = data.links;
      this.displayLinks();
      $('a').on('click', this.clickHandler);
      Bridge.hideLoader();
      return Bridge.tracking(data.tracking.setLevel2, "page", {
        "myPageLabel": data.tracking.myPageLabel,
        "andPageChapter": data.tracking.andPageChapter
      });
    };

    livraisonColissimo.prototype.displayLinks = function() {
      var i, _i, _ref, _results;
      _results = [];
      for (i = _i = 0, _ref = this.data.length; 0 <= _ref ? _i < _ref : _i > _ref; i = 0 <= _ref ? ++_i : --_i) {
        _results.push(this.links.push(new this.displayLink(this.data[i], this)));
      }
      return _results;
    };

    livraisonColissimo.prototype.displayLink = function(data, that) {
      this.label = data.label;
      this.desc = data.desc;
      this.link = data.link;
      this.tracking = JSON.stringify(data.tracking);
    };

    livraisonColissimo.prototype.clickHandler = function(e) {
      var $target, tracking, url;
      e.preventDefault();
      $target = $(e.currentTarget);
      url = $target.attr('href');
      tracking = $target.data("tracking");
      Bridge.tracking(tracking.setLevel2, 'click', {
        "myPageLabel": tracking.myPageLabel,
        "andPageChapter": tracking.andPageChapter
      });
      Bridge.redirect(url);
    };

    return livraisonColissimo;

  })(ManifestLoader);
  return $(function() {
    return ko.applyBindings(new livraisonColissimo());
  });
})();
