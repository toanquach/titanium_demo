var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

(function() {
  var monDomicile;
  monDomicile = (function(_super) {
    __extends(monDomicile, _super);

    monDomicile.prototype.instance = null;

    function monDomicile() {
      this.successLoad = __bind(this.successLoad, this);
      var data;
      this.title = ko.observable();
      this.desc = ko.observable();
      data = $('#app').data('json');
      monDomicile.__super__.constructor.call(this, data);
    }

    monDomicile.prototype.isSuccessLoaded = function() {
      return Helpers.loadJson(Helpers.convertAbsoluteToRelativeJsonPath(this.getData().json.solution)).done(this.successLoad).fail(this.failLoad);
    };

    monDomicile.prototype.successLoad = function(data) {
      var type;
      type = Helpers.getUrlVar("type");
      this.title(data[type].title);
      this.desc(data[type].desc);
      this.fillLabels();
      return Bridge.hideLoader();
    };

    return monDomicile;

  })(ManifestLoader);
  return $(function() {
    return ko.applyBindings(new monDomicile());
  });
})();
