var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

(function() {
  var FacebookAlbum;
  FacebookAlbum = (function(_super) {
    __extends(FacebookAlbum, _super);

    function FacebookAlbum() {
      this.selectPicture = __bind(this.selectPicture, this);
      this.failGetFacebookPicturesAlbum = __bind(this.failGetFacebookPicturesAlbum, this);
      this.successGetFacebookPicturesAlbum = __bind(this.successGetFacebookPicturesAlbum, this);
      var data;
      this.albumName = ko.observable();
      this.pictures = ko.observableArray();
      data = $('#app').data('json');
      FacebookAlbum.__super__.constructor.call(this, data);
    }

    FacebookAlbum.prototype.isSuccessLoaded = function() {
      if (Helpers.getUrlVar('accesstoken') != null) {
        this.accessToken = Helpers.getUrlVar('accesstoken');
        this.getFacebookPicturesAlbum();
      } else {
        this.loginFacebook();
      }
      this.fillLabels();
      return Bridge.hideLoader();
    };

    FacebookAlbum.prototype.loginFacebook = function() {
      var appId, currentUrl, permissionUrl, redirectPage, scope;
      appId = this.getData().facebook.appId;
      scope = this.getData().facebook.scope;
      redirectPage = this.getData().facebook.redirect;
      permissionUrl = "https://www.facebook.com/dialog/oauth?client_id=" + appId + "&client_secret=6aee16ceecf89b72ace0b4c0ddadb6fd&response_type=token&redirect_uri=" + redirectPage + "&scope=" + scope;
      currentUrl = window.location.href;
      return Bridge.socialNetworkCnx(permissionUrl, currentUrl);
    };

    FacebookAlbum.prototype.getFacebookPicturesAlbum = function() {
      var graphUrl, id, name;
      Bridge.displayLoader();
      id = Helpers.getUrlVar('id');
      name = Helpers.getUrlVar('name');
      this.albumName(decodeURI(name));
      graphUrl = "https://graph.facebook.com/" + id + "/photos?limit=" + (this.getData().facebook.limit_photos) + "&access_token=" + this.accessToken;
      return $.getJSON(graphUrl).done(this.successGetFacebookPicturesAlbum).fail(this.failGetFacebookPicturesAlbum);
    };

    FacebookAlbum.prototype.successGetFacebookPicturesAlbum = function(response) {
      var cpt, imgWidth, item, _i, _len, _ref;
      Bridge.hideLoader(false);
      cpt = 0;
      this.data = response.data;
      _ref = this.data;
      for (_i = 0, _len = _ref.length; _i < _len; _i++) {
        item = _ref[_i];
        this.pictures.push(new this.DisplayPicture(item, this));
        imgWidth = ($('#app').width() - 2) / 3;
        $('.picture-img').css({
          width: "" + imgWidth + "px",
          height: "" + imgWidth + "px"
        });
        $('.picture-selected-layer').css({
          width: "" + imgWidth + "px",
          height: "" + imgWidth + "px"
        });
        if ((cpt + 1) % 3 === 0) {
          $($('.picture-li')[cpt]).css("margin-right", "0");
        }
        cpt++;
      }
      this.height = $('#app').height();
      return $('.picture-container').on('click touch', this.selectPicture);
    };

    FacebookAlbum.prototype.failGetFacebookPicturesAlbum = function(error) {
      Bridge.hideLoader(false);
      return console.log(error);
    };

    FacebookAlbum.prototype.DisplayPicture = function(data, that) {
      this.img = ko.observable("url(" + data.picture + ")");
      return this;
    };

    FacebookAlbum.prototype.selectPicture = function(e) {
      var i, imgSrc, temp, _i, _ref;
      for (i = _i = 0, _ref = $('.picture-container').length; 0 <= _ref ? _i < _ref : _i > _ref; i = 0 <= _ref ? ++_i : --_i) {
        if ($('.picture-container')[i] !== e.currentTarget) {
          $($('.picture-container')[i]).removeClass('active');
        } else {
          this.pictureSelected = i;
        }
      }
      if (!$(e.currentTarget).hasClass('active')) {
        $(e.currentTarget).addClass('active');
        $('.container-btn-next').css('bottom', '0');
        $('#app').height(this.height + $('.container-btn-next').height());
      } else {
        $(e.currentTarget).removeClass('active');
        $('.container-btn-next').css('bottom', '-100px');
        $('#app').height(this.height - $('.container-btn-next').height());
      }
      imgSrc = this.data[this.pictureSelected].images[0].source;
      temp = {
        "image": {
          "original": "" + imgSrc
        }
      };
      return Bridge.writeTempJSON(temp);
    };

    return FacebookAlbum;

  })(ManifestLoader);
  return $(function() {
    return ko.applyBindings(new FacebookAlbum());
  });
})();
