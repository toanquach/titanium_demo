var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

(function() {
  var Didacticiel;
  Didacticiel = (function(_super) {
    __extends(Didacticiel, _super);

    function Didacticiel() {
      this.setSlideshow = __bind(this.setSlideshow, this);
      this.failLoadDidacticiel = __bind(this.failLoadDidacticiel, this);
      this.successLoadDidacticiel = __bind(this.successLoadDidacticiel, this);
      var data;
      this.didacticiel = ko.observableArray();
      data = $('#app').data('json');
      Didacticiel.__super__.constructor.call(this, data);
    }

    Didacticiel.prototype.isSuccessLoaded = function() {
      var jsonPath;
      jsonPath = Helpers.convertAbsoluteToRelativeJsonPath(this.getData().json.didacticiel);
      return Helpers.loadJson(jsonPath).done(this.successLoadDidacticiel).fail(this.failLoadDidacticiel);
    };

    Didacticiel.prototype.successLoadDidacticiel = function(data) {
      data = data.didacticiel;
      this.setDidacticiel(data);
      this.setSlideshow();
      Helpers.forceImgToRetina($('img'));
      Bridge.hideLoader();
      return Bridge.tracking(7, "page", {
        "myPageLabel": "didacticiel",
        "andPageChapter": "didacticiel"
      });
    };

    Didacticiel.prototype.failLoadDidacticiel = function(error) {
      return console.log(error);
    };

    Didacticiel.prototype.setDidacticiel = function(data) {
      var i, _i, _ref, _results;
      _results = [];
      for (i = _i = 0, _ref = data.length; 0 <= _ref ? _i < _ref : _i > _ref; i = 0 <= _ref ? ++_i : --_i) {
        _results.push(this.didacticiel.push(new this.DisplayDidacticiel(data[i], this)));
      }
      return _results;
    };

    Didacticiel.prototype.DisplayDidacticiel = function(data, that) {
      this.img = data.img;
      this.title = data.title;
      return this.description = data.description;
    };

    Didacticiel.prototype.setSlideshow = function() {
      var _this = this;
      return $('.flexslider').flexslider({
        animation: "slide",
        animationLoop: false,
        slideshow: false,
        directionNav: false,
        touch: true,
        start: function() {
          var nb;
          $('.flexslider').resize();
          nb = $('.flexslider').data('flexslider').count;
          if (nb > 4 && parseFloat(($('#app').width() - 30) / nb) < 40) {
            $('.flexslider .flex-control-nav li').css("margin", "0px");
            return $('.flexslider .flex-control-nav li a').css("width", "" + (($('#app').width() - 30) / nb) + "px");
          }
        }
      });
    };

    return Didacticiel;

  })(ManifestLoader);
  return $(function() {
    return ko.applyBindings(new Didacticiel());
  });
})();
