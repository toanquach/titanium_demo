var __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  __hasProp = {}.hasOwnProperty,
  __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

(function() {
  var Recommande;
  Recommande = (function(_super) {
    __extends(Recommande, _super);

    Recommande.prototype.instance = null;

    function Recommande() {
      this.clickAdviceHandler = __bind(this.clickAdviceHandler, this);
      this.successLoadParams = __bind(this.successLoadParams, this);
      this.chooseType = __bind(this.chooseType, this);
      this.successLoad = __bind(this.successLoad, this);
      var data;
      this.categories = ko.observableArray();
      this.title = ko.observable();
      this.sublink = ko.observable();
      this.ar = {};
      data = $('#app').data('json');
      Recommande.__super__.constructor.call(this, data);
    }

    Recommande.prototype.isSuccessLoaded = function() {
      return Helpers.loadJson(Helpers.convertAbsoluteToRelativeJsonPath(this.getData().json.recommande)).done(this.successLoad).fail(this.failLoad);
    };

    Recommande.prototype.successLoad = function(data) {
      var attr;
      Recommande.getInstance(this);
      attr = Helpers.getUrlVar("type");
      if (attr != null) {
        data = data[attr];
      }
      this.title(data.title);
      this.sublink(data.sublink);
      this.cat = data.cat;
      this.displayCategories();
      Helpers.forceImgToRetina($('img'));
      Helpers.loadJson(Helpers.convertAbsoluteToRelativeJsonPath(this.getData().json.params)).done(this.successLoadParams).fail(this.failLoadParams);
      $('body ul').on('click', 'a', this.chooseType);
      $('.need-help').on('click', this.clickAdviceHandler);
      return Bridge.hideLoader();
    };

    Recommande.prototype.displayCategories = function() {
      var i, _i, _ref, _results;
      _results = [];
      for (i = _i = 0, _ref = this.cat.length; 0 <= _ref ? _i < _ref : _i > _ref; i = 0 <= _ref ? ++_i : --_i) {
        _results.push(this.categories.push(new this.displayCategory(this.cat[i], this)));
      }
      return _results;
    };

    Recommande.prototype.displayCategory = function(data, that) {
      this.title = data.title;
      this.links = ko.observableArray();
      this.filter = ko.observable(false);
      this.filteredList = ko.computed(function() {
        var filter;
        filter = this.filter();
        return ko.utils.arrayFilter(this.links(), function(link) {
          if (filter) {
            link.show(link.ar);
          } else {
            link.show(true);
          }
        });
      }, this);
      this.changeAR = function() {
        if (this.filter()) {
          return this.filter(false);
        } else {
          return this.filter(true);
        }
      };
      that.displayLinks(data.links, this);
    };

    Recommande.prototype.displayLinks = function(data, that) {
      var i, _i, _ref, _results;
      _results = [];
      for (i = _i = 0, _ref = data.length; 0 <= _ref ? _i < _ref : _i > _ref; i = 0 <= _ref ? ++_i : --_i) {
        _results.push(that.links.push(new this.displayLink(data[i])));
      }
      return _results;
    };

    Recommande.prototype.displayLink = function(data) {
      this.show = ko.observable(true);
      this.ar = data.ar;
      this.label = data.label;
      if (data.link.length) {
        this.link = data.link;
      } else {
        this.attr = Helpers.getUrlVar("step");
        if (this.attr != null) {
          this.link = "?step=" + this.attr + "," + data.id;
        } else {
          this.link = "?step=" + data.id;
        }
      }
      this.value = JSON.stringify(data.param);
      if (data.img.length) {
        this.type = data.img;
      } else {
        this.type = "";
      }
      this.desc = data.desc;
    };

    Recommande.prototype.chooseType = function(e) {
      var $checkbox, $img, tmp, tmp1, tmp2;
      e.preventDefault();
      $checkbox = $(e.currentTarget).find('.checkbox');
      if ($checkbox.length) {
        $img = $checkbox.find('img');
        if ($img.attr('src').indexOf('-off') !== -1) {
          $img.attr('src', $img.attr('src').replace('-off', '-on'));
          return this.ar = {
            "ar": "ac"
          };
        } else {
          $img.attr('src', $img.attr('src').replace('-on', '-off'));
          return this.ar = {};
        }
      } else {
        this.redirection = $(e.currentTarget).attr('href');
        $.extend(this.params.params, $(e.currentTarget).data('value'), this.ar);
        tmp = $(e.currentTarget).find('.label').text();
        if (tmp === "Export suivi") {
          tmp1 = "Recommandé, " + tmp;
          tmp2 = "Recommandé " + tmp + "\nAucune Option";
        }
        if (/^R[1-9]/.test(tmp)) {
          if (!!this.ar["ar"]) {
            tmp1 = "Recommandé, " + tmp + ", Avis de réception";
            tmp2 = "Recommandé " + tmp + "\n Avis de réception";
          } else {
            tmp1 = "Recommandé, " + tmp;
            tmp2 = "Recommandé " + tmp + "\nAucune Option";
          }
        }
        $.extend(this.params.summary, {
          "recommande": tmp1
        });
        $.extend(this.params.favorite, {
          "details": tmp2
        });
        if (Helpers.isWebApp()) {
          return Bridge.writeJSON(this.getData().json.params, this.params, "Recommande.gotoNext()", false, "");
        } else {
          return Recommande.gotoNext();
        }
      }
    };

    Recommande.prototype.successLoadParams = function(data) {
      this.params = data;
    };

    Recommande.prototype.clickAdviceHandler = function(e) {
      var $target, completeUrl, url;
      e.preventDefault();
      $target = $(e.currentTarget);
      url = $target.attr('href');
      $target.attr('href', "" + ($target.attr('href').split('&')[0]) + "&=" + (Math.random()));
      completeUrl = "" + (Helpers.getCurrentApp()) + "/views/" + url;
      return Bridge.displayPopin(completeUrl, null, $target.find('.advice-label').html());
    };

    Recommande.getInstance = function(_this) {
      if (this.instance == null) {
        this.instance = _this;
      }
      return this.instance;
    };

    Recommande.gotoNext = function() {
      return Bridge.redirect(this.instance.redirection);
    };

    return Recommande;

  })(ManifestLoader);
  window.Recommande = Recommande;
  return $(function() {
    return ko.applyBindings(new Recommande());
  });
})();
